/**
 * ZaZ POS Pro - Preload Script
 * Secure bridge: exposes safe API to renderer via contextBridge
 * No direct Node.js access in renderer
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {

  // ---- App ----
  getAppInfo: () => ipcRenderer.invoke('app:info'),

  // ---- Database (generic) ----
  dbGet: (sql, params) => ipcRenderer.invoke('db:get', sql, params),
  dbAll: (sql, params) => ipcRenderer.invoke('db:all', sql, params),
  dbRun: (sql, params) => ipcRenderer.invoke('db:run', sql, params),

  // ---- Business Info ----
  getBusiness: () => ipcRenderer.invoke('business:get'),
  updateBusiness: (data) => ipcRenderer.invoke('business:update', data),

  // ---- Settings ----
  getSettings: () => ipcRenderer.invoke('settings:get'),
  updateSettings: (data) => ipcRenderer.invoke('settings:update', data),

  // ---- Network ----
  getNetworkInfo: () => ipcRenderer.invoke('network:info'),

  // ---- Stock System ----
  stockDeduct: (items) => ipcRenderer.invoke('stock:deduct', items),
  stockAdjust: (data) => ipcRenderer.invoke('stock:adjust', data),
  stockDamage: (data) => ipcRenderer.invoke('stock:damage', data),
  stockRestore: (saleId) => ipcRenderer.invoke('stock:restore', saleId),
  stockHistory: (opts) => ipcRenderer.invoke('stock:history', opts || {}),
  stockLow: () => ipcRenderer.invoke('stock:low'),

  // ---- Backup System ----
  backupCreate: (label) => ipcRenderer.invoke('backup:create', label),
  backupList: () => ipcRenderer.invoke('backup:list'),
  backupRestore: (path) => ipcRenderer.invoke('backup:restore', path),
  backupDelete: (path) => ipcRenderer.invoke('backup:delete', path),
  backupOpenFolder: () => ipcRenderer.invoke('backup:openFolder'),
  backupGetDbPath: () => ipcRenderer.invoke('backup:getDbPath'),
  backupExport: (path) => ipcRenderer.invoke('backup:exportFile', path),
  backupImport: () => ipcRenderer.invoke('backup:importFile'),
  gdriveUpload: (data) => ipcRenderer.invoke('gdrive:upload', data),
  gdriveList: (token) => ipcRenderer.invoke('gdrive:list', token),
  gdriveDownload: (data) => ipcRenderer.invoke('gdrive:download', data),

  // ---- Software Update ----
  updateCheck: () => ipcRenderer.invoke('update:check'),
  updateInstall: () => ipcRenderer.invoke('update:install'),

  // ---- Events (renderer listening) ----
  on: (channel, callback) => {
    const validChannels = [
      'cart:updated',
      'product:scanned',
      'stock:alert',
      'sync:status',
      'device:connected',
      'device:disconnected',
      'backup:status',
      'update:status'
    ];
    if (validChannels.includes(channel)) {
      ipcRenderer.on(channel, (event, ...args) => callback(...args));
    }
  },

  removeListener: (channel, callback) => {
    ipcRenderer.removeListener(channel, callback);
  }
});
