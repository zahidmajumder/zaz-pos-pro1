/**
 * ZaZ POS Pro - Database Module
 * SQLite local database with all core tables
 * Offline-first, instant save, crash-safe
 */

const path = require('path');
const Database = require('better-sqlite3');
const { app } = require('electron');

let db = null;

function getDbPath() {
  const userDataPath = app ? app.getPath('userData') : path.join(__dirname, '..');
  return path.join(userDataPath, 'zaz_pos_pro.db');
}

function initDatabase() {
  const dbPath = getDbPath();
  console.log('[DB] Opening database at:', dbPath);

  db = new Database(dbPath);

  // Performance: WAL mode for speed + crash safety
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  db.pragma('cache_size = -64000'); // 64MB cache

  createTables();
  seedDefaults();

  console.log('[DB] Database initialized successfully');
  return db;
}

function createTables() {
  db.exec(`

    -- ============================================
    -- BUSINESS INFO
    -- ============================================
    CREATE TABLE IF NOT EXISTS business_info (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      shop_name TEXT DEFAULT '',
      logo_path TEXT DEFAULT '',
      address TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      vat_number TEXT DEFAULT '',
      cr_number TEXT DEFAULT '',
      currency TEXT DEFAULT 'SAR',
      tax_rate REAL DEFAULT 15.0,
      receipt_footer TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- ============================================
    -- SECURITY / PIN
    -- ============================================
    CREATE TABLE IF NOT EXISTS app_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      client_pin TEXT DEFAULT '',
      owner_password TEXT DEFAULT '65244342726',
      pin_required INTEGER DEFAULT 0,
      license_type TEXT DEFAULT 'unlimited',
      license_expiry TEXT DEFAULT '',
      mac_locked INTEGER DEFAULT 0,
      mac_address TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- ============================================
    -- OWNER FEATURE VISIBILITY
    -- ============================================
    CREATE TABLE IF NOT EXISTS feature_visibility (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      feature_key TEXT UNIQUE NOT NULL,
      feature_label TEXT NOT NULL,
      is_visible INTEGER DEFAULT 1,
      is_editable_by_client INTEGER DEFAULT 1
    );

    -- ============================================
    -- CATEGORIES
    -- ============================================
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      name_ar TEXT DEFAULT '',
      color TEXT DEFAULT '#4A90D9',
      sort_order INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- ============================================
    -- PRODUCTS
    -- ============================================
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      barcode TEXT UNIQUE,
      sku TEXT DEFAULT '',
      name TEXT NOT NULL,
      name_ar TEXT DEFAULT '',
      category_id INTEGER DEFAULT NULL,
      cost_price REAL DEFAULT 0,
      sell_price REAL NOT NULL DEFAULT 0,
      tax_included INTEGER DEFAULT 1,
      stock_qty REAL DEFAULT 0,
      low_stock_threshold REAL DEFAULT 5,
      track_stock INTEGER DEFAULT 1,
      unit TEXT DEFAULT 'pcs',
      image_path TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      is_deleted INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (category_id) REFERENCES categories(id)
    );

    -- ============================================
    -- CUSTOMERS
    -- ============================================
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL DEFAULT 'Customer General',
      phone TEXT DEFAULT '',
      email TEXT DEFAULT '',
      address TEXT DEFAULT '',
      balance_due REAL DEFAULT 0,
      notes TEXT DEFAULT '',
      is_active INTEGER DEFAULT 1,
      is_deleted INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now','localtime')),
      updated_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- ============================================
    -- SALES
    -- ============================================
    CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_number TEXT UNIQUE NOT NULL,
      customer_id INTEGER DEFAULT 1,
      subtotal REAL DEFAULT 0,
      tax_amount REAL DEFAULT 0,
      discount_amount REAL DEFAULT 0,
      total REAL DEFAULT 0,
      amount_paid REAL DEFAULT 0,
      change_amount REAL DEFAULT 0,
      payment_method TEXT DEFAULT 'cash',
      cash_amount REAL DEFAULT 0,
      card_amount REAL DEFAULT 0,
      due_amount REAL DEFAULT 0,
      status TEXT DEFAULT 'completed',
      is_void INTEGER DEFAULT 0,
      void_reason TEXT DEFAULT '',
      void_by TEXT DEFAULT '',
      device_id TEXT DEFAULT 'main',
      notes TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (customer_id) REFERENCES customers(id)
    );

    -- ============================================
    -- SALE ITEMS
    -- ============================================
    CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      barcode TEXT DEFAULT '',
      qty REAL DEFAULT 1,
      unit_price REAL DEFAULT 0,
      cost_price REAL DEFAULT 0,
      discount REAL DEFAULT 0,
      tax_amount REAL DEFAULT 0,
      total REAL DEFAULT 0,
      is_void INTEGER DEFAULT 0,
      FOREIGN KEY (sale_id) REFERENCES sales(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- ============================================
    -- STOCK HISTORY
    -- ============================================
    CREATE TABLE IF NOT EXISTS stock_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      qty_change REAL DEFAULT 0,
      qty_before REAL DEFAULT 0,
      qty_after REAL DEFAULT 0,
      reference_id TEXT DEFAULT '',
      reason TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- ============================================
    -- DAMAGE STOCK
    -- ============================================
    CREATE TABLE IF NOT EXISTS damage_stock (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      qty REAL DEFAULT 0,
      reason TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    -- ============================================
    -- EXPENSES
    -- ============================================
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT DEFAULT 'General',
      description TEXT DEFAULT '',
      amount REAL DEFAULT 0,
      date TEXT DEFAULT (date('now','localtime')),
      is_deleted INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now','localtime'))
    );

    -- ============================================
    -- PAYMENT HISTORY (Customer Dues)
    -- ============================================
    CREATE TABLE IF NOT EXISTS payment_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER NOT NULL,
      sale_id INTEGER DEFAULT NULL,
      amount REAL DEFAULT 0,
      type TEXT DEFAULT 'payment',
      method TEXT DEFAULT 'cash',
      notes TEXT DEFAULT '',
      created_at TEXT DEFAULT (datetime('now','localtime')),
      FOREIGN KEY (customer_id) REFERENCES customers(id),
      FOREIGN KEY (sale_id) REFERENCES sales(id)
    );

    -- ============================================
    -- DEVICES (Multi-device tracking)
    -- ============================================
    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY,
      name TEXT DEFAULT '',
      type TEXT DEFAULT 'pc',
      ip_address TEXT DEFAULT '',
      last_seen TEXT DEFAULT (datetime('now','localtime')),
      is_active INTEGER DEFAULT 1
    );

    -- ============================================
    -- INDEXES FOR PERFORMANCE
    -- ============================================
    CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active, is_deleted);
    CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(created_at);
    CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id);
    CREATE INDEX IF NOT EXISTS idx_sales_status ON sales(status, is_void);
    CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);
    CREATE INDEX IF NOT EXISTS idx_stock_history_product ON stock_history(product_id);
    CREATE INDEX IF NOT EXISTS idx_customers_active ON customers(is_active, is_deleted);

  `);
}

function seedDefaults() {
  // Seed business info row if not exists
  const bizRow = db.prepare('SELECT id FROM business_info WHERE id = 1').get();
  if (!bizRow) {
    db.prepare('INSERT INTO business_info (id) VALUES (1)').run();
  }

  // Seed app settings row if not exists
  const settingsRow = db.prepare('SELECT id FROM app_settings WHERE id = 1').get();
  if (!settingsRow) {
    db.prepare('INSERT INTO app_settings (id) VALUES (1)').run();
  }

  // Seed default customer if not exists
  const defaultCustomer = db.prepare('SELECT id FROM customers WHERE id = 1').get();
  if (!defaultCustomer) {
    db.prepare("INSERT INTO customers (id, name) VALUES (1, 'Customer General')").run();
  }

  // Seed feature visibility defaults
  const featureCount = db.prepare('SELECT COUNT(*) as cnt FROM feature_visibility').get();
  if (featureCount.cnt === 0) {
    const features = [
      ['sell', 'Sell Screen', 1, 1],
      ['products', 'Products', 1, 1],
      ['categories', 'Categories', 1, 1],
      ['customers', 'Customers', 1, 1],
      ['inventory', 'Inventory', 1, 1],
      ['sales_report', 'Sales Report', 1, 1],
      ['profit_report', 'Profit Report', 1, 0],
      ['expense_report', 'Expense Report', 1, 1],
      ['stock_report', 'Stock Report', 1, 1],
      ['expenses', 'Expenses', 1, 1],
      ['settings', 'Settings', 1, 1],
      ['backup', 'Backup', 1, 0]
    ];
    const insert = db.prepare(
      'INSERT INTO feature_visibility (feature_key, feature_label, is_visible, is_editable_by_client) VALUES (?, ?, ?, ?)'
    );
    const insertMany = db.transaction((items) => {
      for (const item of items) insert.run(...item);
    });
    insertMany(features);
  }

  // Seed main device
  const mainDevice = db.prepare("SELECT id FROM devices WHERE id = 'main'").get();
  if (!mainDevice) {
    db.prepare("INSERT INTO devices (id, name, type) VALUES ('main', 'Main PC', 'pc')").run();
  }
}

function getDb() {
  if (!db) {
    throw new Error('[DB] Database not initialized. Call initDatabase() first.');
  }
  return db;
}

function closeDatabase() {
  if (db) {
    db.close();
    db = null;
    console.log('[DB] Database closed');
  }
}

module.exports = {
  initDatabase,
  getDb,
  closeDatabase,
  getDbPath
};
