# ZaZ POS Pro

Enterprise-grade Point of Sale desktop application built with Electron.js and SQLite.

![Electron](https://img.shields.io/badge/Electron-33-blue)
![SQLite](https://img.shields.io/badge/SQLite-Local-green)
![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey)
![License](https://img.shields.io/badge/License-Private-red)

---

## Features

### 🛒 Sell Screen (POS)
- Fullscreen POS interface — default screen on launch
- Product grid with category tabs
- Live search by name, barcode, or SKU
- Cart with quantity control (+/−), remove, clear
- Auto-calculated subtotal, tax (15%), and total
- Keyboard shortcuts: `ENTER` Pay, `ESC` Clear, `F2` Search

### 📷 Barcode Scanner
- USB barcode scanner auto-detection (no focus needed)
- Mobile camera scanner via browser (`http://<IP>:3456/scanner`)
- Dual-tone beep on successful scan
- Error buzzer for unknown barcodes
- Duplicate scan prevention (1.2s cooldown)
- Same product scan → quantity increases

### 📦 Product Management
- Add / Edit / Delete products
- Barcode, SKU, category, cost price, sell price
- Arabic name support
- Stock tracking toggle per product
- **Duplicate barcode prevention** (live check + save check + DB constraint)
- Soft delete (never hard removes)

### 🏷️ Category Management
- Add / Edit / Delete categories
- Color picker, Arabic name, sort order
- Product count per category

### 📋 Inventory & Stock
- Real-time stock tracking
- Low stock alerts with orange banner
- Stock adjust (add / remove / set exact qty)
- Damage stock recording with reason
- Full stock history log with type badges
- **Transaction-safe stock deduction** (SQLite transactions)
- **Prevents overselling** at cart-time and payment-time

### 💳 Payment System
- Cash / Card / Split payment *(coming soon)*
- Payment validation against total

### 🧾 Receipt & Invoice
- Thermal receipt printing *(coming soon)*
- A4 invoice with Arabic + English *(coming soon)*
- ZATCA QR code *(coming soon)*

### 📱 Multi-Device
- PC = main server
- Mobile clients connect via IP on same network
- Socket.io real-time sync
- Mobile camera barcode scanner page

### 📊 Dashboard
- Today's sales total and order count
- Active product count
- Low stock alert count

### 🔐 Security
- Client PIN system *(coming soon)*
- Owner panel with password protection *(coming soon)*

---

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Desktop | Electron.js 33 |
| Database | SQLite (better-sqlite3, WAL mode) |
| Server | Express.js |
| Real-time | Socket.io |
| Frontend | Vanilla HTML/CSS/JS |
| Scanner | ZXing (mobile camera) |

---

## Installation

### Prerequisites
- [Node.js](https://nodejs.org/) v18 or later
- npm (comes with Node.js)

### Setup

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/zaz-pos-pro.git
cd zaz-pos-pro

# Install dependencies
npm install

# Run the application
npm start
```

### Build .exe (Windows)

```bash
npm run build
```

Output will be in the `dist/` folder.

---

## Project Structure

```
zaz-pos-pro/
├── main.js              # Electron main process
├── preload.js           # Secure API bridge
├── index.html           # App shell (all pages)
├── renderer.js          # Frontend logic
├── style.css            # Stylesheet (#EBEBEB sell, #F7F7F7 others)
├── scanner.html         # Mobile camera scanner page
├── database/
│   └── db.js            # SQLite init, 13 tables, indexes
├── assets/              # Icons, images
├── package.json
└── .gitignore
```

### Database Tables

| Table | Purpose |
|-------|---------|
| `business_info` | Shop name, logo, VAT, CR |
| `app_settings` | PIN, owner password, license |
| `feature_visibility` | Owner feature control |
| `categories` | Product categories |
| `products` | Product catalog |
| `customers` | Customer records |
| `sales` | Sale transactions |
| `sale_items` | Items per sale |
| `stock_history` | Stock change log |
| `damage_stock` | Damaged stock records |
| `expenses` | Expense tracking |
| `payment_history` | Customer payment log |
| `devices` | Multi-device registry |

---

## Mobile Scanner

1. Open Settings → note the IP address shown
2. On your phone, connect to the **same WiFi network**
3. Open browser and go to: `http://<IP>:3456/scanner`
4. Allow camera permission
5. Point at any barcode — it auto-sends to POS

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `F1` | Dashboard |
| `F2` | Sell screen + focus search |
| `F3` | Products |
| `ENTER` | Pay (when cart has items) |
| `ESC` | Clear cart |
| `+` / `-` | Quantity adjust *(in cart)* |

---

## Configuration

- **Background colors:** `#EBEBEB` (sell screen), `#F7F7F7` (other pages)
- **Tax rate:** 15% (configurable in code)
- **Server port:** 3456
- **Database:** Auto-created in user data folder

---

## Created by

**Zakir & Zahid**

---

## License

Private — All rights reserved.
