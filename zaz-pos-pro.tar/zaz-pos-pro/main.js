/**
 * ZaZ POS Pro - Main Process
 * Electron main entry point
 * Handles: window, database, IPC, Express server
 */

const { app, BrowserWindow, ipcMain, screen, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { initDatabase, getDb, closeDatabase, getDbPath } = require('./database/db');
const express = require('express');
const http = require('http');
const os = require('os');
const { autoUpdater } = require('electron-updater');

// ============================================
// GLOBALS
// ============================================
let mainWindow = null;
let db = null;
let expressApp = null;
let httpServer = null;
let io = null;
const SERVER_PORT = 3456;

// ============================================
// AUTO-UPDATER SYSTEM
// ============================================
function initAutoUpdater() {
  // Config
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.allowPrerelease = false;

  // Logging
  autoUpdater.logger = {
    info: (msg) => console.log('[UPDATER]', msg),
    warn: (msg) => console.warn('[UPDATER]', msg),
    error: (msg) => console.error('[UPDATER]', msg),
    debug: (msg) => console.log('[UPDATER:DEBUG]', msg)
  };

  // Events → send to renderer
  autoUpdater.on('checking-for-update', () => {
    console.log('[UPDATER] Checking for update...');
    sendToRenderer('update:status', { status: 'checking' });
  });

  autoUpdater.on('update-available', (info) => {
    console.log('[UPDATER] Update available:', info.version);
    sendToRenderer('update:status', {
      status: 'available',
      version: info.version,
      releaseDate: info.releaseDate,
      releaseNotes: info.releaseNotes || ''
    });
  });

  autoUpdater.on('update-not-available', (info) => {
    console.log('[UPDATER] No update available. Current:', info.version);
    sendToRenderer('update:status', {
      status: 'up-to-date',
      version: info.version
    });
  });

  autoUpdater.on('download-progress', (progress) => {
    sendToRenderer('update:status', {
      status: 'downloading',
      percent: Math.round(progress.percent),
      transferred: progress.transferred,
      total: progress.total,
      speed: progress.bytesPerSecond
    });
  });

  autoUpdater.on('update-downloaded', (info) => {
    console.log('[UPDATER] Update downloaded:', info.version);
    sendToRenderer('update:status', {
      status: 'downloaded',
      version: info.version
    });

    // Show dialog to user
    if (mainWindow && !mainWindow.isDestroyed()) {
      dialog.showMessageBox(mainWindow, {
        type: 'info',
        title: 'Update Ready',
        message: `Version ${info.version} has been downloaded.`,
        detail: 'The app will restart to install the update.',
        buttons: ['Restart Now', 'Later'],
        defaultId: 0
      }).then((result) => {
        if (result.response === 0) {
          autoUpdater.quitAndInstall(false, true);
        }
      });
    }
  });

  autoUpdater.on('error', (err) => {
    console.error('[UPDATER] Error:', err.message);
    sendToRenderer('update:status', {
      status: 'error',
      error: err.message
    });
  });

  // Check on startup (after 5 seconds)
  setTimeout(() => {
    autoUpdater.checkForUpdates().catch(e => {
      console.log('[UPDATER] Check failed (offline?):', e.message);
    });
  }, 5000);

  // Check every 30 minutes
  setInterval(() => {
    autoUpdater.checkForUpdates().catch(() => {});
  }, 30 * 60 * 1000);
}

function sendToRenderer(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, data);
  }
}

// ============================================
// SINGLE INSTANCE LOCK
// ============================================
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

// ============================================
// CREATE WINDOW
// ============================================
function createMainWindow() {
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width, height } = primaryDisplay.workAreaSize;

  mainWindow = new BrowserWindow({
    width: width,
    height: height,
    minWidth: 1024,
    minHeight: 600,
    show: false,
    frame: true,
    title: 'ZaZ POS Pro',
    backgroundColor: '#F7F7F7',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      devTools: true
    }
  });

  mainWindow.loadFile('index.html');

  // Show when ready to prevent white flash
  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize();
    mainWindow.show();
    console.log('[APP] Window displayed');
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// ============================================
// EXPRESS SERVER (for multi-device access)
// ============================================
function startExpressServer() {
  expressApp = express();
  expressApp.use(express.json());

  // Allow camera access on http:// for mobile scanner
  expressApp.use((req, res, next) => {
    res.setHeader('Permissions-Policy', 'camera=*, microphone=*');
    res.setHeader('Feature-Policy', "camera *; microphone *");
    next();
  });

  expressApp.use(express.static(path.join(__dirname)));

  // ============================================
  // API ROUTES
  // ============================================

  // Health check
  expressApp.get('/api/health', (req, res) => {
    res.json({ status: 'ok', name: 'ZaZ POS Pro', version: '1.0.0', time: new Date().toISOString() });
  });

  // Business info
  expressApp.get('/api/business', (req, res) => {
    try {
      const info = db.prepare('SELECT * FROM business_info WHERE id = 1').get();
      res.json({ success: true, data: info });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Products list
  expressApp.get('/api/products', (req, res) => {
    try {
      const products = db.prepare(
        `SELECT p.*, c.name as cat_name FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.is_active = 1 AND p.is_deleted = 0 ORDER BY p.name ASC`
      ).all();
      res.json({ success: true, data: products });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Product by barcode
  expressApp.get('/api/products/barcode/:barcode', (req, res) => {
    try {
      const product = db.prepare(
        'SELECT * FROM products WHERE barcode = ? AND is_active = 1 AND is_deleted = 0'
      ).get(req.params.barcode);
      if (product) {
        res.json({ success: true, data: product });
      } else {
        res.json({ success: false, error: 'Product not found' });
      }
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Categories list
  expressApp.get('/api/categories', (req, res) => {
    try {
      const cats = db.prepare('SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name').all();
      res.json({ success: true, data: cats });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Mobile scanner page
  expressApp.get('/scanner', (req, res) => {
    res.sendFile(path.join(__dirname, 'scanner.html'));
  });

  // Mobile POS client page
  expressApp.get('/mobile', (req, res) => {
    res.sendFile(path.join(__dirname, 'mobile.html'));
  });

  // API: submit barcode from mobile
  expressApp.post('/api/scan', (req, res) => {
    const { barcode } = req.body;
    if (!barcode) {
      return res.status(400).json({ success: false, error: 'No barcode' });
    }
    try {
      // Find product
      const product = db.prepare(
        'SELECT id, name, sell_price, stock_qty, track_stock FROM products WHERE barcode = ? AND is_active = 1 AND is_deleted = 0'
      ).get(barcode);

      // Emit to main window via socket
      if (io) {
        io.emit('barcode:scanned', { barcode, source: 'mobile', time: Date.now(), product: product || null });
      }
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('product:scanned', { barcode, source: 'mobile' });
      }
      res.json({ success: true, product: product || null });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // ============================================
  // SOCKET.IO — Real-time multi-device
  // ============================================
  httpServer = http.createServer(expressApp);

  const { Server } = require('socket.io');
  io = new Server(httpServer, {
    cors: { origin: '*', methods: ['GET', 'POST'] }
  });

  // Track connected devices
  const connectedDevices = new Map();

  io.on('connection', (socket) => {
    console.log('[SOCKET] Device connected:', socket.id);

    // Device registers itself
    socket.on('device:register', (data) => {
      connectedDevices.set(socket.id, {
        id: socket.id,
        name: data.name || 'Mobile',
        type: data.type || 'mobile',
        connectedAt: new Date().toISOString()
      });
      // Broadcast device list to all
      io.emit('devices:list', Array.from(connectedDevices.values()));
      // Notify main window
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('device:connected', {
          id: socket.id,
          name: data.name,
          count: connectedDevices.size
        });
      }
    });

    // Mobile sends barcode
    socket.on('barcode:scan', (data) => {
      console.log('[SOCKET] Barcode from mobile:', data.barcode);
      const product = db.prepare(
        'SELECT id, name, sell_price, stock_qty, track_stock FROM products WHERE barcode = ? AND is_active = 1 AND is_deleted = 0'
      ).get(data.barcode);

      // Send product info back to the scanning device
      socket.emit('barcode:result', {
        barcode: data.barcode,
        found: !!product,
        product: product || null
      });

      // Notify main PC
      io.emit('barcode:scanned', { barcode: data.barcode, source: 'mobile', device: socket.id, time: Date.now() });
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('product:scanned', { barcode: data.barcode, source: 'mobile' });
      }
    });

    // Mobile requests product list
    socket.on('products:request', () => {
      try {
        const products = db.prepare(
          `SELECT p.id, p.name, p.barcode, p.sell_price, p.stock_qty, p.track_stock, p.low_stock_threshold, p.category_id, c.name as cat_name
           FROM products p LEFT JOIN categories c ON p.category_id = c.id
           WHERE p.is_active = 1 AND p.is_deleted = 0 ORDER BY p.name ASC`
        ).all();
        socket.emit('products:list', products);
      } catch (e) {
        socket.emit('products:list', []);
      }
    });

    // Cart sync — mobile sends its cart, broadcast to others
    socket.on('cart:sync', (cartData) => {
      socket.broadcast.emit('cart:updated', {
        deviceId: socket.id,
        deviceName: (connectedDevices.get(socket.id) || {}).name || 'Mobile',
        cart: cartData
      });
    });

    // Sale completed from mobile
    socket.on('sale:complete', (saleData) => {
      io.emit('sale:completed', {
        deviceId: socket.id,
        deviceName: (connectedDevices.get(socket.id) || {}).name || 'Mobile',
        sale: saleData
      });
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('cart:updated', { source: 'mobile_sale' });
      }
    });

    // Request devices list
    socket.on('devices:request', () => {
      socket.emit('devices:list', Array.from(connectedDevices.values()));
    });

    socket.on('disconnect', () => {
      console.log('[SOCKET] Device disconnected:', socket.id);
      connectedDevices.delete(socket.id);
      io.emit('devices:list', Array.from(connectedDevices.values()));
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('device:disconnected', {
          id: socket.id,
          count: connectedDevices.size
        });
      }
    });
  });

  httpServer.listen(SERVER_PORT, '0.0.0.0', () => {
    const ip = getLocalIP();
    console.log(`[SERVER] Running on http://${ip}:${SERVER_PORT}`);
  });
}

// ============================================
// GET LOCAL IP
// ============================================
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

// ============================================
// IPC HANDLERS
// ============================================
function registerIpcHandlers() {

  // --- App Info ---
  ipcMain.handle('app:info', () => {
    return {
      version: '1.0.0',
      name: 'ZaZ POS Pro',
      ip: getLocalIP(),
      port: SERVER_PORT,
      dbConnected: db !== null
    };
  });

  // --- Database: Generic query ---
  ipcMain.handle('db:get', (event, sql, params = []) => {
    try {
      return { success: true, data: db.prepare(sql).get(...params) };
    } catch (err) {
      console.error('[DB:GET]', err.message);
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('db:all', (event, sql, params = []) => {
    try {
      return { success: true, data: db.prepare(sql).all(...params) };
    } catch (err) {
      console.error('[DB:ALL]', err.message);
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('db:run', (event, sql, params = []) => {
    try {
      const result = db.prepare(sql).run(...params);
      return { success: true, data: { changes: result.changes, lastInsertRowid: result.lastInsertRowid } };
    } catch (err) {
      console.error('[DB:RUN]', err.message);
      return { success: false, error: err.message };
    }
  });

  // --- Business Info ---
  ipcMain.handle('business:get', () => {
    try {
      const info = db.prepare('SELECT * FROM business_info WHERE id = 1').get();
      return { success: true, data: info };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('business:update', (event, data) => {
    try {
      const fields = Object.keys(data);
      const sets = fields.map(f => `${f} = ?`).join(', ');
      const values = fields.map(f => data[f]);
      db.prepare(`UPDATE business_info SET ${sets}, updated_at = datetime('now','localtime') WHERE id = 1`).run(...values);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  // --- App Settings ---
  ipcMain.handle('settings:get', () => {
    try {
      const settings = db.prepare('SELECT * FROM app_settings WHERE id = 1').get();
      return { success: true, data: settings };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  ipcMain.handle('settings:update', (event, data) => {
    try {
      const fields = Object.keys(data);
      const sets = fields.map(f => `${f} = ?`).join(', ');
      const values = fields.map(f => data[f]);
      db.prepare(`UPDATE app_settings SET ${sets}, updated_at = datetime('now','localtime') WHERE id = 1`).run(...values);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  // --- Network Info ---
  ipcMain.handle('network:info', () => {
    return {
      ip: getLocalIP(),
      port: SERVER_PORT,
      url: `http://${getLocalIP()}:${SERVER_PORT}`
    };
  });

  // --- Auto Update ---
  ipcMain.handle('update:check', async () => {
    try {
      const result = await autoUpdater.checkForUpdates();
      return { success: true, version: result?.updateInfo?.version || null };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  ipcMain.handle('update:install', () => {
    autoUpdater.quitAndInstall(false, true);
  });

  // ============================================
  // STOCK SYSTEM — Transaction-safe operations
  // ============================================

  /**
   * stock:deduct — Atomically deduct stock for a sale
   * Params: items = [{ product_id, qty }]
   * Returns: { success, errors[] }
   * Uses SQLite transaction — all or nothing
   */
  ipcMain.handle('stock:deduct', (event, items) => {
    try {
      const errors = [];

      // Pre-validate all items BEFORE transaction
      for (const item of items) {
        const product = db.prepare(
          'SELECT id, name, stock_qty, track_stock FROM products WHERE id = ? AND is_deleted = 0'
        ).get(item.product_id);

        if (!product) {
          errors.push({ product_id: item.product_id, error: 'Product not found' });
          continue;
        }
        if (product.track_stock && product.stock_qty < item.qty) {
          errors.push({
            product_id: item.product_id,
            name: product.name,
            available: product.stock_qty,
            requested: item.qty,
            error: `Not enough stock for "${product.name}" (have ${product.stock_qty}, need ${item.qty})`
          });
        }
      }

      if (errors.length > 0) {
        return { success: false, errors };
      }

      // Execute atomic transaction
      const deductTransaction = db.transaction((saleItems, refId) => {
        for (const item of saleItems) {
          const product = db.prepare(
            'SELECT id, stock_qty, track_stock FROM products WHERE id = ?'
          ).get(item.product_id);

          if (!product || !product.track_stock) continue;

          const qtyBefore = product.stock_qty;
          const qtyAfter = qtyBefore - item.qty;

          // Deduct stock
          db.prepare(
            'UPDATE products SET stock_qty = ?, updated_at = datetime("now","localtime") WHERE id = ?'
          ).run(qtyAfter, item.product_id);

          // Log history
          db.prepare(
            `INSERT INTO stock_history (product_id, type, qty_change, qty_before, qty_after, reference_id, reason)
             VALUES (?, 'sale', ?, ?, ?, ?, 'Sale deduction')`
          ).run(item.product_id, -item.qty, qtyBefore, qtyAfter, refId || '');
        }
      });

      deductTransaction(items, items._refId || '');
      return { success: true };

    } catch (err) {
      console.error('[STOCK:DEDUCT]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * stock:adjust — Add or remove stock manually
   * Params: { product_id, qty_change (+/-), reason }
   */
  ipcMain.handle('stock:adjust', (event, { product_id, qty_change, reason }) => {
    try {
      const result = db.transaction(() => {
        const product = db.prepare(
          'SELECT id, name, stock_qty, track_stock FROM products WHERE id = ? AND is_deleted = 0'
        ).get(product_id);

        if (!product) throw new Error('Product not found');
        if (!product.track_stock) throw new Error('Stock tracking disabled for this product');

        const qtyBefore = product.stock_qty;
        const qtyAfter = qtyBefore + qty_change;

        if (qtyAfter < 0) {
          throw new Error(`Cannot reduce below 0 (current: ${qtyBefore}, change: ${qty_change})`);
        }

        db.prepare(
          'UPDATE products SET stock_qty = ?, updated_at = datetime("now","localtime") WHERE id = ?'
        ).run(qtyAfter, product_id);

        db.prepare(
          `INSERT INTO stock_history (product_id, type, qty_change, qty_before, qty_after, reason)
           VALUES (?, 'adjustment', ?, ?, ?, ?)`
        ).run(product_id, qty_change, qtyBefore, qtyAfter, reason || 'Manual adjustment');

        return { name: product.name, qtyBefore, qtyAfter };
      })();

      return { success: true, data: result };

    } catch (err) {
      console.error('[STOCK:ADJUST]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * stock:damage — Record damaged/lost stock
   * Params: { product_id, qty, reason }
   */
  ipcMain.handle('stock:damage', (event, { product_id, qty, reason }) => {
    try {
      const result = db.transaction(() => {
        const product = db.prepare(
          'SELECT id, name, stock_qty, track_stock FROM products WHERE id = ? AND is_deleted = 0'
        ).get(product_id);

        if (!product) throw new Error('Product not found');
        if (!product.track_stock) throw new Error('Stock tracking disabled');
        if (product.stock_qty < qty) {
          throw new Error(`Cannot damage ${qty} — only ${product.stock_qty} in stock`);
        }

        const qtyBefore = product.stock_qty;
        const qtyAfter = qtyBefore - qty;

        db.prepare(
          'UPDATE products SET stock_qty = ?, updated_at = datetime("now","localtime") WHERE id = ?'
        ).run(qtyAfter, product_id);

        db.prepare(
          'INSERT INTO damage_stock (product_id, qty, reason) VALUES (?, ?, ?)'
        ).run(product_id, qty, reason || 'Damaged');

        db.prepare(
          `INSERT INTO stock_history (product_id, type, qty_change, qty_before, qty_after, reason)
           VALUES (?, 'damage', ?, ?, ?, ?)`
        ).run(product_id, -qty, qtyBefore, qtyAfter, reason || 'Damaged stock');

        return { name: product.name, qtyBefore, qtyAfter };
      })();

      return { success: true, data: result };

    } catch (err) {
      console.error('[STOCK:DAMAGE]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * stock:restore — Reverse a sale's stock deduction (for void)
   * Params: sale_id
   */
  ipcMain.handle('stock:restore', (event, sale_id) => {
    try {
      db.transaction(() => {
        const items = db.prepare(
          'SELECT product_id, qty FROM sale_items WHERE sale_id = ?'
        ).all(sale_id);

        for (const item of items) {
          const product = db.prepare(
            'SELECT id, stock_qty, track_stock FROM products WHERE id = ?'
          ).get(item.product_id);

          if (!product || !product.track_stock) continue;

          const qtyBefore = product.stock_qty;
          const qtyAfter = qtyBefore + item.qty;

          db.prepare(
            'UPDATE products SET stock_qty = ?, updated_at = datetime("now","localtime") WHERE id = ?'
          ).run(qtyAfter, item.product_id);

          db.prepare(
            `INSERT INTO stock_history (product_id, type, qty_change, qty_before, qty_after, reference_id, reason)
             VALUES (?, 'void_restore', ?, ?, ?, ?, 'Sale voided — stock restored')`
          ).run(item.product_id, item.qty, qtyBefore, qtyAfter, String(sale_id));
        }
      })();

      return { success: true };

    } catch (err) {
      console.error('[STOCK:RESTORE]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * stock:history — Get stock history for a product or all
   */
  ipcMain.handle('stock:history', (event, { product_id, limit }) => {
    try {
      let sql, params;
      if (product_id) {
        sql = `SELECT sh.*, p.name as product_name FROM stock_history sh
               LEFT JOIN products p ON sh.product_id = p.id
               WHERE sh.product_id = ? ORDER BY sh.created_at DESC LIMIT ?`;
        params = [product_id, limit || 100];
      } else {
        sql = `SELECT sh.*, p.name as product_name FROM stock_history sh
               LEFT JOIN products p ON sh.product_id = p.id
               ORDER BY sh.created_at DESC LIMIT ?`;
        params = [limit || 100];
      }
      return { success: true, data: db.prepare(sql).all(...params) };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  /**
   * stock:low — Get all low-stock products
   */
  ipcMain.handle('stock:low', () => {
    try {
      const data = db.prepare(
        `SELECT p.*, c.name as cat_name FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         WHERE p.is_active = 1 AND p.is_deleted = 0 AND p.track_stock = 1
         AND p.stock_qty <= p.low_stock_threshold
         ORDER BY p.stock_qty ASC`
      ).all();
      return { success: true, data };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  // ============================================
  // BACKUP SYSTEM
  // ============================================

  /**
   * Get backup directory path
   */
  function getBackupDir() {
    const dir = path.join(app.getPath('userData'), 'backups');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  /**
   * backup:create — Create local backup copy of database
   */
  ipcMain.handle('backup:create', (event, label) => {
    try {
      const dbPath = getDbPath();
      const backupDir = getBackupDir();
      const now = new Date();
      const timestamp = now.toISOString().replace(/[:.]/g, '-').substring(0, 19);
      const tag = label ? ('_' + label.replace(/[^a-zA-Z0-9]/g, '_')) : '';
      const filename = `zaz_backup_${timestamp}${tag}.db`;
      const destPath = path.join(backupDir, filename);

      // Checkpoint WAL to ensure all data is flushed to main DB file
      try { db.pragma('wal_checkpoint(TRUNCATE)'); } catch(e) {}

      // Safe file copy
      fs.copyFileSync(dbPath, destPath);

      // Also copy WAL/SHM if they exist (belt and suspenders)
      try {
        if (fs.existsSync(dbPath + '-wal')) fs.copyFileSync(dbPath + '-wal', destPath + '-wal');
        if (fs.existsSync(dbPath + '-shm')) fs.copyFileSync(dbPath + '-shm', destPath + '-shm');
      } catch(e) {}

      const stats = fs.statSync(destPath);
      console.log('[BACKUP] Created:', filename, '(' + (stats.size / 1024).toFixed(1) + ' KB)');
      return {
        success: true,
        data: {
          filename,
          path: destPath,
          size: stats.size,
          date: now.toISOString()
        }
      };
    } catch (err) {
      console.error('[BACKUP:CREATE]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * backup:list — List all local backups
   */
  ipcMain.handle('backup:list', () => {
    try {
      const backupDir = getBackupDir();
      const files = fs.readdirSync(backupDir)
        .filter(f => f.startsWith('zaz_backup_') && f.endsWith('.db'))
        .map(f => {
          const stats = fs.statSync(path.join(backupDir, f));
          return {
            filename: f,
            path: path.join(backupDir, f),
            size: stats.size,
            date: stats.mtime.toISOString()
          };
        })
        .sort((a, b) => b.date.localeCompare(a.date));
      return { success: true, data: files };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  /**
   * backup:restore — Restore database from backup file
   */
  ipcMain.handle('backup:restore', (event, backupPath) => {
    try {
      if (!fs.existsSync(backupPath)) {
        return { success: false, error: 'Backup file not found' };
      }

      const dbPath = getDbPath();

      // Create safety backup of current DB first
      const safetyPath = dbPath + '.pre_restore_' + Date.now();
      fs.copyFileSync(dbPath, safetyPath);

      // Close current DB
      closeDatabase();

      // Copy backup over current DB
      fs.copyFileSync(backupPath, dbPath);

      // Re-initialize
      const newDb = initDatabase();
      db = newDb;

      console.log('[BACKUP] Restored from:', backupPath);
      return { success: true, safetyBackup: safetyPath };
    } catch (err) {
      console.error('[BACKUP:RESTORE]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * backup:delete — Delete a local backup file
   */
  ipcMain.handle('backup:delete', (event, backupPath) => {
    try {
      if (fs.existsSync(backupPath)) {
        fs.unlinkSync(backupPath);
      }
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  /**
   * backup:openFolder — Open backup folder in file explorer
   */
  ipcMain.handle('backup:openFolder', () => {
    const dir = getBackupDir();
    shell.openPath(dir);
    return { success: true, path: dir };
  });

  /**
   * backup:getDbPath — Get current database file path
   */
  ipcMain.handle('backup:getDbPath', () => {
    return { success: true, path: getDbPath() };
  });

  /**
   * backup:exportFile — Export backup to user-chosen location
   */
  ipcMain.handle('backup:exportFile', async (event, sourcePath) => {
    try {
      const result = await dialog.showSaveDialog(mainWindow, {
        title: 'Export Backup',
        defaultPath: path.basename(sourcePath),
        filters: [{ name: 'Database', extensions: ['db'] }]
      });
      if (result.canceled) return { success: false, error: 'Cancelled' };
      fs.copyFileSync(sourcePath, result.filePath);
      return { success: true, path: result.filePath };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  /**
   * backup:importFile — Import backup from user-chosen file
   */
  ipcMain.handle('backup:importFile', async () => {
    try {
      const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Import Backup',
        filters: [{ name: 'Database', extensions: ['db'] }],
        properties: ['openFile']
      });
      if (result.canceled || result.filePaths.length === 0) {
        return { success: false, error: 'Cancelled' };
      }
      const src = result.filePaths[0];
      // Copy to backup dir
      const backupDir = getBackupDir();
      const filename = 'zaz_backup_imported_' + Date.now() + '.db';
      const dest = path.join(backupDir, filename);
      fs.copyFileSync(src, dest);
      return { success: true, data: { filename, path: dest } };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  /**
   * Google Drive — Upload backup
   * Uses service-free OAuth2 via Electron shell for browser auth
   */
  ipcMain.handle('gdrive:upload', async (event, { filePath, accessToken }) => {
    try {
      const { google } = require('googleapis');
      const oauth2Client = new google.auth.OAuth2();
      oauth2Client.setCredentials({ access_token: accessToken });

      const drive = google.drive({ version: 'v3', auth: oauth2Client });
      const filename = path.basename(filePath);
      const fileSize = fs.statSync(filePath).size;

      // Check if file already exists in Drive
      const existing = await drive.files.list({
        q: `name='${filename}' and trashed=false`,
        spaces: 'drive',
        fields: 'files(id,name)'
      });

      let result;
      if (existing.data.files && existing.data.files.length > 0) {
        // Update existing
        result = await drive.files.update({
          fileId: existing.data.files[0].id,
          media: { body: fs.createReadStream(filePath) }
        });
      } else {
        // Create new
        result = await drive.files.create({
          requestBody: { name: filename, mimeType: 'application/octet-stream' },
          media: { mimeType: 'application/octet-stream', body: fs.createReadStream(filePath) },
          fields: 'id,name,size'
        });
      }

      console.log('[GDRIVE] Uploaded:', filename);
      return { success: true, fileId: result.data.id, name: filename };
    } catch (err) {
      console.error('[GDRIVE:UPLOAD]', err.message);
      return { success: false, error: err.message };
    }
  });

  /**
   * Google Drive — List ZaZ backups
   */
  ipcMain.handle('gdrive:list', async (event, accessToken) => {
    try {
      const { google } = require('googleapis');
      const oauth2Client = new google.auth.OAuth2();
      oauth2Client.setCredentials({ access_token: accessToken });

      const drive = google.drive({ version: 'v3', auth: oauth2Client });
      const res = await drive.files.list({
        q: "name contains 'zaz_backup_' and trashed=false",
        spaces: 'drive',
        fields: 'files(id,name,size,modifiedTime)',
        orderBy: 'modifiedTime desc',
        pageSize: 20
      });

      return { success: true, data: res.data.files || [] };
    } catch (err) {
      return { success: false, error: err.message };
    }
  });

  /**
   * Google Drive — Download backup
   */
  ipcMain.handle('gdrive:download', async (event, { fileId, fileName, accessToken }) => {
    try {
      const { google } = require('googleapis');
      const oauth2Client = new google.auth.OAuth2();
      oauth2Client.setCredentials({ access_token: accessToken });

      const drive = google.drive({ version: 'v3', auth: oauth2Client });
      const backupDir = getBackupDir();
      const destPath = path.join(backupDir, fileName || 'gdrive_backup.db');

      const res = await drive.files.get({ fileId, alt: 'media' }, { responseType: 'stream' });

      return new Promise((resolve, reject) => {
        const dest = fs.createWriteStream(destPath);
        res.data.pipe(dest);
        dest.on('finish', () => {
          console.log('[GDRIVE] Downloaded:', fileName);
          resolve({ success: true, path: destPath });
        });
        dest.on('error', (err) => reject({ success: false, error: err.message }));
      });
    } catch (err) {
      console.error('[GDRIVE:DOWNLOAD]', err.message);
      return { success: false, error: err.message };
    }
  });

  // ============================================
}

// ============================================
// APP LIFECYCLE
// ============================================
app.whenReady().then(() => {
  console.log('[APP] Starting ZaZ POS Pro...');

  // 1. Init database
  db = initDatabase();
  console.log('[APP] Database ready');

  // 2. Register IPC
  registerIpcHandlers();
  console.log('[APP] IPC handlers registered');

  // 3. Start Express server
  startExpressServer();

  // 4. Create window
  createMainWindow();

  // 5. Start auto-updater (production only)
  if (app.isPackaged) {
    initAutoUpdater();
  } else {
    console.log('[UPDATER] Skipped — running in dev mode');
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  closeDatabase();
  if (httpServer) httpServer.close();
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  closeDatabase();
  if (httpServer) httpServer.close();
});

process.on('uncaughtException', (err) => {
  console.error('[CRASH] Uncaught exception:', err);
});

process.on('unhandledRejection', (err) => {
  console.error('[CRASH] Unhandled rejection:', err);
});
