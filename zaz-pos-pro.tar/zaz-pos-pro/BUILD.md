# ZaZ POS Pro — Build Guide

## Prerequisites

- **Node.js 18+** (LTS): https://nodejs.org
- **Windows 10/11** (for .exe build)
- **Python** (auto-installed with node-gyp for native modules)

---

## Run from Source

```bash
cd zaz-pos-pro
npm install
npm start
```

App opens fullscreen on the Sell screen.

---

## Build Windows .exe Installer

### Step 1: Install
```bash
npm install
```

### Step 2: Convert icon (one time)
Convert `assets/icon.png` to `assets/icon.ico` using:
- https://convertico.com
- Or any PNG→ICO converter (256x256)

### Step 3: Build
```bash
npm run build
```

**Output:** `dist/ZaZ POS Pro Setup 1.0.0.exe`

### Quick test (no installer):
```bash
npm run build:dir
```
**Output:** `dist/win-unpacked/ZaZ POS Pro.exe`

---

## If native module errors:
```bash
npm run rebuild
```
Or:
```bash
npx electron-rebuild -f -w better-sqlite3
```

---

## Ports & Network

| Port | Service |
|------|---------|
| 3456 | Express server (mobile POS + scanner) |

Allow port 3456 through Windows Firewall for mobile access.

## Mobile Access (same WiFi)

| URL | Purpose |
|-----|---------|
| `http://<IP>:3456/mobile` | Full POS terminal |
| `http://<IP>:3456/scanner` | Barcode scanner only |

IP shown in Settings → Network.

## Database Location

| File | Path |
|------|------|
| Database | `%APPDATA%/zaz-pos-pro/zaz_pos_pro.db` |
| Backups | `%APPDATA%/zaz-pos-pro/backups/` |

## Default Credentials

| | Value |
|-|-------|
| Owner Password | `65244342726` |
| Client PIN | Not set |

---

## Project Structure

```
zaz-pos-pro/
├── main.js           # Electron main process
├── preload.js        # Secure API bridge
├── renderer.js       # All UI logic (19 modules)
├── index.html        # App shell (11 pages)
├── style.css         # All styles
├── mobile.html       # Mobile POS client
├── scanner.html      # Mobile barcode scanner
├── package.json      # Dependencies + build config
├── assets/
│   └── icon.png      # App icon
└── database/
    └── db.js         # SQLite schema (13 tables)
```
