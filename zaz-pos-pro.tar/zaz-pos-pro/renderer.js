/**
 * ZaZ POS Pro - Renderer Process
 * Handles: UI logic, navigation, dashboard, status bar
 * Runs in browser context with api bridge from preload
 */

// ============================================
// APP STATE
// ============================================
const AppState = {
  currentPage: 'sell',
  appInfo: null,
  businessInfo: null,
  settings: null,
  initialized: false
};

// ============================================
// API FALLBACK — allows preview without Electron
// ============================================
if (!window.api) {
  console.warn('[ZaZ POS Pro] Running outside Electron — using mock API');
  const mockResult = { success: true, data: null };
  const mockAll = { success: true, data: [] };
  window.api = {
    getAppInfo: async () => ({ version: '1.0.0', name: 'ZaZ POS Pro', ip: '127.0.0.1', port: 3456, dbConnected: false }),
    dbGet: async () => mockResult,
    dbAll: async () => mockAll,
    dbRun: async () => ({ success: true, data: { changes: 0, lastInsertRowid: 0 } }),
    getBusiness: async () => mockResult,
    updateBusiness: async () => mockResult,
    getSettings: async () => ({ success: true, data: { client_pin: '', pin_required: 0 } }),
    updateSettings: async () => mockResult,
    getNetworkInfo: async () => ({ ip: '127.0.0.1', port: 3456, url: 'http://127.0.0.1:3456' }),
    stockDeduct: async () => ({ success: true }),
    stockAdjust: async () => ({ success: true, data: { name: '', qtyBefore: 0, qtyAfter: 0 } }),
    stockDamage: async () => ({ success: true, data: { name: '', qtyBefore: 0, qtyAfter: 0 } }),
    stockRestore: async () => mockResult,
    stockHistory: async () => mockAll,
    stockLow: async () => mockAll,
    gdriveUpload: async () => ({ success: false, error: 'Not in Electron' }),
    gdriveList: async () => mockAll,
    gdriveDownload: async () => ({ success: false, error: 'Not in Electron' }),
    backupCreate: async () => ({ success: true, data: { filename: 'mock_backup.db', path: '', size: 0, date: new Date().toISOString() } }),
    backupList: async () => mockAll,
    backupRestore: async () => ({ success: false, error: 'Not in Electron' }),
    backupDelete: async () => mockResult,
    backupOpenFolder: async () => mockResult,
    backupGetDbPath: async () => ({ success: true, path: '' }),
    backupExport: async () => ({ success: false, error: 'Not in Electron' }),
    backupImport: async () => ({ success: false, error: 'Not in Electron' }),
    updateCheck: async () => ({ success: true, data: { currentVersion: '1.0.0', latestVersion: '1.0.0', hasUpdate: false } }),
    updateDownload: async () => ({ success: false, error: 'Not in Electron' }),
    updateInstall: async () => ({ success: false, error: 'Not in Electron' }),
    on: () => {},
    removeListener: () => {}
  };
}

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', async () => {
  try {
    updateLoadingStatus('Connecting to database...');
    const appInfo = await window.api.getAppInfo();
    AppState.appInfo = appInfo;

    updateLoadingStatus('Loading business info...');
    const bizResult = await window.api.getBusiness();
    if (bizResult.success) {
      AppState.businessInfo = bizResult.data;
    }

    updateLoadingStatus('Loading settings...');
    const settingsResult = await window.api.getSettings();
    if (settingsResult.success) {
      AppState.settings = settingsResult.data;
    }

    updateLoadingStatus('Preparing interface...');
    await sleep(300);

    // Init UI systems
    initNavigation();
    initStatusBar();
    loadDashboard();
    Modal.init();
    await SellEngine.init();
    await CategoryManager.init();
    await ProductManager.init();
    await StockManager.init();
    await SettingsManager.init();
    await OwnerManager.init();
    await OwnerManager._applySidebarVisibility();
    await SalesManager.init();
    await ExpenseManager.init();
    await ReportManager.init();
    await BackupManager.init();
    await CustomerManager.init();
    await UpdateManager.init();

    // Show app
    AppState.initialized = true;
    showApp();

    // Check PIN lock after app shows
    await PinLock.check();

    console.log('[ZaZ POS Pro] Ready', appInfo);

  } catch (err) {
    console.error('[INIT ERROR]', err);
    updateLoadingStatus('Error: ' + err.message);
  }
});

// ============================================
// LOADING SCREEN
// ============================================
function updateLoadingStatus(text) {
  const el = document.getElementById('loading-status');
  if (el) el.textContent = text;
}

function showApp() {
  const loadingScreen = document.getElementById('loading-screen');
  const app = document.getElementById('app');

  loadingScreen.classList.add('fade-out');
  app.style.display = 'flex';

  setTimeout(() => {
    loadingScreen.style.display = 'none';
  }, 400);
}

// ============================================
// NAVIGATION
// ============================================
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item[data-page]');

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const page = item.getAttribute('data-page');
      navigateTo(page);
    });
  });
}

function navigateTo(pageId) {
  // Update nav items
  document.querySelectorAll('.nav-item[data-page]').forEach(item => {
    item.classList.toggle('active', item.getAttribute('data-page') === pageId);
  });

  // Update pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.toggle('active', page.id === `page-${pageId}`);
  });

  AppState.currentPage = pageId;

  // Refresh page-specific data
  if (pageId === 'dashboard') loadDashboard();
  if (pageId === 'sell') {
    SellEngine.loadProducts().then(() => SellEngine.renderProducts());
    SellEngine.loadCategories().then(() => SellEngine.renderCategories());
  }
  if (pageId === 'products') {
    ProductManager.load().then(() => { ProductManager.render(); ProductManager.refreshCatFilter(); });
  }
  if (pageId === 'categories') {
    CategoryManager.load().then(() => CategoryManager.render());
  }
  if (pageId === 'inventory') {
    StockManager.load().then(() => { StockManager.render(); StockManager.checkLowStock(); });
  }
  if (pageId === 'customers') {
    CustomerManager.load().then(() => CustomerManager.render());
  }
  if (pageId === 'settings') {
    SettingsManager.loadAll();
    BackupManager.loadList();
  }
  if (pageId === 'sales') {
    SalesManager.load().then(() => SalesManager.render());
  }
  if (pageId === 'expenses') {
    ExpenseManager.load().then(() => ExpenseManager.render());
  }
  if (pageId === 'owner') {
    // Reset gate if was locked
    if (!OwnerManager.unlocked) {
      document.getElementById('owner-gate').style.display = 'flex';
      document.getElementById('owner-panel').style.display = 'none';
      document.getElementById('owner-pw-input').value = '';
      document.getElementById('owner-pw-error').textContent = '';
      setTimeout(() => document.getElementById('owner-pw-input').focus(), 200);
    }
  }
}

// ============================================
// DASHBOARD
// ============================================
async function loadDashboard() {
  // Date display
  const dateEl = document.getElementById('dashboard-date');
  if (dateEl) {
    const now = new Date();
    dateEl.textContent = now.toLocaleDateString('en-US', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });
  }

  // Today's sales
  try {
    const today = new Date().toISOString().split('T')[0];
    const salesResult = await window.api.dbGet(
      "SELECT COALESCE(SUM(total), 0) as total, COUNT(*) as count FROM sales WHERE date(created_at) = ? AND is_void = 0",
      [today]
    );
    if (salesResult.success && salesResult.data) {
      document.getElementById('dash-sales-today').textContent = formatCurrency(salesResult.data.total);
      document.getElementById('dash-orders-today').textContent = salesResult.data.count;
    }
  } catch (e) {
    console.warn('[DASHBOARD] Sales query:', e.message);
  }

  // Product count
  try {
    const prodResult = await window.api.dbGet(
      "SELECT COUNT(*) as count FROM products WHERE is_active = 1 AND is_deleted = 0"
    );
    if (prodResult.success && prodResult.data) {
      document.getElementById('dash-products-count').textContent = prodResult.data.count;
    }
  } catch (e) {
    console.warn('[DASHBOARD] Products query:', e.message);
  }

  // Low stock
  try {
    const lowResult = await window.api.dbGet(
      "SELECT COUNT(*) as count FROM products WHERE is_active = 1 AND is_deleted = 0 AND track_stock = 1 AND stock_qty <= low_stock_threshold"
    );
    if (lowResult.success && lowResult.data) {
      document.getElementById('dash-low-stock').textContent = lowResult.data.count;
    }
  } catch (e) {
    console.warn('[DASHBOARD] Low stock query:', e.message);
  }
}

// ============================================
// STATUS BAR
// ============================================
function initStatusBar() {
  updateStatusTime();
  setInterval(updateStatusTime, 1000);
  updateNetworkStatus();
  initUpdateListener();
}

function updateStatusTime() {
  const el = document.getElementById('status-time');
  if (el) {
    const now = new Date();
    el.textContent = now.toLocaleTimeString('en-US', {
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    });
  }
}

async function updateNetworkStatus() {
  try {
    const info = await window.api.getNetworkInfo();
    const el = document.getElementById('status-network');
    if (el && info) {
      el.textContent = `IP: ${info.ip}:${info.port}`;
    }
  } catch (e) {
    console.warn('[STATUS] Network info:', e.message);
  }
}

// ============================================
// AUTO-UPDATE LISTENER
// ============================================
function initUpdateListener() {
  if (!window.api || !window.api.on) return;

  const bar = document.getElementById('update-bar');
  const text = document.getElementById('update-bar-text');
  const progress = document.getElementById('update-bar-progress');
  const fill = document.getElementById('update-bar-fill');
  const btn = document.getElementById('update-bar-btn');
  const dismiss = document.getElementById('update-bar-dismiss');

  if (!bar) return;

  window.api.on('update:status', (data) => {
    switch (data.status) {
      case 'checking':
        // Silent — don't show bar
        break;

      case 'available':
        bar.style.display = 'flex';
        bar.className = 'update-bar';
        text.textContent = `Update v${data.version} available — downloading...`;
        progress.style.display = 'block';
        fill.style.width = '0%';
        btn.style.display = 'none';
        break;

      case 'downloading':
        bar.style.display = 'flex';
        text.textContent = `Downloading update... ${data.percent}%`;
        progress.style.display = 'block';
        fill.style.width = data.percent + '%';
        btn.style.display = 'none';
        break;

      case 'downloaded':
        bar.style.display = 'flex';
        bar.className = 'update-bar downloaded';
        text.textContent = `v${data.version} ready — restart to install`;
        progress.style.display = 'none';
        btn.style.display = 'block';
        btn.textContent = 'Restart Now';
        break;

      case 'up-to-date':
        // Silent
        break;

      case 'error':
        // Silent — don't bother user with update errors
        console.warn('[UPDATE] Error:', data.error);
        break;
    }
  });

  // Restart button
  if (btn) {
    btn.addEventListener('click', () => {
      window.api.updateInstall();
    });
  }

  // Dismiss
  if (dismiss) {
    dismiss.addEventListener('click', () => {
      bar.style.display = 'none';
    });
  }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function formatCurrency(amount, currency = 'SAR') {
  const num = parseFloat(amount) || 0;
  return num.toFixed(2);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Safe event binding — prevents crash if element missing
function bindClick(id, handler) {
  const el = document.getElementById(id);
  if (el) el.addEventListener('click', handler);
}

function bindChange(id, handler) {
  const el = document.getElementById(id);
  if (el) el.addEventListener('change', handler);
}

function bindInput(id, handler) {
  const el = document.getElementById(id);
  if (el) el.addEventListener('input', handler);
}

// ============================================
// KEYBOARD SHORTCUTS (Global)
// ============================================
document.addEventListener('keydown', (e) => {
  // F1 = Dashboard
  if (e.key === 'F1') {
    e.preventDefault();
    navigateTo('dashboard');
  }
  // F2 = Sell (and focus search)
  if (e.key === 'F2') {
    e.preventDefault();
    navigateTo('sell');
    setTimeout(() => {
      const el = document.getElementById('sell-search');
      if (el) el.focus();
    }, 100);
  }
  // F3 = Products
  if (e.key === 'F3') {
    e.preventDefault();
    navigateTo('products');
  }

  // Sell-page-only shortcuts
  if (AppState.currentPage === 'sell') {
    // ESC = Clear cart
    if (e.key === 'Escape') {
      e.preventDefault();
      SellEngine.clearCart();
    }
    // ENTER = Pay (if cart has items)
    if (e.key === 'Enter') {
      const searchEl = document.getElementById('sell-search');
      // If search is focused and has value, let search handle it
      if (document.activeElement === searchEl && searchEl.value.trim()) {
        return; // barcode handler takes over
      }
      if (SellEngine.cart.length > 0) {
        e.preventDefault();
        SellEngine.openPaymentModal();
      }
    }
  }
});

// ============================================
// BARCODE SCANNER — USB + Mobile + Duplicate Prevention
// ============================================
const BarcodeScanner = {
  buffer: '',                // keystroke buffer for USB scanner
  bufferTimeout: null,       // timer to flush buffer
  _lastKeyTime: 0,           // timestamp of last keystroke
  lastCode: '',              // last scanned barcode
  lastTime: 0,               // timestamp of last scan
  TYPING_SPEED: 50,          // max ms between chars (USB scanners type ~10-30ms/char)
  COOLDOWN: 600,             // ms cooldown between same barcode
  DUPLICATE_WINDOW: 1200,    // ms to block exact duplicate
  MIN_LENGTH: 3,             // minimum barcode length
  active: false,
  onScan: null,              // callback(barcode, source)

  // ============================================
  // START — attach global keydown listener
  // ============================================
  start(callback) {
    this.onScan = callback;
    this.active = true;

    // USB scanner interceptor — catches rapid keystrokes anywhere on page
    document.addEventListener('keydown', this._handleKeyDown.bind(this), true);

    // Listen for mobile scans via IPC
    if (window.api && window.api.on) {
      window.api.on('product:scanned', (data) => {
        if (data && data.barcode) {
          this._processBarcode(data.barcode, 'mobile');
        }
      });
    }

    console.log('[SCANNER] Barcode scanner started');
  },

  // ============================================
  // USB SCANNER DETECTION — Global Keydown
  // ============================================
  _handleKeyDown(e) {
    if (!this.active) return;

    // Ignore if typing in a real input (except the barcode search field)
    const tag = e.target.tagName;
    const isSellSearch = e.target.id === 'sell-search';
    const isInput = (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT');

    // If user is in an input that is NOT the sell search, let normal typing happen
    if (isInput && !isSellSearch) return;

    // If on sell page and search is focused, the search handler deals with Enter
    if (isSellSearch && e.key === 'Enter') return;

    // Collect printable characters into buffer
    if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
      const now = Date.now();

      // If too much time passed since last char, reset buffer (human typing)
      if (this.buffer.length > 0 && (now - this._lastKeyTime) > this.TYPING_SPEED) {
        this.buffer = '';
      }

      this._lastKeyTime = now;
      this.buffer += e.key;

      // Clear existing timeout
      if (this.bufferTimeout) clearTimeout(this.bufferTimeout);

      // Set timeout — if no more chars come, check if it's a barcode
      this.bufferTimeout = setTimeout(() => {
        this._flushBuffer();
      }, this.TYPING_SPEED + 20);

      // If we're NOT in sell-search, prevent character from appearing elsewhere
      if (!isSellSearch && AppState.currentPage === 'sell') {
        // Don't prevent — let buffer collect silently
      }

      return;
    }

    // Enter key = finalize barcode from buffer
    if (e.key === 'Enter' && this.buffer.length >= this.MIN_LENGTH) {
      e.preventDefault();
      e.stopPropagation();
      if (this.bufferTimeout) clearTimeout(this.bufferTimeout);
      this._flushBuffer();
      return;
    }
  },

  // ============================================
  // FLUSH BUFFER — Check if it's a valid barcode
  // ============================================
  _flushBuffer() {
    const code = this.buffer.trim();
    this.buffer = '';

    if (code.length < this.MIN_LENGTH) return;

    // Only process if it was typed fast (scanner speed, not human)
    // USB scanners output entire barcode in <100ms total
    this._processBarcode(code, 'usb');
  },

  // ============================================
  // PROCESS BARCODE — Duplicate check + fire callback
  // ============================================
  _processBarcode(code, source) {
    const now = Date.now();

    // Exact duplicate within window
    if (code === this.lastCode && (now - this.lastTime) < this.DUPLICATE_WINDOW) {
      console.log('[SCANNER] Duplicate blocked:', code);
      return;
    }

    // General cooldown
    if ((now - this.lastTime) < this.COOLDOWN) {
      console.log('[SCANNER] Cooldown active, code:', code);
      return;
    }

    this.lastCode = code;
    this.lastTime = now;

    console.log('[SCANNER] Barcode detected:', code, 'source:', source);

    if (this.onScan) {
      this.onScan(code, source);
    }
  },

  // ============================================
  // STOP
  // ============================================
  stop() {
    this.active = false;
  }
};


// ============================================
// SELL ENGINE — Complete cart & product logic
// ============================================
const SellEngine = {
  cart: [],              // { id, product_id, name, barcode, price, cost, qty, total }
  products: [],          // cached from DB
  categories: [],        // cached from DB
  selectedCategory: 'all',
  searchTerm: '',
  taxRate: 15,           // percent
  nextCartId: 1,
  selectedCustomer: { id: 1, name: 'Customer General' },
  _audioCtx: null,       // shared AudioContext for beep

  // ---- SVG icons used in rendering ----
  PRODUCT_ICON: '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#b0b4bc" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
  DELETE_ICON: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',

  // ============================================
  // INIT — Load products, categories, wire events
  // ============================================
  async init() {
    await this.loadProducts();
    await this.loadCategories();
    this.renderProducts();
    this.renderCategories();
    this.renderCart();
    this.bindEvents();

    // Start barcode scanner with callback
    BarcodeScanner.start((barcode, source) => {
      this.handleBarcodeScan(barcode, source);
    });

    console.log('[SELL] Engine initialized —', this.products.length, 'products loaded');
  },

  // ============================================
  // LOAD DATA FROM DB
  // ============================================
  async loadProducts() {
    try {
      const result = await window.api.dbAll(
        "SELECT * FROM products WHERE is_active = 1 AND is_deleted = 0 ORDER BY name ASC"
      );
      this.products = (result.success && result.data) ? result.data : [];
    } catch (e) {
      console.error('[SELL] Load products failed:', e);
      this.products = [];
    }
  },

  async loadCategories() {
    try {
      const result = await window.api.dbAll(
        "SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC, name ASC"
      );
      this.categories = (result.success && result.data) ? result.data : [];
    } catch (e) {
      console.error('[SELL] Load categories failed:', e);
      this.categories = [];
    }
  },

  // ============================================
  // RENDER PRODUCTS GRID
  // ============================================
  renderProducts() {
    const grid = document.getElementById('sell-products-grid');
    if (!grid) return;

    let filtered = this.products;

    // Filter by category
    if (this.selectedCategory !== 'all') {
      const catId = parseInt(this.selectedCategory);
      filtered = filtered.filter(p => p.category_id === catId);
    }

    // Filter by search
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(p =>
        (p.name && p.name.toLowerCase().includes(term)) ||
        (p.barcode && p.barcode.toLowerCase().includes(term)) ||
        (p.sku && p.sku.toLowerCase().includes(term))
      );
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
          <div style="font-size: 40px; margin-bottom: 10px; opacity: 0.3;">📦</div>
          <div style="font-size: 14px; font-weight: 600; color: #9CA3AF;">No products found</div>
          <div style="font-size: 12px; color: #D1D5DB; margin-top: 4px;">
            ${this.products.length === 0 ? 'Add products in the Products page first' : 'Try a different search or category'}
          </div>
        </div>`;
      return;
    }

    grid.innerHTML = filtered.map(p => {
      const isLow = p.track_stock && p.stock_qty <= p.low_stock_threshold;
      return `
        <div class="sell-product-card${isLow ? ' sell-product-card--low' : ''}" data-product-id="${p.id}">
          <div class="sell-product-img">${this.PRODUCT_ICON}</div>
          <div class="sell-product-name">${this.escHtml(p.name)}</div>
          <div class="sell-product-price">${parseFloat(p.sell_price).toFixed(2)}</div>
          <div class="sell-product-stock${isLow ? ' sell-product-stock--low' : ''}">Stock: ${Math.floor(p.stock_qty)}</div>
        </div>`;
    }).join('');
  },

  // ============================================
  // RENDER CATEGORIES
  // ============================================
  renderCategories() {
    const container = document.getElementById('sell-categories');
    if (!container) return;

    let html = `<button class="sell-cat-btn${this.selectedCategory === 'all' ? ' active' : ''}" data-cat-id="all">All Items</button>`;
    this.categories.forEach(cat => {
      html += `<button class="sell-cat-btn${this.selectedCategory === String(cat.id) ? ' active' : ''}" data-cat-id="${cat.id}">${this.escHtml(cat.name)}</button>`;
    });
    container.innerHTML = html;
  },

  // ============================================
  // BIND ALL EVENTS
  // ============================================
  bindEvents() {
    // Product card clicks (event delegation)
    const grid = document.getElementById('sell-products-grid');
    if (grid) {
      grid.addEventListener('click', (e) => {
        const card = e.target.closest('.sell-product-card');
        if (!card) return;
        const productId = parseInt(card.getAttribute('data-product-id'));
        if (productId) this.addToCart(productId);
      });
    }

    // Category clicks (event delegation)
    const cats = document.getElementById('sell-categories');
    if (cats) {
      cats.addEventListener('click', (e) => {
        const btn = e.target.closest('.sell-cat-btn');
        if (!btn) return;
        this.selectedCategory = btn.getAttribute('data-cat-id');
        this.renderCategories();
        this.renderProducts();
      });
    }

    // Cart clicks (event delegation for +, -, delete)
    const cartList = document.getElementById('sell-cart-items');
    if (cartList) {
      cartList.addEventListener('click', (e) => {
        const row = e.target.closest('.sell-cart-row');
        if (!row) return;
        const cartId = parseInt(row.getAttribute('data-cart-id'));
        if (!cartId) return;

        if (e.target.closest('.sell-qty-plus')) {
          this.changeQty(cartId, 1);
        } else if (e.target.closest('.sell-qty-minus')) {
          this.changeQty(cartId, -1);
        } else if (e.target.closest('.sell-row-delete')) {
          this.removeFromCart(cartId);
        }
      });
    }

    // Search input — live filter (NOT barcode scan; scanner uses BarcodeScanner module)
    const searchInput = document.getElementById('sell-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchTerm = e.target.value;
        this.renderProducts();
      });

      // Enter in search = try barcode lookup, then clear
      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const val = searchInput.value.trim();
          if (val) {
            this.handleBarcodeScan(val, 'search');
            searchInput.value = '';
            this.searchTerm = '';
            this.renderProducts();
          }
        }
      });
    }

    // Clear button
    const clearBtn = document.getElementById('sell-btn-clear');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => this.clearCart());
    }

    // Customer change button
    const custChangeBtn = document.querySelector('.sell-customer-change');
    if (custChangeBtn) {
      custChangeBtn.addEventListener('click', () => this.openCustomerSelect());
    }

    // Hold button — save cart to localStorage for later
    const holdBtn = document.getElementById('sell-btn-hold');
    if (holdBtn) {
      holdBtn.addEventListener('click', () => {
        if (this.cart.length === 0) return;
        const held = JSON.parse(localStorage.getItem('zaz_held_carts') || '[]');
        held.push({
          id: Date.now(),
          items: [...this.cart],
          date: new Date().toISOString(),
          total: this.getTotal()
        });
        localStorage.setItem('zaz_held_carts', JSON.stringify(held));
        this.showToast('Cart held (' + held.length + ' saved)', 'success');
        this.clearCart();
        this._updateHeldCount();
      });
    }

    // Recall held cart button
    const recallBtn = document.getElementById('sell-btn-recall');
    if (recallBtn) {
      recallBtn.addEventListener('click', () => {
        const held = JSON.parse(localStorage.getItem('zaz_held_carts') || '[]');
        if (held.length === 0) { this.showToast('No held carts', 'info'); return; }

        let html = '<div style="max-height:300px;overflow:auto;">';
        held.forEach((h, i) => {
          const d = new Date(h.date);
          const dateStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          const itemNames = h.items.map(x => x.name).join(', ');
          html += `<div style="display:flex;align-items:center;gap:10px;padding:10px;background:#FAFBFC;border:1px solid var(--border-light);border-radius:8px;margin-bottom:6px;cursor:pointer;" onclick="SellEngine._recallCart(${i})">
            <div style="flex:1;min-width:0;">
              <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${this.escHtml(itemNames)}</div>
              <div style="font-size:11px;color:var(--text-light);">${h.items.length} items · ${dateStr}</div>
            </div>
            <div style="font-size:15px;font-weight:800;font-family:var(--font-mono);color:var(--accent-blue);">${parseFloat(h.total).toFixed(2)}</div>
            <button class="pm-act-btn danger" title="Delete" onclick="event.stopPropagation();SellEngine._deleteHeldCart(${i})" style="flex-shrink:0">✕</button>
          </div>`;
        });
        html += '</div>';

        Modal.open('Held Carts (' + held.length + ')', html, () => Modal.close());
        document.getElementById('modal-save').style.display = 'none';
        document.getElementById('modal-cancel').textContent = 'Close';
      });
      this._updateHeldCount();
    }

    // Pay button
    const payBtn = document.getElementById('sell-btn-pay');
    if (payBtn) {
      payBtn.addEventListener('click', () => {
        if (this.cart.length === 0) return;
        this.openPaymentModal();
      });
    }
  },

  // ============================================
  // BARCODE SCAN HANDLER (from any source)
  // ============================================
  handleBarcodeScan(barcode, source) {
    if (!barcode || !barcode.trim()) return;
    barcode = barcode.trim();

    // If not on sell page, switch to it
    if (AppState.currentPage !== 'sell') {
      navigateTo('sell');
    }

    // Find product by exact barcode match
    const product = this.products.find(p => p.barcode && p.barcode === barcode);
    if (product) {
      this.addToCart(product.id);
      this.showToast('✓ ' + product.name, 'success');
      return;
    }

    // Try SKU match
    const bySku = this.products.find(p => p.sku && p.sku === barcode);
    if (bySku) {
      this.addToCart(bySku.id);
      this.showToast('✓ ' + bySku.name, 'success');
      return;
    }

    // Try exact name match (case insensitive)
    const byName = this.products.find(p =>
      p.name && p.name.toLowerCase() === barcode.toLowerCase()
    );
    if (byName) {
      this.addToCart(byName.id);
      this.showToast('✓ ' + byName.name, 'success');
      return;
    }

    // Not found
    this.playBeepError();
    this.showToast('Product not found: ' + barcode, 'error');
  },

  // ============================================
  // ADD TO CART
  // ============================================
  addToCart(productId) {
    const product = this.products.find(p => p.id === productId);
    if (!product) return;

    // Check if already in cart → increase qty
    const existing = this.cart.find(item => item.product_id === productId);
    if (existing) {
      // Check stock
      if (product.track_stock && existing.qty + 1 > product.stock_qty) {
        this.playBeepError();
        this.showToast('Not enough stock for ' + product.name, 'error');
        return;
      }
      existing.qty += 1;
      existing.total = +(existing.qty * existing.price).toFixed(2);
    } else {
      // Check stock for new item
      if (product.track_stock && product.stock_qty < 1) {
        this.playBeepError();
        this.showToast('Out of stock: ' + product.name, 'error');
        return;
      }
      this.cart.push({
        id: this.nextCartId++,
        product_id: product.id,
        name: product.name,
        barcode: product.barcode || '',
        price: parseFloat(product.sell_price),
        cost: parseFloat(product.cost_price),
        qty: 1,
        total: parseFloat(product.sell_price)
      });
    }

    this.renderCart();
    this.playBeep();
  },

  // ============================================
  // CHANGE QTY (+1 or -1)
  // ============================================
  changeQty(cartId, delta) {
    const item = this.cart.find(i => i.id === cartId);
    if (!item) return;

    const newQty = item.qty + delta;

    if (newQty <= 0) {
      this.removeFromCart(cartId);
      return;
    }

    // Check stock on increase
    if (delta > 0) {
      const product = this.products.find(p => p.id === item.product_id);
      if (product && product.track_stock && newQty > product.stock_qty) {
        this.showToast('Not enough stock', 'error');
        return;
      }
    }

    item.qty = newQty;
    item.total = +(item.qty * item.price).toFixed(2);
    this.renderCart();
  },

  // ============================================
  // REMOVE FROM CART
  // ============================================
  removeFromCart(cartId) {
    this.cart = this.cart.filter(i => i.id !== cartId);
    this.renderCart();
  },

  // ============================================
  // CLEAR CART
  // ============================================
  clearCart() {
    if (this.cart.length === 0) return;
    this.cart = [];
    this.nextCartId = 1;
    this.selectedCustomer = { id: 1, name: 'Customer General' };
    const custEl = document.getElementById('sell-customer-name');
    if (custEl) custEl.textContent = 'Customer General';
    this.renderCart();
  },

  // ============================================
  // CALCULATIONS
  // ============================================
  getSubtotal() {
    return this.cart.reduce((sum, item) => sum + item.total, 0);
  },

  getTax() {
    return +(this.getSubtotal() * this.taxRate / 100).toFixed(2);
  },

  getTotal() {
    return +(this.getSubtotal() + this.getTax()).toFixed(2);
  },

  getItemCount() {
    return this.cart.reduce((sum, item) => sum + item.qty, 0);
  },

  // ============================================
  // RENDER CART (items + summary + pay button)
  // ============================================
  renderCart() {
    const container = document.getElementById('sell-cart-items');
    const emptyState = document.getElementById('sell-cart-empty');

    if (!container) return;

    if (this.cart.length === 0) {
      container.querySelectorAll('.sell-cart-row').forEach(el => el.remove());
      if (emptyState) emptyState.style.display = 'flex';
    } else {
      if (emptyState) emptyState.style.display = 'none';

      const html = this.cart.map(item => `
        <div class="sell-cart-row" data-cart-id="${item.id}">
          <div class="sell-row-item">
            <div class="sell-row-name">${this.escHtml(item.name)}</div>
            <div class="sell-row-barcode">${this.escHtml(item.barcode)}</div>
          </div>
          <div class="sell-row-qty">
            <button class="sell-qty-btn sell-qty-minus">−</button>
            <span class="sell-qty-val">${String(item.qty).padStart(2, '0')}</span>
            <button class="sell-qty-btn sell-qty-plus">+</button>
          </div>
          <div class="sell-row-price">${item.price.toFixed(2)}</div>
          <div class="sell-row-total">${item.total.toFixed(2)}</div>
          <button class="sell-row-delete" title="Remove">${this.DELETE_ICON}</button>
        </div>`).join('');

      container.querySelectorAll('.sell-cart-row').forEach(el => el.remove());
      container.insertAdjacentHTML('afterbegin', html);
    }

    this.updateSummary();
  },

  // ============================================
  // UPDATE SUMMARY
  // ============================================
  updateSummary() {
    const subtotal = this.getSubtotal();
    const tax = this.getTax();
    const total = this.getTotal();
    const count = this.getItemCount();

    const setTxt = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setTxt('sell-subtotal', subtotal.toFixed(2));
    setTxt('sell-tax', tax.toFixed(2));
    setTxt('sell-discount', '0.00');
    setTxt('sell-total', total.toFixed(2));
    setTxt('sell-item-count', count + ' item' + (count !== 1 ? 's' : ''));
    setTxt('sell-btn-pay-text', 'Pay  ' + total.toFixed(2));
  },

  // ============================================
  // CUSTOMER SELECTOR FOR SELL SCREEN
  // ============================================
  async openCustomerSelect() {
    const customers = await CustomerManager.getForSelect();
    const options = customers.map(c =>
      `<option value="${c.id}"${c.id === this.selectedCustomer.id ? ' selected' : ''}>${SellEngine.escHtml(c.name)}${c.balance_due > 0 ? ' (Due: '+parseFloat(c.balance_due).toFixed(2)+')' : ''}</option>`
    ).join('');

    const html = `
      <div class="form-row">
        <label class="form-label">Select Customer</label>
        <select class="form-select" id="f-sel-customer" style="font-size:14px;height:42px">${options}</select>
      </div>`;

    Modal.open('Change Customer', html, () => {
      const selId = parseInt(Modal.getVal('f-sel-customer'));
      const cust = customers.find(c => c.id === selId);
      if (cust) {
        this.selectedCustomer = { id: cust.id, name: cust.name };
        const nameEl = document.getElementById('sell-customer-name');
        if (nameEl) nameEl.textContent = cust.name;
      }
      Modal.close();
    });
  },

  // ============================================
  // PAYMENT MODAL — Cash / Card / Split
  // ============================================
  openPaymentModal() {
    if (this.cart.length === 0) return;
    const total = this.getTotal();

    const html = `
      <div style="text-align:center;margin-bottom:16px;">
        <div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;">Amount Due</div>
        <div style="font-size:32px;font-weight:900;font-family:var(--font-mono);color:var(--text-primary);">${total.toFixed(2)} <span style="font-size:14px;font-weight:600;">SAR</span></div>
      </div>
      <div class="form-row">
        <label class="form-label">Payment Method</label>
        <select class="form-select" id="f-pay-method" onchange="SellEngine._onPayMethodChange()">
          <option value="cash">Cash</option>
          <option value="card">Card</option>
          <option value="split">Split (Cash + Card)</option>
        </select>
      </div>
      <div id="f-pay-cash-section">
        <div class="form-row">
          <label class="form-label">Cash Received</label>
          <input class="form-input form-input-mono" id="f-pay-cash" type="number" step="0.01" min="0" value="${total.toFixed(2)}" style="font-size:18px;height:44px;font-weight:700">
        </div>
        <div style="display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap;" id="f-pay-quick-btns">
          <button class="btn btn-ghost" onclick="document.getElementById('f-pay-cash').value='${total.toFixed(2)}'" style="font-family:var(--font-mono)">Exact</button>
          <button class="btn btn-ghost" onclick="document.getElementById('f-pay-cash').value='${(Math.ceil(total / 5) * 5).toFixed(2)}'" style="font-family:var(--font-mono)">${(Math.ceil(total / 5) * 5).toFixed(2)}</button>
          <button class="btn btn-ghost" onclick="document.getElementById('f-pay-cash').value='${(Math.ceil(total / 10) * 10).toFixed(2)}'" style="font-family:var(--font-mono)">${(Math.ceil(total / 10) * 10).toFixed(2)}</button>
          <button class="btn btn-ghost" onclick="document.getElementById('f-pay-cash').value='${(Math.ceil(total / 50) * 50).toFixed(2)}'" style="font-family:var(--font-mono)">${(Math.ceil(total / 50) * 50).toFixed(2)}</button>
          <button class="btn btn-ghost" onclick="document.getElementById('f-pay-cash').value='${(Math.ceil(total / 100) * 100).toFixed(2)}'" style="font-family:var(--font-mono)">${(Math.ceil(total / 100) * 100).toFixed(2)}</button>
        </div>
      </div>
      <div id="f-pay-card-section" style="display:none;">
        <div class="form-row">
          <label class="form-label">Card Amount</label>
          <input class="form-input form-input-mono" id="f-pay-card" type="number" step="0.01" min="0" value="0" style="font-size:16px;height:42px">
        </div>
      </div>
      <div style="background:#F0FFF4;border:1px solid #BBF7D0;border-radius:8px;padding:10px 14px;text-align:center;">
        <div style="font-size:11px;color:#065F46;">Change</div>
        <div style="font-size:22px;font-weight:900;font-family:var(--font-mono);color:#16A34A;" id="f-pay-change">0.00</div>
      </div>`;

    Modal.open('Payment', html, () => this._processPayment());
    document.getElementById('modal-save').textContent = '✓ Complete Sale';
    document.getElementById('modal-save').style.background = '#22C55E';

    // Auto-calculate change on input
    const cashInput = document.getElementById('f-pay-cash');
    const cardInput = document.getElementById('f-pay-card');
    const calcChange = () => {
      const method = document.getElementById('f-pay-method').value;
      const cash = parseFloat(cashInput.value) || 0;
      const card = parseFloat(cardInput.value) || 0;
      let paid = method === 'card' ? card : method === 'split' ? cash + card : cash;
      const change = Math.max(0, paid - total);
      document.getElementById('f-pay-change').textContent = change.toFixed(2);
    };
    cashInput.addEventListener('input', calcChange);
    cardInput.addEventListener('input', calcChange);

    // Focus cash input and select all
    setTimeout(() => { cashInput.focus(); cashInput.select(); }, 150);
  },

  _onPayMethodChange() {
    const method = document.getElementById('f-pay-method').value;
    const total = this.getTotal();
    const cashSection = document.getElementById('f-pay-cash-section');
    const cardSection = document.getElementById('f-pay-card-section');
    const cashInput = document.getElementById('f-pay-cash');
    const cardInput = document.getElementById('f-pay-card');

    if (method === 'cash') {
      cashSection.style.display = 'block';
      cardSection.style.display = 'none';
      cashInput.value = total.toFixed(2);
      cardInput.value = '0';
    } else if (method === 'card') {
      cashSection.style.display = 'none';
      cardSection.style.display = 'block';
      cashInput.value = '0';
      cardInput.value = total.toFixed(2);
    } else { // split
      cashSection.style.display = 'block';
      cardSection.style.display = 'block';
      cashInput.value = '';
      cardInput.value = '';
    }
    // Trigger change recalc
    cashInput.dispatchEvent(new Event('input'));
  },

  async _processPayment() {
    const total = this.getTotal();
    const method = document.getElementById('f-pay-method').value;
    const cash = parseFloat(document.getElementById('f-pay-cash').value) || 0;
    const card = parseFloat(document.getElementById('f-pay-card').value) || 0;

    let paid;
    if (method === 'cash') paid = cash;
    else if (method === 'card') paid = card;
    else paid = cash + card;

    // Validate
    if (paid < total) {
      Modal.showError('Payment (' + paid.toFixed(2) + ') is less than total (' + total.toFixed(2) + ')');
      return;
    }

    const change = Math.max(0, paid - total);
    Modal.close();

    // Complete sale with transaction-safe stock deduction
    const result = await this.completeSale({
      method,
      cash: method === 'card' ? 0 : cash,
      card: method === 'cash' ? 0 : card,
      amount_paid: paid,
      change,
      customer_id: this.selectedCustomer.id,
      due: 0
    });

    if (result.success) {
      this.playBeep();
      this.showToast('Sale completed! ' + result.invoiceNumber, 'success');

      // Build receipt data from saved sale (cart is already cleared)
      const saleR = await window.api.dbGet(
        "SELECT * FROM sales WHERE id = ?", [result.saleId]
      );
      const itemsR = await window.api.dbAll(
        "SELECT * FROM sale_items WHERE sale_id = ?", [result.saleId]
      );

      const savedSale = (saleR.success && saleR.data) ? saleR.data : {};
      const savedItems = (itemsR.success && itemsR.data) ? itemsR.data : [];

      const saleData = {
        invoiceNumber: result.invoiceNumber,
        items: savedItems.map(i => ({
          name: i.product_name,
          qty: i.qty,
          price: i.unit_price,
          total: i.total,
          tax: i.tax_amount || 0
        })),
        subtotal: parseFloat(savedSale.subtotal || 0),
        tax: parseFloat(savedSale.tax_amount || 0),
        total: parseFloat(savedSale.total || result.total),
        method,
        cash: method === 'card' ? 0 : cash,
        card: method === 'cash' ? 0 : card,
        change,
        customer: this.selectedCustomer.name || 'Cash',
        date: savedSale.created_at || new Date().toISOString()
      };

      // Auto-show receipt
      setTimeout(() => ReceiptBuilder.showPreview(saleData), 300);
    }
  },

  // ============================================
  // HELD CART HELPERS
  // ============================================
  _recallCart(index) {
    const held = JSON.parse(localStorage.getItem('zaz_held_carts') || '[]');
    if (index < 0 || index >= held.length) return;

    const heldCart = held[index];
    // Remove from held list
    held.splice(index, 1);
    localStorage.setItem('zaz_held_carts', JSON.stringify(held));

    // If current cart has items, ask first
    if (this.cart.length > 0) {
      if (!confirm('Replace current cart with held cart?')) return;
    }

    // Load held cart
    this.cart = heldCart.items;
    this.nextCartId = Math.max(...this.cart.map(i => i.id), 0) + 1;
    this.renderCart();
    this._updateHeldCount();
    Modal.close();
    this.showToast('Cart recalled', 'success');
  },

  _deleteHeldCart(index) {
    const held = JSON.parse(localStorage.getItem('zaz_held_carts') || '[]');
    held.splice(index, 1);
    localStorage.setItem('zaz_held_carts', JSON.stringify(held));
    this._updateHeldCount();
    // Re-open the list
    const recallBtn = document.getElementById('sell-btn-recall');
    Modal.close();
    if (held.length > 0) {
      setTimeout(() => recallBtn.click(), 100);
    } else {
      this.showToast('No held carts remaining', 'info');
    }
  },

  _updateHeldCount() {
    const held = JSON.parse(localStorage.getItem('zaz_held_carts') || '[]');
    const el = document.getElementById('sell-held-count');
    if (el) el.textContent = held.length > 0 ? held.length : '';
  },

  // ============================================
  // COMPLETE SALE — Transaction-safe stock deduction
  // Called by payment system after payment confirmed
  // ============================================
  async completeSale(paymentData) {
    if (this.cart.length === 0) return { success: false, error: 'Cart is empty' };

    // 1. Build stock deduction items
    const stockItems = this.cart
      .filter(item => {
        const p = this.products.find(x => x.id === item.product_id);
        return p && p.track_stock;
      })
      .map(item => ({ product_id: item.product_id, qty: item.qty }));

    // 2. Atomically deduct stock (transaction-safe, prevents overselling)
    if (stockItems.length > 0) {
      const stockResult = await window.api.stockDeduct(stockItems);
      if (!stockResult.success) {
        // Stock deduction failed — do NOT proceed with sale
        const errMsg = stockResult.errors
          ? stockResult.errors.map(e => e.error).join('; ')
          : stockResult.error;
        this.playBeepError();
        this.showToast('Stock error: ' + errMsg, 'error');
        // Refresh products to get current stock levels
        await this.loadProducts();
        this.renderProducts();
        return { success: false, error: errMsg };
      }
    }

    // 3. Generate invoice number
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const countR = await window.api.dbGet(
      "SELECT COUNT(*) + 1 as num FROM sales WHERE date(created_at) = date('now','localtime')"
    );
    const num = (countR.success && countR.data) ? countR.data.num : 1;
    const invoiceNumber = 'INV-' + dateStr + '-' + String(num).padStart(4, '0');

    // 4. Save sale record
    const subtotal = this.getSubtotal();
    const tax = this.getTax();
    const total = this.getTotal();

    const saleR = await window.api.dbRun(
      `INSERT INTO sales (invoice_number, customer_id, subtotal, tax_amount, discount_amount,
       total, amount_paid, change_amount, payment_method, cash_amount, card_amount, due_amount, status)
       VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, 'completed')`,
      [
        invoiceNumber,
        paymentData.customer_id || 1,
        subtotal, tax, total,
        paymentData.amount_paid || total,
        paymentData.change || 0,
        paymentData.method || 'cash',
        paymentData.cash || 0,
        paymentData.card || 0,
        paymentData.due || 0
      ]
    );

    if (!saleR.success) {
      return { success: false, error: saleR.error };
    }

    const saleId = saleR.data.lastInsertRowid;

    // 5. Save sale items
    for (const item of this.cart) {
      await window.api.dbRun(
        `INSERT INTO sale_items (sale_id, product_id, product_name, barcode, qty, unit_price, cost_price, total)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [saleId, item.product_id, item.name, item.barcode, item.qty, item.price, item.cost, item.total]
      );
    }

    // 6. Clear cart, reset customer, refresh
    this.cart = [];
    this.nextCartId = 1;
    this.selectedCustomer = { id: 1, name: 'Customer General' };
    const custNameEl = document.getElementById('sell-customer-name');
    if (custNameEl) custNameEl.textContent = 'Customer General';
    this.renderCart();
    await this.loadProducts();
    this.renderProducts();

    return { success: true, saleId, invoiceNumber, total };
  },

  // ============================================
  // AUDIO — Shared context + dual-tone beep
  // ============================================
  _getAudioCtx() {
    if (!this._audioCtx) {
      this._audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    // Resume if suspended (browser policy)
    if (this._audioCtx.state === 'suspended') {
      this._audioCtx.resume();
    }
    return this._audioCtx;
  },

  playBeep() {
    try {
      const ctx = this._getAudioCtx();
      const now = ctx.currentTime;

      // Dual-tone success beep: two short rising tones
      const freqs = [1800, 2250];
      freqs.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'square';
        const startAt = now + i * 0.06;
        osc.frequency.setValueAtTime(freq, startAt);
        gain.gain.setValueAtTime(0.08, startAt);
        gain.gain.exponentialRampToValueAtTime(0.001, startAt + 0.07);
        osc.start(startAt);
        osc.stop(startAt + 0.07);
      });
    } catch (e) { /* audio not critical */ }
  },

  playBeepError() {
    try {
      const ctx = this._getAudioCtx();
      const now = ctx.currentTime;

      // Low buzzer for error
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, now);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } catch (e) { /* audio not critical */ }
  },

  // ============================================
  // TOAST NOTIFICATION
  // ============================================
  showToast(msg, type = 'info') {
    const old = document.querySelector('.sell-toast');
    if (old) old.remove();

    const toast = document.createElement('div');
    toast.className = 'sell-toast sell-toast--' + type;
    toast.textContent = msg;
    document.body.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('sell-toast--show'));

    setTimeout(() => {
      toast.classList.remove('sell-toast--show');
      setTimeout(() => toast.remove(), 300);
    }, 2200);
  },

  // ============================================
  // ESCAPE HTML
  // ============================================
  escHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
};


// ============================================
// MODAL SYSTEM
// ============================================
const Modal = {
  _onSave: null,

  open(title, bodyHtml, onSave) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = bodyHtml;
    document.getElementById('modal-error').style.display = 'none';
    document.getElementById('modal-error').textContent = '';
    document.getElementById('modal-overlay').style.display = 'flex';
    this._onSave = onSave;
    // Focus first input
    setTimeout(() => {
      const first = document.querySelector('#modal-body input, #modal-body select');
      if (first) first.focus();
    }, 100);
  },

  close() {
    document.getElementById('modal-overlay').style.display = 'none';
    document.getElementById('modal-box').style.width = '';
    document.getElementById('modal-save').style.display = '';
    document.getElementById('modal-save').textContent = 'Save';
    document.getElementById('modal-cancel').style.display = '';
    this._onSave = null;
  },

  showError(msg) {
    const el = document.getElementById('modal-error');
    el.textContent = msg;
    el.style.display = 'block';
  },

  getVal(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
  },

  getNum(id) {
    return parseFloat(Modal.getVal(id)) || 0;
  },

  getChecked(id) {
    const el = document.getElementById(id);
    return el ? el.checked : false;
  },

  init() {
    document.getElementById('modal-close').addEventListener('click', () => Modal.close());
    document.getElementById('modal-cancel').addEventListener('click', () => Modal.close());
    document.getElementById('modal-save').addEventListener('click', () => {
      if (Modal._onSave) Modal._onSave();
    });
    document.getElementById('modal-overlay').addEventListener('click', (e) => {
      if (e.target.id === 'modal-overlay') Modal.close();
    });
  }
};


// ============================================
// CATEGORY MANAGER
// ============================================
const CategoryManager = {
  categories: [],

  async init() {
    await this.load();
    this.render();
    document.getElementById('categories-add-btn').addEventListener('click', () => this.openForm());
  },

  async load() {
    const r = await window.api.dbAll("SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id AND is_deleted = 0) as product_count FROM categories c WHERE c.is_active = 1 ORDER BY c.sort_order ASC, c.name ASC");
    this.categories = (r.success && r.data) ? r.data : [];
  },

  render() {
    const tbody = document.getElementById('categories-tbody');
    const empty = document.getElementById('categories-empty');
    if (!tbody) return;

    if (this.categories.length === 0) {
      tbody.innerHTML = '';
      empty.style.display = 'block';
      return;
    }

    empty.style.display = 'none';
    tbody.innerHTML = this.categories.map((c, i) => `
      <tr>
        <td style="color:var(--text-light)">${i + 1}</td>
        <td class="cell-name">${SellEngine.escHtml(c.name)}</td>
        <td style="color:var(--text-secondary)">${SellEngine.escHtml(c.name_ar || '—')}</td>
        <td><span class="pm-cat-dot" style="background:${c.color || '#4A90D9'};display:inline-block"></span></td>
        <td>${c.product_count || 0}</td>
        <td>${c.sort_order || 0}</td>
        <td>
          <div class="pm-actions">
            <button class="pm-act-btn" title="Edit" onclick="CategoryManager.openForm(${c.id})">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="pm-act-btn danger" title="Delete" onclick="CategoryManager.delete(${c.id})">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
            </button>
          </div>
        </td>
      </tr>`).join('');
  },

  openForm(editId) {
    const cat = editId ? this.categories.find(c => c.id === editId) : null;
    const title = cat ? 'Edit Category' : 'Add Category';
    const html = `
      <div class="form-row">
        <label class="form-label">Category Name *</label>
        <input class="form-input" id="f-cat-name" value="${cat ? SellEngine.escHtml(cat.name) : ''}" placeholder="e.g. Beverages">
      </div>
      <div class="form-row">
        <label class="form-label">Arabic Name</label>
        <input class="form-input" id="f-cat-name-ar" value="${cat ? SellEngine.escHtml(cat.name_ar || '') : ''}" placeholder="Optional" dir="rtl">
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Color</label>
          <input class="form-input" id="f-cat-color" type="color" value="${cat ? cat.color : '#4A90D9'}" style="height:38px;padding:4px">
        </div>
        <div>
          <label class="form-label">Sort Order</label>
          <input class="form-input" id="f-cat-order" type="number" value="${cat ? cat.sort_order : 0}" min="0">
        </div>
      </div>`;

    Modal.open(title, html, async () => {
      const name = Modal.getVal('f-cat-name');
      if (!name) { Modal.showError('Category name is required'); return; }
      const data = {
        name,
        name_ar: Modal.getVal('f-cat-name-ar'),
        color: Modal.getVal('f-cat-color') || '#4A90D9',
        sort_order: Modal.getNum('f-cat-order')
      };

      let r;
      if (cat) {
        r = await window.api.dbRun(
          "UPDATE categories SET name=?, name_ar=?, color=?, sort_order=? WHERE id=?",
          [data.name, data.name_ar, data.color, data.sort_order, cat.id]
        );
      } else {
        r = await window.api.dbRun(
          "INSERT INTO categories (name, name_ar, color, sort_order) VALUES (?, ?, ?, ?)",
          [data.name, data.name_ar, data.color, data.sort_order]
        );
      }

      if (!r.success) { Modal.showError(r.error || 'Save failed'); return; }
      Modal.close();
      await this.load();
      this.render();
      await ProductManager.refreshCatFilter();
      SellEngine.showToast(cat ? 'Category updated' : 'Category added', 'success');
    });
  },

  async delete(id) {
    if (!confirm('Delete this category? Products won\'t be deleted.')) return;
    await window.api.dbRun("UPDATE categories SET is_active = 0 WHERE id = ?", [id]);
    await this.load();
    this.render();
    await ProductManager.refreshCatFilter();
  }
};


// ============================================
// PRODUCT MANAGER
// ============================================
const ProductManager = {
  products: [],
  searchTerm: '',
  catFilter: 'all',
  stockFilter: 'all',

  async init() {
    await this.load();
    this.render();
    this.bindEvents();
  },

  async load() {
    const r = await window.api.dbAll(
      `SELECT p.*, c.name as cat_name, c.color as cat_color
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.is_deleted = 0
       ORDER BY p.name ASC`
    );
    this.products = (r.success && r.data) ? r.data : [];
  },

  render() {
    const tbody = document.getElementById('products-tbody');
    const empty = document.getElementById('products-empty');
    const countEl = document.getElementById('products-count');
    if (!tbody) return;

    let list = this.products;

    // Filters
    if (this.catFilter !== 'all') {
      list = list.filter(p => p.category_id === parseInt(this.catFilter));
    }
    if (this.stockFilter === 'low') {
      list = list.filter(p => p.track_stock && p.stock_qty > 0 && p.stock_qty <= p.low_stock_threshold);
    } else if (this.stockFilter === 'out') {
      list = list.filter(p => p.track_stock && p.stock_qty <= 0);
    }
    if (this.searchTerm) {
      const t = this.searchTerm.toLowerCase();
      list = list.filter(p =>
        (p.name && p.name.toLowerCase().includes(t)) ||
        (p.barcode && p.barcode.toLowerCase().includes(t)) ||
        (p.sku && p.sku.toLowerCase().includes(t))
      );
    }

    if (countEl) countEl.textContent = list.length + ' product' + (list.length !== 1 ? 's' : '');

    if (list.length === 0) {
      tbody.innerHTML = '';
      empty.style.display = 'block';
      return;
    }

    empty.style.display = 'none';
    tbody.innerHTML = list.map((p, i) => {
      const isLow = p.track_stock && p.stock_qty > 0 && p.stock_qty <= p.low_stock_threshold;
      const isOut = p.track_stock && p.stock_qty <= 0;
      const stockClass = isOut ? 'out' : (isLow ? 'low' : '');
      return `
        <tr>
          <td style="color:var(--text-light)">${i + 1}</td>
          <td class="cell-name">${SellEngine.escHtml(p.name)}</td>
          <td class="cell-barcode">${SellEngine.escHtml(p.barcode || '—')}</td>
          <td>${p.cat_name ? `<span class="cell-cat"><span class="pm-cat-dot" style="background:${p.cat_color || '#4A90D9'}"></span>${SellEngine.escHtml(p.cat_name)}</span>` : '<span style="color:#D1D5DB">—</span>'}</td>
          <td class="cell-price">${parseFloat(p.cost_price).toFixed(2)}</td>
          <td class="cell-price" style="color:var(--accent-blue);font-weight:700">${parseFloat(p.sell_price).toFixed(2)}</td>
          <td class="cell-stock ${stockClass}">${p.track_stock ? Math.floor(p.stock_qty) : '∞'}</td>
          <td>
            <div class="pm-actions">
              <button class="pm-act-btn" title="Edit" onclick="ProductManager.openForm(${p.id})">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <button class="pm-act-btn danger" title="Delete" onclick="ProductManager.deleteProduct(${p.id})">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              </button>
            </div>
          </td>
        </tr>`;
    }).join('');
  },

  bindEvents() {
    document.getElementById('products-add-btn').addEventListener('click', () => this.openForm());
    document.getElementById('products-search').addEventListener('input', (e) => {
      this.searchTerm = e.target.value;
      this.render();
    });
    document.getElementById('products-cat-filter').addEventListener('change', (e) => {
      this.catFilter = e.target.value;
      this.render();
    });
    document.getElementById('products-stock-filter').addEventListener('change', (e) => {
      this.stockFilter = e.target.value;
      this.render();
    });
    this.refreshCatFilter();
  },

  async refreshCatFilter() {
    const sel = document.getElementById('products-cat-filter');
    if (!sel) return;
    const cats = await window.api.dbAll("SELECT id, name FROM categories WHERE is_active=1 ORDER BY sort_order, name");
    let html = '<option value="all">All Categories</option>';
    if (cats.success && cats.data) {
      cats.data.forEach(c => { html += `<option value="${c.id}">${SellEngine.escHtml(c.name)}</option>`; });
    }
    sel.innerHTML = html;
  },

  // ============================================
  // OPEN ADD/EDIT FORM
  // ============================================
  async openForm(editId) {
    const p = editId ? this.products.find(x => x.id === editId) : null;
    const title = p ? 'Edit Product' : 'Add Product';

    // Load categories for dropdown
    const catsR = await window.api.dbAll("SELECT id, name FROM categories WHERE is_active=1 ORDER BY sort_order, name");
    const cats = (catsR.success && catsR.data) ? catsR.data : [];
    const catOptions = cats.map(c =>
      `<option value="${c.id}"${p && p.category_id === c.id ? ' selected' : ''}>${SellEngine.escHtml(c.name)}</option>`
    ).join('');

    const html = `
      <div class="form-row">
        <label class="form-label">Product Name *</label>
        <input class="form-input" id="f-name" value="${p ? SellEngine.escHtml(p.name) : ''}" placeholder="e.g. Coca Cola 350ml">
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Barcode</label>
          <input class="form-input form-input-mono" id="f-barcode" value="${p ? SellEngine.escHtml(p.barcode || '') : ''}" placeholder="Scan or type barcode">
          <div class="form-hint" id="f-barcode-hint"></div>
        </div>
        <div>
          <label class="form-label">SKU</label>
          <input class="form-input form-input-mono" id="f-sku" value="${p ? SellEngine.escHtml(p.sku || '') : ''}" placeholder="Optional">
        </div>
      </div>
      <div class="form-row">
        <label class="form-label">Category</label>
        <select class="form-select" id="f-category">
          <option value="">— No Category —</option>
          ${catOptions}
        </select>
      </div>
      <div class="form-divider"></div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Cost Price</label>
          <input class="form-input form-input-mono" id="f-cost" type="number" step="0.01" min="0" value="${p ? p.cost_price : '0'}">
        </div>
        <div>
          <label class="form-label">Sell Price *</label>
          <input class="form-input form-input-mono" id="f-price" type="number" step="0.01" min="0" value="${p ? p.sell_price : ''}">
        </div>
      </div>
      <div class="form-check-row">
        <input type="checkbox" id="f-tax-inc" ${(!p || p.tax_included) ? 'checked' : ''}> Tax included in price
      </div>
      <div class="form-divider"></div>
      <div class="form-check-row">
        <input type="checkbox" id="f-track-stock" ${(!p || p.track_stock) ? 'checked' : ''}> Track stock
      </div>
      <div class="form-row-double" id="f-stock-fields">
        <div>
          <label class="form-label">Stock Qty</label>
          <input class="form-input form-input-mono" id="f-stock" type="number" step="1" min="0" value="${p ? p.stock_qty : '0'}">
        </div>
        <div>
          <label class="form-label">Low Stock Alert</label>
          <input class="form-input form-input-mono" id="f-low-stock" type="number" step="1" min="0" value="${p ? p.low_stock_threshold : '5'}">
        </div>
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Unit</label>
          <select class="form-select" id="f-unit">
            <option value="pcs" ${p && p.unit === 'pcs' ? 'selected' : ''}>Pieces (pcs)</option>
            <option value="kg" ${p && p.unit === 'kg' ? 'selected' : ''}>Kilogram (kg)</option>
            <option value="ltr" ${p && p.unit === 'ltr' ? 'selected' : ''}>Liter (ltr)</option>
            <option value="box" ${p && p.unit === 'box' ? 'selected' : ''}>Box</option>
            <option value="pack" ${p && p.unit === 'pack' ? 'selected' : ''}>Pack</option>
          </select>
        </div>
        <div>
          <label class="form-label">Arabic Name</label>
          <input class="form-input" id="f-name-ar" value="${p ? SellEngine.escHtml(p.name_ar || '') : ''}" dir="rtl" placeholder="Optional">
        </div>
      </div>`;

    Modal.open(title, html, () => this._saveProduct(p ? p.id : null));

    // Live barcode duplicate check
    const bcInput = document.getElementById('f-barcode');
    if (bcInput) {
      bcInput.addEventListener('input', () => this._checkBarcodeDuplicate(bcInput, p ? p.id : null));
    }

    // Toggle stock fields
    const trackChk = document.getElementById('f-track-stock');
    const stockFields = document.getElementById('f-stock-fields');
    if (trackChk && stockFields) {
      const toggle = () => { stockFields.style.display = trackChk.checked ? 'grid' : 'none'; };
      trackChk.addEventListener('change', toggle);
      toggle();
    }
  },

  // ============================================
  // LIVE BARCODE DUPLICATE CHECK
  // ============================================
  async _checkBarcodeDuplicate(input, editId) {
    const hint = document.getElementById('f-barcode-hint');
    const barcode = input.value.trim();
    if (!barcode) {
      input.classList.remove('error');
      if (hint) { hint.textContent = ''; hint.style.color = ''; }
      return;
    }

    const r = await window.api.dbGet(
      "SELECT id, name FROM products WHERE barcode = ? AND is_deleted = 0 AND id != ?",
      [barcode, editId || -1]
    );

    if (r.success && r.data) {
      input.classList.add('error');
      if (hint) {
        hint.textContent = '⚠ Barcode already used by: ' + r.data.name;
        hint.style.color = 'var(--accent-red)';
      }
    } else {
      input.classList.remove('error');
      if (hint) {
        hint.textContent = '✓ Barcode available';
        hint.style.color = 'var(--accent-green)';
      }
    }
  },

  // ============================================
  // SAVE PRODUCT (CREATE or UPDATE)
  // ============================================
  async _saveProduct(editId) {
    const name = Modal.getVal('f-name');
    const barcode = Modal.getVal('f-barcode');
    const sku = Modal.getVal('f-sku');
    const price = Modal.getNum('f-price');

    // Validation
    if (!name) { Modal.showError('Product name is required'); return; }
    if (price <= 0) { Modal.showError('Sell price must be greater than 0'); return; }

    // ★ DUPLICATE BARCODE CHECK (server-side, definitive)
    if (barcode) {
      const dupCheck = await window.api.dbGet(
        "SELECT id, name FROM products WHERE barcode = ? AND is_deleted = 0 AND id != ?",
        [barcode, editId || -1]
      );
      if (dupCheck.success && dupCheck.data) {
        Modal.showError('Barcode "' + barcode + '" is already assigned to: ' + dupCheck.data.name);
        return;
      }
    }

    const catId = Modal.getVal('f-category') || null;
    const cost = Modal.getNum('f-cost');
    const taxInc = Modal.getChecked('f-tax-inc') ? 1 : 0;
    const trackStock = Modal.getChecked('f-track-stock') ? 1 : 0;
    const stock = Modal.getNum('f-stock');
    const lowStock = Modal.getNum('f-low-stock');
    const unit = Modal.getVal('f-unit') || 'pcs';
    const nameAr = Modal.getVal('f-name-ar');

    let r;
    if (editId) {
      r = await window.api.dbRun(
        `UPDATE products SET name=?, name_ar=?, barcode=?, sku=?, category_id=?,
         cost_price=?, sell_price=?, tax_included=?, track_stock=?,
         stock_qty=?, low_stock_threshold=?, unit=?,
         updated_at=datetime('now','localtime')
         WHERE id=?`,
        [name, nameAr, barcode, sku, catId, cost, price, taxInc, trackStock, stock, lowStock, unit, editId]
      );
    } else {
      r = await window.api.dbRun(
        `INSERT INTO products (name, name_ar, barcode, sku, category_id,
         cost_price, sell_price, tax_included, track_stock,
         stock_qty, low_stock_threshold, unit)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [name, nameAr, barcode, sku, catId, cost, price, taxInc, trackStock, stock, lowStock, unit]
      );
    }

    if (!r.success) { Modal.showError(r.error || 'Save failed'); return; }

    Modal.close();
    await this.load();
    this.render();

    // Refresh sell screen product cache
    await SellEngine.loadProducts();
    SellEngine.renderProducts();

    SellEngine.showToast(editId ? 'Product updated' : 'Product added', 'success');
  },

  // ============================================
  // DELETE PRODUCT (soft delete)
  // ============================================
  async deleteProduct(id) {
    const p = this.products.find(x => x.id === id);
    if (!p) return;
    if (!confirm('Delete "' + p.name + '"?\nThis will mark it as deleted.')) return;

    await window.api.dbRun("UPDATE products SET is_deleted = 1, updated_at = datetime('now','localtime') WHERE id = ?", [id]);
    await this.load();
    this.render();

    // Refresh sell screen
    await SellEngine.loadProducts();
    SellEngine.renderProducts();

    SellEngine.showToast('Product deleted', 'info');
  }
};


// ============================================
// STOCK MANAGER — Inventory page + stock ops
// ============================================
const StockManager = {
  products: [],
  searchTerm: '',
  filter: 'all',

  async init() {
    await this.load();
    this.render();
    this.bindEvents();
    this.checkLowStock();
  },

  async load() {
    const r = await window.api.dbAll(
      `SELECT p.*, c.name as cat_name FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.is_deleted = 0 ORDER BY p.name ASC`
    );
    this.products = (r.success && r.data) ? r.data : [];
  },

  render() {
    const tbody = document.getElementById('inv-tbody');
    const empty = document.getElementById('inv-empty');
    const countEl = document.getElementById('inv-count');
    if (!tbody) return;

    let list = this.products;

    if (this.filter === 'tracked') {
      list = list.filter(p => p.track_stock);
    } else if (this.filter === 'low') {
      list = list.filter(p => p.track_stock && p.stock_qty > 0 && p.stock_qty <= p.low_stock_threshold);
    } else if (this.filter === 'out') {
      list = list.filter(p => p.track_stock && p.stock_qty <= 0);
    }

    if (this.searchTerm) {
      const t = this.searchTerm.toLowerCase();
      list = list.filter(p =>
        (p.name && p.name.toLowerCase().includes(t)) ||
        (p.barcode && p.barcode.toLowerCase().includes(t))
      );
    }

    if (countEl) countEl.textContent = list.length + ' product' + (list.length !== 1 ? 's' : '');

    if (list.length === 0) {
      tbody.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';

    tbody.innerHTML = list.map((p, i) => {
      if (!p.track_stock) {
        return `<tr>
          <td style="color:var(--text-light)">${i + 1}</td>
          <td class="cell-name">${SellEngine.escHtml(p.name)}</td>
          <td class="cell-barcode">${SellEngine.escHtml(p.barcode || '—')}</td>
          <td style="color:var(--text-light)">∞</td>
          <td style="color:var(--text-light)">—</td>
          <td><span class="inv-badge ok">Untracked</span></td>
          <td></td>
        </tr>`;
      }
      const isOut = p.stock_qty <= 0;
      const isLow = !isOut && p.stock_qty <= p.low_stock_threshold;
      const badge = isOut ? '<span class="inv-badge out">OUT</span>'
                   : isLow ? '<span class="inv-badge low">LOW</span>'
                   : '<span class="inv-badge ok">OK</span>';
      return `<tr>
        <td style="color:var(--text-light)">${i + 1}</td>
        <td class="cell-name">${SellEngine.escHtml(p.name)}</td>
        <td class="cell-barcode">${SellEngine.escHtml(p.barcode || '—')}</td>
        <td class="cell-stock ${isOut ? 'out' : isLow ? 'low' : ''}" style="font-family:var(--font-mono);font-weight:700">${Math.floor(p.stock_qty)}</td>
        <td style="color:var(--text-light)">${p.low_stock_threshold}</td>
        <td>${badge}</td>
        <td>
          <div class="inv-quick">
            <button class="inv-quick-btn" onclick="StockManager.openAdjust(${p.id})">± Adjust</button>
            <button class="inv-quick-btn dmg" onclick="StockManager.openDamage(${p.id})">⚠ Dmg</button>
          </div>
        </td>
      </tr>`;
    }).join('');
  },

  bindEvents() {
    document.getElementById('inv-search').addEventListener('input', (e) => {
      this.searchTerm = e.target.value;
      this.render();
    });
    document.getElementById('inv-filter').addEventListener('change', (e) => {
      this.filter = e.target.value;
      this.render();
    });
    document.getElementById('inv-adjust-btn').addEventListener('click', () => this.openAdjust());
    document.getElementById('inv-damage-btn').addEventListener('click', () => this.openDamage());
    document.getElementById('inv-history-btn').addEventListener('click', () => this.openHistory());
    document.getElementById('inv-alert-show').addEventListener('click', () => {
      document.getElementById('inv-filter').value = 'low';
      this.filter = 'low';
      this.render();
    });
  },

  async checkLowStock() {
    const r = await window.api.stockLow();
    const alert = document.getElementById('inv-alert');
    const alertText = document.getElementById('inv-alert-text');
    if (r.success && r.data && r.data.length > 0) {
      alert.style.display = 'flex';
      alertText.textContent = r.data.length + ' product' + (r.data.length > 1 ? 's are' : ' is') + ' low on stock';
    } else {
      alert.style.display = 'none';
    }
  },

  // ============================================
  // ADJUST STOCK — Modal
  // ============================================
  openAdjust(productId) {
    const products = this.products.filter(p => p.track_stock);
    const selected = productId || '';
    const options = products.map(p =>
      `<option value="${p.id}"${p.id === selected ? ' selected' : ''}>${SellEngine.escHtml(p.name)} (current: ${Math.floor(p.stock_qty)})</option>`
    ).join('');

    const html = `
      <div class="form-row">
        <label class="form-label">Product *</label>
        <select class="form-select" id="f-adj-product">${options}</select>
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Adjustment Type</label>
          <select class="form-select" id="f-adj-type">
            <option value="add">+ Add Stock</option>
            <option value="remove">− Remove Stock</option>
            <option value="set">= Set Exact Qty</option>
          </select>
        </div>
        <div>
          <label class="form-label">Quantity *</label>
          <input class="form-input form-input-mono" id="f-adj-qty" type="number" step="1" min="0" value="0">
        </div>
      </div>
      <div class="form-row">
        <label class="form-label">Reason</label>
        <input class="form-input" id="f-adj-reason" placeholder="e.g. Restock delivery, Inventory count...">
      </div>`;

    Modal.open('Adjust Stock', html, async () => {
      const pid = parseInt(Modal.getVal('f-adj-product'));
      const type = Modal.getVal('f-adj-type');
      const qty = Modal.getNum('f-adj-qty');
      const reason = Modal.getVal('f-adj-reason');

      if (!pid) { Modal.showError('Select a product'); return; }
      if (qty <= 0 && type !== 'set') { Modal.showError('Quantity must be greater than 0'); return; }

      let change;
      if (type === 'set') {
        const p = this.products.find(x => x.id === pid);
        change = qty - (p ? p.stock_qty : 0);
      } else if (type === 'remove') {
        change = -qty;
      } else {
        change = qty;
      }

      const r = await window.api.stockAdjust({ product_id: pid, qty_change: change, reason: reason || type });
      if (!r.success) { Modal.showError(r.error); return; }

      Modal.close();
      await this.load();
      this.render();
      this.checkLowStock();
      await SellEngine.loadProducts();
      SellEngine.renderProducts();
      SellEngine.showToast(`Stock updated: ${r.data.name} (${r.data.qtyBefore} → ${r.data.qtyAfter})`, 'success');
    });
  },

  // ============================================
  // DAMAGE STOCK — Modal
  // ============================================
  openDamage(productId) {
    const products = this.products.filter(p => p.track_stock && p.stock_qty > 0);
    const selected = productId || '';
    const options = products.map(p =>
      `<option value="${p.id}"${p.id === selected ? ' selected' : ''}>${SellEngine.escHtml(p.name)} (stock: ${Math.floor(p.stock_qty)})</option>`
    ).join('');

    const html = `
      <div class="form-row">
        <label class="form-label">Product *</label>
        <select class="form-select" id="f-dmg-product">${options}</select>
      </div>
      <div class="form-row">
        <label class="form-label">Damaged Quantity *</label>
        <input class="form-input form-input-mono" id="f-dmg-qty" type="number" step="1" min="1" value="1">
      </div>
      <div class="form-row">
        <label class="form-label">Reason *</label>
        <input class="form-input" id="f-dmg-reason" placeholder="e.g. Broken, Expired, Water damage...">
      </div>`;

    Modal.open('Record Damaged Stock', html, async () => {
      const pid = parseInt(Modal.getVal('f-dmg-product'));
      const qty = Modal.getNum('f-dmg-qty');
      const reason = Modal.getVal('f-dmg-reason');

      if (!pid) { Modal.showError('Select a product'); return; }
      if (qty <= 0) { Modal.showError('Quantity must be at least 1'); return; }
      if (!reason) { Modal.showError('Reason is required for damage records'); return; }

      const r = await window.api.stockDamage({ product_id: pid, qty, reason });
      if (!r.success) { Modal.showError(r.error); return; }

      Modal.close();
      await this.load();
      this.render();
      this.checkLowStock();
      await SellEngine.loadProducts();
      SellEngine.renderProducts();
      SellEngine.showToast(`Damage recorded: ${r.data.name} −${qty} (${r.data.qtyBefore} → ${r.data.qtyAfter})`, 'info');
    });
  },

  // ============================================
  // STOCK HISTORY — Modal
  // ============================================
  async openHistory(productId) {
    const r = await window.api.stockHistory({ product_id: productId || null, limit: 50 });
    const items = (r.success && r.data) ? r.data : [];

    let html;
    if (items.length === 0) {
      html = '<div style="text-align:center;padding:30px;color:#9CA3AF;">No stock history yet</div>';
    } else {
      html = `<div style="max-height:400px;overflow:auto;">
        <table class="hist-table">
          <thead><tr>
            <th>Date</th><th>Product</th><th>Type</th><th>Change</th><th>Before</th><th>After</th><th>Reason</th>
          </tr></thead>
          <tbody>${items.map(h => {
            const cls = h.qty_change >= 0 ? 'positive' : 'negative';
            const sign = h.qty_change >= 0 ? '+' : '';
            const typeClass = h.type.replace('_', '_');
            const dateStr = h.created_at ? h.created_at.substring(0, 16).replace('T', ' ') : '';
            return `<tr>
              <td style="font-size:11px;color:var(--text-light);white-space:nowrap">${dateStr}</td>
              <td class="cell-name" style="font-size:12px">${SellEngine.escHtml(h.product_name || '')}</td>
              <td><span class="hist-type ${typeClass}">${h.type}</span></td>
              <td class="hist-change ${cls}" style="font-family:var(--font-mono)">${sign}${h.qty_change}</td>
              <td style="font-family:var(--font-mono);color:var(--text-light)">${h.qty_before}</td>
              <td style="font-family:var(--font-mono);font-weight:700">${h.qty_after}</td>
              <td style="font-size:11.5px;color:var(--text-secondary)">${SellEngine.escHtml(h.reason || '')}</td>
            </tr>`;
          }).join('')}</tbody>
        </table>
      </div>`;
    }

    Modal.open('Stock History', html, () => Modal.close());
    document.getElementById('modal-save').textContent = 'Close';
    document.getElementById('modal-cancel').style.display = 'none';
  }
};


// ============================================
// RECEIPT BUILDER — Exact match to thermal receipt
// ============================================
const ReceiptBuilder = {

  /**
   * Build receipt HTML matching the provided receipt image exactly
   * @param {Object} sale - { invoiceNumber, items[], subtotal, tax, total, method, cash, card, change, due, customer, date }
   * @param {Object} biz - business info from DB
   * @returns {string} HTML
   */
  build(sale, biz) {
    const items = sale.items || [];
    const totalQty = items.reduce((s, i) => s + i.qty, 0);
    const dateObj = sale.date ? new Date(sale.date) : new Date();
    const dateStr = this._fmtDate(dateObj);
    const timeStr = this._fmtTime(dateObj);

    let html = '<div class="receipt">';

    // === LOGO ===
    if (biz.logo_path) {
      html += `<div class="rcpt-logo"><img src="${biz.logo_path}" alt=""></div>`;
    }

    // === SHOP NAME (Arabic) ===
    if (biz.shop_name) {
      html += `<div class="rcpt-shop-name">${this._esc(biz.shop_name)}</div>`;
    }

    // === ADDRESS lines ===
    if (biz.address) {
      const lines = biz.address.split('\n');
      lines.forEach(line => {
        if (line.trim()) {
          html += `<div class="rcpt-line-ar">${this._esc(line.trim())}</div>`;
        }
      });
    }

    // === PHONE — One block per unique number, no duplicates ===
    if (biz.phone) {
      // Split by newline, deduplicate, filter empty
      const allPhones = biz.phone.split('\n').map(p => p.trim()).filter(p => p);
      const uniquePhones = [...new Set(allPhones)];
      uniquePhones.forEach(p => {
        html += `<div class="rcpt-line">Mobile: ${this._esc(p)}</div>`;
        html += `<div class="rcpt-line-ar">جوال : ${this._esc(p)}</div>`;
      });
    }

    // === VAT NUMBER — Show number or NIL, hide entire line if field empty and no VAT ===
    const vatDisplay = (biz.vat_number && biz.vat_number.trim()) ? biz.vat_number.trim() : 'NIL';
    html += `<div class="rcpt-vat-label">${this._esc(vatDisplay)} : الرقم الضريبي</div>`;

    // === TITLE ===
    html += `<div class="rcpt-title-ar">فاتورة ضريبية مبسطة</div>`;
    html += `<div class="rcpt-title-en">Simplified Tax Invoice</div>`;

    // === INVOICE INFO ===
    html += `<div class="rcpt-info">`;
    html += `<div class="rcpt-info-row"><span>INVOICE NO:</span><span>&nbsp;&nbsp;${this._esc(sale.invoiceNumber || '')}</span></div>`;
    html += `<div class="rcpt-info-row"><span>Date</span><span>&nbsp;&nbsp;&nbsp;&nbsp;:${dateStr}</span><span>&nbsp;Time&nbsp;:${timeStr}</span></div>`;
    html += `<div class="rcpt-info-row"><span>Customer :</span><span>${this._esc(sale.customer || 'Cash')}</span></div>`;
    html += `</div>`;

    // === ITEMS TABLE ===
    html += `<table class="rcpt-table">`;
    html += `<thead><tr>
      <th style="width:14px">Sl</th>
      <th>Item</th>
      <th style="width:32px">Qty</th>
      <th style="width:42px">Rate</th>
      <th style="width:32px">Tax</th>
      <th style="width:48px">Amount</th>
    </tr></thead>`;
    html += `<tbody>`;

    items.forEach((item, idx) => {
      // Item name row
      html += `<tr><td class="rcpt-item-name" colspan="6">${idx + 1}&nbsp;&nbsp;&nbsp;${this._esc(item.name).toUpperCase()}</td></tr>`;
      // Unit + values row
      html += `<tr class="rcpt-item-unit">
        <td></td>
        <td>Psc</td>
        <td>${this._fmtQty(item.qty)}</td>
        <td>${this._fmtPrice(item.price)}</td>
        <td>${this._fmtPrice(item.tax || 0)}</td>
        <td>${this._fmtPrice(item.total)}</td>
      </tr>`;
    });

    html += `</tbody></table>`;

    // === QUANTITY COUNT ===
    html += `<div style="font-size:11px;padding:2px 2px;border-top:1px solid #000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this._fmtQty(totalQty)}</div>`;

    // === TOTALS ===
    html += `<div class="rcpt-totals">`;

    // TOTAL (مجموع)
    html += `<div class="rcpt-total-row">
      <div class="label"><span>TOTAL</span><span class="label-ar">(مجموع)</span></div>
      <span>${this._fmtPrice(sale.subtotal)}</span>
    </div>`;

    // VAT (ضريبة) — use actual tax rate
    const taxRateDisplay = (biz.tax_rate != null && biz.tax_rate !== undefined) ? biz.tax_rate : 15;
    html += `<div class="rcpt-total-row">
      <div class="label"><span>VAT ${taxRateDisplay}%</span><span class="label-ar">(ضريبة)</span></div>
      <span>${this._fmtPrice(sale.tax)}</span>
    </div>`;

    // GRAND TOTAL (المجموع الإجمالي)
    html += `<div class="rcpt-grand-row">
      <div class="label"><span>GRAND TOTAL</span><span class="label-ar">(المجموع الإجمالي)</span></div>
      <span>${this._fmtPrice(sale.total)}</span>
    </div>`;

    html += `</div>`;

    // === DASHED LINE ===
    html += `<hr class="rcpt-dashed">`;

    // === PAYMENT ===
    html += `<div class="rcpt-payment">`;
    const method = (sale.method || 'cash').toLowerCase();
    if (method === 'cash' || method === 'split') {
      html += `<div class="rcpt-payment-row"><span>Received by Cash :</span><span>&nbsp;${this._fmtPrice(sale.cash || sale.total)}</span></div>`;
    }
    if (method === 'card' || method === 'split') {
      html += `<div class="rcpt-payment-row"><span>Received by Card :</span><span>&nbsp;${this._fmtPrice(sale.card || 0)}</span></div>`;
    }
    // Balance / Change
    const change = sale.change || 0;
    html += `<div class="rcpt-payment-row"><span>Balance&nbsp;&nbsp;=</span><span>&nbsp;${change > 0 ? this._fmtPrice(change) : ''}</span></div>`;
    html += `</div>`;

    // === AMOUNT IN WORDS ===
    html += `<div class="rcpt-words">Amount in Words: ${this._amountToWords(sale.total)} Riyal and ${this._amountToWordsDecimal(sale.total)} Halala</div>`;

    // === QR CODE ===
    html += `<div class="rcpt-qr"><canvas id="rcpt-qr-canvas"></canvas></div>`;

    // === FOOTER ===
    if (biz.receipt_footer) {
      html += `<div class="rcpt-footer">${this._esc(biz.receipt_footer)}</div>`;
    }
    html += `<div class="rcpt-footer">الأسترجاع خلال 24 ساعة بالحالة الأصليه للمنتج</div>`;
    html += `<div class="rcpt-footer">------شكرا لزيارتكم------</div>`;

    html += '</div>';
    return html;
  },

  // ============================================
  // SHOW PREVIEW — Modal with print button
  // ============================================
  async showPreview(saleData) {
    const bizR = await window.api.getBusiness();
    const biz = (bizR.success && bizR.data) ? bizR.data : {};

    const receiptHtml = this.build(saleData, biz);

    const html = `
      <div class="receipt-preview-wrap">
        <div class="receipt-print-area" id="receipt-print-area">
          ${receiptHtml}
        </div>
        <div class="receipt-actions">
          <button class="btn btn-ghost" onclick="Modal.close()">Close</button>
          <button class="btn btn-primary" onclick="ReceiptBuilder.print()">🖨 Print</button>
        </div>
      </div>`;

    Modal.open('Receipt Preview', html, () => Modal.close());
    document.getElementById('modal-save').style.display = 'none';
    document.getElementById('modal-cancel').style.display = 'none';

    // Generate QR code
    setTimeout(() => this._generateQR(saleData, biz), 100);
  },

  // ============================================
  // PRINT
  // ============================================
  print() {
    window.print();
  },

  // ============================================
  // QR CODE — ZATCA format (Base64 TLV)
  // ============================================
  _generateQR(sale, biz) {
    const canvas = document.getElementById('rcpt-qr-canvas');
    if (!canvas) return;

    // Build ZATCA TLV data
    const tlvData = this._buildZatcaTLV(biz, sale);

    // Simple QR rendering using canvas
    this._drawQR(canvas, tlvData);
  },

  _buildZatcaTLV(biz, sale) {
    // ZATCA requires TLV (Tag-Length-Value) base64 encoded:
    // Tag 1: Seller name
    // Tag 2: VAT number
    // Tag 3: Timestamp
    // Tag 4: Total with VAT
    // Tag 5: VAT amount
    const seller = biz.shop_name || 'Shop';
    const vat = biz.vat_number || 'NIL';
    const timestamp = new Date().toISOString();
    const total = (sale.total || 0).toFixed(2);
    const tax = (sale.tax || 0).toFixed(2);

    const tlv = (tag, value) => {
      const enc = new TextEncoder();
      const bytes = enc.encode(value);
      return [tag, bytes.length, ...bytes];
    };

    const data = [
      ...tlv(1, seller),
      ...tlv(2, vat),
      ...tlv(3, timestamp),
      ...tlv(4, total),
      ...tlv(5, tax)
    ];

    // Convert to base64
    const uint8 = new Uint8Array(data);
    let binary = '';
    uint8.forEach(b => binary += String.fromCharCode(b));
    return btoa(binary);
  },

  _drawQR(canvas, data) {
    // Simple QR-like pattern generator for preview
    // In production, use a proper QR library
    const ctx = canvas.getContext('2d');
    const size = 120;
    canvas.width = size;
    canvas.height = size;

    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, size, size);

    // Generate a deterministic pattern from data
    const cells = 25;
    const cellSize = size / cells;
    ctx.fillStyle = '#000';

    // Position detection patterns (3 corners)
    this._drawFinderPattern(ctx, 0, 0, cellSize);
    this._drawFinderPattern(ctx, (cells - 7) * cellSize, 0, cellSize);
    this._drawFinderPattern(ctx, 0, (cells - 7) * cellSize, cellSize);

    // Data modules from base64 string
    let bitIndex = 0;
    const bits = [];
    for (let i = 0; i < data.length; i++) {
      const c = data.charCodeAt(i);
      for (let b = 7; b >= 0; b--) {
        bits.push((c >> b) & 1);
      }
    }

    for (let row = 0; row < cells; row++) {
      for (let col = 0; col < cells; col++) {
        // Skip finder patterns
        if ((row < 8 && col < 8) || (row < 8 && col >= cells - 8) || (row >= cells - 8 && col < 8)) continue;
        // Timing patterns
        if (row === 6 || col === 6) {
          if ((row + col) % 2 === 0) ctx.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
          continue;
        }
        if (bitIndex < bits.length && bits[bitIndex]) {
          ctx.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
        }
        bitIndex++;
      }
    }
  },

  _drawFinderPattern(ctx, x, y, cellSize) {
    // 7x7 finder pattern
    ctx.fillStyle = '#000';
    ctx.fillRect(x, y, 7 * cellSize, 7 * cellSize);
    ctx.fillStyle = '#fff';
    ctx.fillRect(x + cellSize, y + cellSize, 5 * cellSize, 5 * cellSize);
    ctx.fillStyle = '#000';
    ctx.fillRect(x + 2 * cellSize, y + 2 * cellSize, 3 * cellSize, 3 * cellSize);
  },

  // ============================================
  // FORMAT HELPERS
  // ============================================
  _fmtDate(d) {
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
  },

  _fmtTime(d) {
    let h = d.getHours();
    const m = String(d.getMinutes()).padStart(2, '0');
    const s = String(d.getSeconds()).padStart(2, '0');
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    if (h === 0) h = 12;
    return `${String(h).padStart(2, '0')}:${m}:${s} ${ampm}`;
  },

  _fmtQty(n) {
    return parseFloat(n).toFixed(2);
  },

  _fmtPrice(n) {
    return parseFloat(n || 0).toFixed(2);
  },

  _esc(s) {
    if (!s) return '';
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  },

  // ============================================
  // AMOUNT TO WORDS (English)
  // ============================================
  _amountToWords(amount) {
    const num = Math.floor(Math.abs(parseFloat(amount) || 0));
    if (num === 0) return 'Zero';

    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    const scales = ['', 'Thousand', 'Million'];

    const chunk = (n) => {
      let str = '';
      if (n >= 100) { str += ones[Math.floor(n / 100)] + ' Hundred'; n %= 100; if (n > 0) str += ' and '; }
      if (n >= 20) { str += tens[Math.floor(n / 10)]; n %= 10; if (n > 0) str += ' '; }
      if (n > 0) str += ones[n];
      return str;
    };

    let result = '';
    let scaleIdx = 0;
    let remaining = num;

    while (remaining > 0) {
      const part = remaining % 1000;
      if (part > 0) {
        const prefix = chunk(part);
        result = prefix + (scales[scaleIdx] ? ' ' + scales[scaleIdx] : '') + (result ? ' ' : '') + result;
      }
      remaining = Math.floor(remaining / 1000);
      scaleIdx++;
    }

    return result.trim();
  },

  _amountToWordsDecimal(amount) {
    const dec = Math.round((Math.abs(parseFloat(amount) || 0) % 1) * 100);
    if (dec === 0) return 'Zero';
    return this._amountToWords(dec);
  }
};


// ============================================
// INVOICE BUILDER — A4 Sales Invoice
// Arabic + English, exact match to provided design
// ============================================
const InvoiceBuilder = {

  build(sale, biz) {
    const items = sale.items || [];
    const totalQty = items.reduce((s, i) => s + i.qty, 0);
    const dateObj = sale.date ? new Date(sale.date) : new Date();
    const dateStr = ReceiptBuilder._fmtDate(dateObj);
    const timeStr = ReceiptBuilder._fmtTime(dateObj);
    const esc = (s) => ReceiptBuilder._esc(s);

    let h = '<div class="inv-page">';

    // ========== HEADER ==========
    h += '<div class="inv-header">';

    // Left: English
    h += '<div class="inv-hdr-left">';
    h += `<div class="inv-shop-en">${esc(biz.shop_name_en || biz.shop_name || 'Shop Name')}</div>`;
    h += `<div class="inv-sub-en">${esc(biz.description_en || 'Sales & Services')}</div>`;
    if (biz.phone) h += `<div class="inv-sub-en">Mob : ${esc(biz.phone.split('\n')[0])}</div>`;
    h += '</div>';

    // Center: Logo
    h += '<div class="inv-hdr-logo">';
    if (biz.logo_path) {
      h += `<img src="${biz.logo_path}" alt="">`;
    } else {
      h += '<div style="width:55px;height:55px;border:2px solid #2060A0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:20px;color:#2060A0;">Z</div>';
    }
    h += '</div>';

    // Right: Arabic
    h += '<div class="inv-hdr-right">';
    h += `<div class="inv-shop-ar">${esc(biz.shop_name || '')}</div>`;
    h += `<div class="inv-sub-ar">${esc(biz.description_ar || '')}</div>`;
    if (biz.phone) h += `<div class="inv-sub-ar">جوال : ${esc(biz.phone.split('\n')[0])}</div>`;
    h += '</div>';

    h += '</div>'; // inv-header

    // ========== ADDRESS BAR ==========
    if (biz.address) {
      h += `<div class="inv-address-bar">* ${esc(biz.address.replace(/\n/g, ' - '))} *</div>`;
    }

    // ========== INFO GRID ==========
    h += '<table class="inv-info-grid">';

    // Row 1: CASH | SALES INVOICE | empty
    h += '<tr>';
    h += '<td class="lbl" style="width:70px">CASH</td>';
    h += '<td class="hdr-cell" colspan="2">SALES INVOICE</td>';
    h += '<td class="val-light" colspan="2"></td>';
    h += '</tr>';

    // Row 2: Invoice no | value | Mobile
    h += '<tr>';
    h += `<td><span class="lbl">Invoice no.</span><br><span class="lbl-ar">رقم الفاتورة</span></td>`;
    h += `<td class="val">${esc(sale.invoiceNumber || '')}</td>`;
    h += `<td><span class="lbl">Mobile</span><br><span class="lbl-ar">جوال</span></td>`;
    h += '<td class="val-light" colspan="2"></td>';
    h += '</tr>';

    // Row 3: Date | value | Customer VAT
    h += '<tr>';
    h += `<td><span class="lbl">Date.</span><br><span class="lbl-ar">تاريخ</span></td>`;
    h += `<td class="val">${dateStr}&nbsp;&nbsp;Time:${timeStr}</td>`;
    h += `<td><span class="lbl">Customer VAT</span><br><span class="lbl-ar">رقم الضريبي العميل</span></td>`;
    h += '<td class="val-light" colspan="2"></td>';
    h += '</tr>';

    h += '</table>';

    // Customer row
    h += `<div class="inv-cust-row"><span class="lbl">Customer</span> <span class="lbl-ar">اسم العميل :</span>&nbsp;&nbsp;<span class="val">${esc(sale.customer || 'Cash')}</span></div>`;
    h += `<div class="inv-cust-row" style="border-top:none;color:#888"><span class="lbl">Address</span> <span class="lbl-ar">العنوان</span></div>`;

    // ========== ITEMS TABLE ==========
    h += '<table class="inv-items-table">';
    h += '<thead><tr>';
    h += '<th style="width:32px">Slno<span class="th-ar">رقم</span></th>';
    h += '<th style="width:90px">Itemcode<span class="th-ar">رمز الصنف</span></th>';
    h += '<th>Itemname<span class="th-ar">الوصف</span></th>';
    h += '<th style="width:50px">Qty</th>';
    h += '<th style="width:70px">Unitprice<span class="th-ar">سعر الوحدة</span></th>';
    h += '<th style="width:70px">Amount<span class="th-ar">مقدار</span></th>';
    h += '</tr></thead>';
    h += '<tbody>';

    items.forEach((item, idx) => {
      const alt = idx % 2 === 1 ? ' item-row-alt' : '';
      // Main row: English name
      h += `<tr class="${alt}">`;
      h += `<td rowspan="2" style="text-align:center;vertical-align:middle">${idx + 1}</td>`;
      h += `<td rowspan="2">${esc(item.barcode || item.sku || '')}</td>`;
      h += `<td>${esc(item.name)}</td>`;
      h += `<td rowspan="2" class="num">${parseFloat(item.qty).toFixed(2)}</td>`;
      h += `<td rowspan="2" class="num">${parseFloat(item.price).toFixed(2)}</td>`;
      h += `<td rowspan="2" class="num">${parseFloat(item.total).toFixed(2)}</td>`;
      h += '</tr>';
      // Arabic name row
      h += `<tr class="${alt}"><td class="item-name-ar">${esc(item.name_ar || '')}</td></tr>`;
    });

    // Empty rows to fill space (like the image)
    const emptyRows = Math.max(0, 10 - items.length);
    for (let i = 0; i < emptyRows; i++) {
      h += '<tr class="empty-row"><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
    }

    h += '</tbody></table>';

    // ========== TOTAL ROW ==========
    h += '<table class="inv-total-row">';
    h += '<tr>';
    h += '<td style="width:32px"></td><td style="width:90px"></td>';
    h += '<td style="font-weight:700">Total</td>';
    h += `<td class="num" style="width:50px">${totalQty.toFixed(2)}</td>`;
    h += '<td style="width:70px"></td>';
    h += `<td class="num" style="width:70px">${parseFloat(sale.subtotal).toFixed(2)}</td>`;
    h += '</tr>';
    h += '</table>';

    // ========== FOOTER GRID ==========
    h += '<table class="inv-footer-grid">';

    // Row 1: Signatory + QR | Discount
    h += '<tr>';
    h += '<td class="sig-cell" rowspan="2">';
    h += '<div class="sig-label">Authorised Signatory</div>';
    h += '<div class="sig-label-ar">المفوض بالتوقيع</div>';
    h += '</td>';
    h += '<td class="qr-cell" rowspan="2"><canvas id="inv-qr-canvas" width="70" height="70"></canvas></td>';
    h += `<td><span class="disc-label">Discount</span>&nbsp;&nbsp;<span class="disc-label-ar">مجموع الخصومات</span></td>`;
    h += '<td class="val-light num" style="width:100px"></td>';
    h += '</tr>';

    // Row 2: Total Amount
    h += '<tr>';
    h += `<td><span class="disc-label">Total Amount</span>&nbsp;&nbsp;<span class="disc-label-ar">إجمالي المبلغ المستحق</span></td>`;
    h += `<td class="grand-amount">${parseFloat(sale.total).toFixed(2)}</td>`;
    h += '</tr>';

    h += '</table>';

    // ========== GRAND TOTAL IN WORDS ==========
    h += '<div class="inv-words-row">';
    h += '<span class="lbl">Grand total in words</span><br>';
    h += '<span class="lbl-ar">المبلغ الإجمالي</span>';
    h += `&nbsp;&nbsp;&nbsp;&nbsp;${ReceiptBuilder._amountToWords(sale.total)} Riyal and ${ReceiptBuilder._amountToWordsDecimal(sale.total)} Halala only`;
    h += '</div>';

    // ========== RETURN POLICY ==========
    h += '<div class="inv-return">* الأسترجاع خلال 24 ساعة بالحالة الأصليه للمنتج *</div>';

    h += '</div>'; // inv-page
    return h;
  },

  // ============================================
  // SHOW PREVIEW — Full page modal
  // ============================================
  async showPreview(saleData) {
    const bizR = await window.api.getBusiness();
    const biz = (bizR.success && bizR.data) ? bizR.data : {};

    const invoiceHtml = this.build(saleData, biz);

    const html = `
      <div style="overflow:auto;max-height:75vh;display:flex;justify-content:center;background:#666;padding:20px;border-radius:8px;">
        <div style="box-shadow:0 4px 30px rgba(0,0,0,0.3);">${invoiceHtml}</div>
      </div>
      <div class="receipt-actions" style="margin-top:12px;">
        <button class="btn btn-ghost" onclick="Modal.close()">Close</button>
        <button class="btn btn-primary" onclick="InvoiceBuilder.print()">🖨 Print Invoice</button>
      </div>`;

    // Use wider modal
    const modalBox = document.getElementById('modal-box');
    modalBox.style.width = '820px';

    Modal.open('Invoice Preview', html, () => {
      modalBox.style.width = '';
      Modal.close();
    });
    document.getElementById('modal-save').style.display = 'none';
    document.getElementById('modal-cancel').style.display = 'none';

    // Generate QR
    setTimeout(() => {
      const canvas = document.getElementById('inv-qr-canvas');
      if (canvas) ReceiptBuilder._drawQR(canvas, ReceiptBuilder._buildZatcaTLV(biz, saleData));
    }, 150);
  },

  print() {
    window.print();
  }
};


// ============================================
// PIN LOCK SYSTEM
// ============================================
const PinLock = {
  pin: '',
  correctPin: '',
  required: false,

  async check() {
    const r = await window.api.getSettings();
    if (!r.success || !r.data) return;
    this.correctPin = r.data.client_pin || '';
    this.required = r.data.pin_required === 1;

    if (this.required && this.correctPin) {
      document.getElementById('pin-lock-screen').style.display = 'flex';
      this.bindKeys();
    }
  },

  bindKeys() {
    // Keypad buttons
    document.getElementById('pin-keypad').addEventListener('click', (e) => {
      const btn = e.target.closest('.pin-key');
      if (!btn) return;
      const val = btn.getAttribute('data-val');

      if (val === 'clear') {
        this.pin = '';
        this.updateDots();
        document.getElementById('pin-error').textContent = '';
      } else if (val === 'enter') {
        this.submit();
      } else {
        if (this.pin.length < 6) {
          this.pin += val;
          this.updateDots();
        }
      }
    });

    // Physical keyboard
    document.addEventListener('keydown', (e) => {
      if (document.getElementById('pin-lock-screen').style.display === 'none') return;
      if (e.key >= '0' && e.key <= '9' && this.pin.length < 6) {
        this.pin += e.key;
        this.updateDots();
      } else if (e.key === 'Backspace') {
        this.pin = this.pin.slice(0, -1);
        this.updateDots();
        document.getElementById('pin-error').textContent = '';
      } else if (e.key === 'Enter') {
        this.submit();
      }
    });
  },

  updateDots() {
    const dots = document.querySelectorAll('#pin-dots .pin-dot');
    dots.forEach((dot, i) => {
      dot.classList.toggle('filled', i < this.pin.length);
    });
  },

  submit() {
    if (this.pin === this.correctPin) {
      document.getElementById('pin-lock-screen').style.display = 'none';
      this.pin = '';
    } else {
      document.getElementById('pin-error').textContent = 'Incorrect PIN';
      const dots = document.getElementById('pin-dots');
      dots.classList.add('shake');
      setTimeout(() => {
        dots.classList.remove('shake');
        this.pin = '';
        this.updateDots();
      }, 500);
    }
  }
};


// ============================================
// SETTINGS MANAGER
// ============================================
const SettingsManager = {

  async init() {
    this.bindEvents();
    await this.loadAll();
  },

  async loadAll() {
    // Business info
    const bizR = await window.api.getBusiness();
    if (bizR.success && bizR.data) {
      const b = bizR.data;
      this._set('set-shop-name', b.shop_name);
      this._set('set-address', b.address);
      this._set('set-phone', b.phone);
      this._set('set-vat', b.vat_number);
      this._set('set-cr', b.cr_number);
      this._set('set-currency', b.currency || 'SAR');
      this._set('set-tax', b.tax_rate || 15);
      this._set('set-footer', b.receipt_footer);
    }

    // PIN settings
    const setR = await window.api.getSettings();
    if (setR.success && setR.data) {
      const s = setR.data;
      this._setChecked('set-pin-required', s.pin_required === 1);
      this._set('set-pin', s.client_pin || '');
    }

    // Network
    const net = await window.api.getNetworkInfo();
    if (net) {
      this._set('set-ip', net.ip + ':' + net.port);
      this._set('set-mobile-url', net.url + '/mobile');
      this._set('set-scan-url', net.url + '/scanner');

      // Generate QR codes
      setTimeout(() => {
        this._generateSettingsQR('set-qr-mobile', net.url + '/mobile');
        this._generateSettingsQR('set-qr-scanner', net.url + '/scanner');
      }, 200);
    }
  },

  bindEvents() {
    // Save business info
    document.getElementById('set-save-biz').addEventListener('click', async () => {
      const data = {
        shop_name: this._get('set-shop-name'),
        address: this._get('set-address'),
        phone: this._get('set-phone'),
        vat_number: this._get('set-vat'),
        cr_number: this._get('set-cr'),
        currency: this._get('set-currency') || 'SAR',
        tax_rate: parseFloat(this._get('set-tax')) || 15,
        receipt_footer: this._get('set-footer')
      };
      const r = await window.api.updateBusiness(data);
      if (r.success) {
        SellEngine.taxRate = data.tax_rate;
        SellEngine.showToast('Business info saved', 'success');
      } else {
        SellEngine.showToast('Save failed: ' + (r.error || ''), 'error');
      }
    });

    // Save PIN
    document.getElementById('set-save-pin').addEventListener('click', async () => {
      const pin = this._get('set-pin');
      const required = this._getChecked('set-pin-required') ? 1 : 0;

      if (required && pin.length < 4) {
        SellEngine.showToast('PIN must be 4–6 digits', 'error');
        return;
      }
      if (pin && !/^\d{4,6}$/.test(pin)) {
        SellEngine.showToast('PIN must be 4–6 digits only', 'error');
        return;
      }

      const r = await window.api.updateSettings({ client_pin: pin, pin_required: required });
      if (r.success) {
        SellEngine.showToast('PIN settings saved', 'success');
      }
    });

    // Copy IP
    document.getElementById('set-copy-ip').addEventListener('click', () => {
      const val = document.getElementById('set-ip').value;
      navigator.clipboard.writeText(val).then(() => SellEngine.showToast('IP copied', 'success'));
    });

    // Copy mobile URL
    document.getElementById('set-copy-mobile').addEventListener('click', () => {
      const val = document.getElementById('set-mobile-url').value;
      navigator.clipboard.writeText(val).then(() => SellEngine.showToast('Mobile POS URL copied', 'success'));
    });

    // Copy scanner URL
    document.getElementById('set-copy-url').addEventListener('click', () => {
      const val = document.getElementById('set-scan-url').value;
      navigator.clipboard.writeText(val).then(() => SellEngine.showToast('Scanner URL copied', 'success'));
    });

    // Listen for device connect/disconnect from main process
    if (window.api && window.api.on) {
      window.api.on('device:connected', (data) => {
        this._updateDeviceCount(data.count);
        this._addDeviceToList(data);
      });
      window.api.on('device:disconnected', (data) => {
        this._updateDeviceCount(data.count);
        this._removeDeviceFromList(data.id);
      });
    }
  },

  _updateDeviceCount(count) {
    const el = document.getElementById('status-devices');
    if (el) el.textContent = '📱 ' + (count || 0) + ' device' + ((count || 0) !== 1 ? 's' : '');
  },

  _addDeviceToList(data) {
    const container = document.getElementById('set-devices-list');
    if (!container) return;
    // Remove "no devices" message
    if (container.querySelector('[data-empty]')) container.innerHTML = '';

    const div = document.createElement('div');
    div.setAttribute('data-device-id', data.id);
    div.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 10px;background:#F0FFF4;border:1px solid #BBF7D0;border-radius:6px;margin-bottom:4px;font-size:12px;';
    div.innerHTML = `<span style="color:#22C55E">●</span> <span style="font-weight:600">${data.name || 'Mobile Device'}</span> <span style="color:#9CA3AF;margin-left:auto;font-family:var(--font-mono);font-size:10px">${data.id ? data.id.substring(0, 8) : ''}</span>`;
    container.appendChild(div);
  },

  _removeDeviceFromList(id) {
    const el = document.querySelector(`[data-device-id="${id}"]`);
    if (el) el.remove();
    const container = document.getElementById('set-devices-list');
    if (container && container.children.length === 0) {
      container.innerHTML = '<div data-empty style="font-size:12px;color:var(--text-light);">No devices connected</div>';
    }
  },

  _generateSettingsQR(canvasId, url) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    // Reuse ReceiptBuilder's QR drawing
    if (typeof ReceiptBuilder !== 'undefined' && ReceiptBuilder._drawQR) {
      ReceiptBuilder._drawQR(canvas, btoa(url));
    }
  },

  _get(id) { const el = document.getElementById(id); return el ? el.value.trim() : ''; },
  _set(id, v) { const el = document.getElementById(id); if (el) el.value = v || ''; },
  _getChecked(id) { const el = document.getElementById(id); return el ? el.checked : false; },
  _setChecked(id, v) { const el = document.getElementById(id); if (el) el.checked = !!v; }
};


// ============================================
// OWNER MANAGER — Password-gated admin panel
// ============================================
const OwnerManager = {
  unlocked: false,

  async init() {
    this.bindGate();
  },

  // ---- Password gate ----
  bindGate() {
    const input = document.getElementById('owner-pw-input');
    const btn = document.getElementById('owner-pw-submit');
    const error = document.getElementById('owner-pw-error');

    btn.addEventListener('click', () => this._tryUnlock());
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this._tryUnlock();
    });

    // Lock button
    document.getElementById('owner-lock-btn').addEventListener('click', () => {
      this.unlocked = false;
      document.getElementById('owner-panel').style.display = 'none';
      document.getElementById('owner-gate').style.display = 'flex';
      document.getElementById('owner-pw-input').value = '';
      document.getElementById('owner-pw-error').textContent = '';
    });
  },

  async _tryUnlock() {
    const input = document.getElementById('owner-pw-input');
    const error = document.getElementById('owner-pw-error');
    const pw = input.value.trim();

    if (!pw) { error.textContent = 'Enter password'; return; }

    const r = await window.api.getSettings();
    const correctPw = (r.success && r.data) ? r.data.owner_password : '65244342726';

    if (pw === correctPw) {
      this.unlocked = true;
      error.textContent = '';
      document.getElementById('owner-gate').style.display = 'none';
      document.getElementById('owner-panel').style.display = 'block';
      await this._loadPanel();
    } else {
      error.textContent = 'Incorrect password';
      input.value = '';
      input.focus();
    }
  },

  // ---- Load all owner panel data ----
  async _loadPanel() {
    await this._loadFeatures();
    await this._loadSettings();
    this._bindPanelEvents();
  },

  async _loadFeatures() {
    const r = await window.api.dbAll("SELECT * FROM feature_visibility ORDER BY id ASC");
    const container = document.getElementById('owner-features');
    if (!r.success || !r.data || !container) return;

    container.innerHTML = r.data.map(f => `
      <div class="owner-feat-item">
        <input type="checkbox" ${f.is_visible ? 'checked' : ''} data-feat-id="${f.id}" data-feat-key="${f.feature_key}" class="owner-feat-chk">
        <div>
          <div class="owner-feat-label">${SellEngine.escHtml(f.feature_label)}</div>
          <div class="owner-feat-sub">${f.feature_key}</div>
        </div>
      </div>`).join('');

    // Feature toggle events
    container.querySelectorAll('.owner-feat-chk').forEach(chk => {
      chk.addEventListener('change', async () => {
        const id = chk.getAttribute('data-feat-id');
        const visible = chk.checked ? 1 : 0;
        await window.api.dbRun("UPDATE feature_visibility SET is_visible = ? WHERE id = ?", [visible, parseInt(id)]);
        this._applySidebarVisibility();
      });
    });
  },

  async _loadSettings() {
    const r = await window.api.getSettings();
    if (!r.success || !r.data) return;
    const s = r.data;

    document.getElementById('own-cur-pin').value = s.client_pin || '(not set)';
    document.getElementById('own-pin-required').checked = s.pin_required === 1;
    document.getElementById('own-license-type').value = s.license_type || 'unlimited';
    document.getElementById('own-license-expiry').value = s.license_expiry || '';
    document.getElementById('own-mac-locked').checked = s.mac_locked === 1;
    document.getElementById('own-mac-addr').value = s.mac_address || '(auto-detect)';
  },

  _bindPanelEvents() {
    // Change owner password
    const savePwBtn = document.getElementById('own-save-pw');
    if (savePwBtn && !savePwBtn._bound) {
      savePwBtn._bound = true;
      savePwBtn.addEventListener('click', async () => {
        const cur = document.getElementById('own-cur-pw').value.trim();
        const newPw = document.getElementById('own-new-pw').value.trim();
        const confirm = document.getElementById('own-confirm-pw').value.trim();

        const r = await window.api.getSettings();
        const correctPw = (r.success && r.data) ? r.data.owner_password : '';

        if (cur !== correctPw) { SellEngine.showToast('Current password incorrect', 'error'); return; }
        if (newPw.length < 4) { SellEngine.showToast('New password must be at least 4 characters', 'error'); return; }
        if (newPw !== confirm) { SellEngine.showToast('Passwords do not match', 'error'); return; }

        await window.api.updateSettings({ owner_password: newPw });
        document.getElementById('own-cur-pw').value = '';
        document.getElementById('own-new-pw').value = '';
        document.getElementById('own-confirm-pw').value = '';
        SellEngine.showToast('Owner password changed', 'success');
      });
    }

    // Save client PIN from owner panel
    const savePinBtn = document.getElementById('own-save-pin');
    if (savePinBtn && !savePinBtn._bound) {
      savePinBtn._bound = true;
      savePinBtn.addEventListener('click', async () => {
        const pin = document.getElementById('own-new-pin').value.trim();
        const required = document.getElementById('own-pin-required').checked ? 1 : 0;

        if (pin && !/^\d{4,6}$/.test(pin)) {
          SellEngine.showToast('PIN must be 4–6 digits', 'error');
          return;
        }

        const data = { pin_required: required };
        if (pin) data.client_pin = pin;

        await window.api.updateSettings(data);
        document.getElementById('own-cur-pin').value = pin || document.getElementById('own-cur-pin').value;
        document.getElementById('own-new-pin').value = '';
        SellEngine.showToast('Client PIN updated', 'success');
      });
    }

    // Save license
    const saveLicBtn = document.getElementById('own-save-license');
    if (saveLicBtn && !saveLicBtn._bound) {
      saveLicBtn._bound = true;
      saveLicBtn.addEventListener('click', async () => {
        await window.api.updateSettings({
          license_type: document.getElementById('own-license-type').value,
          license_expiry: document.getElementById('own-license-expiry').value
        });
        SellEngine.showToast('License saved', 'success');
      });
    }

    // Save MAC
    const saveMacBtn = document.getElementById('own-save-mac');
    if (saveMacBtn && !saveMacBtn._bound) {
      saveMacBtn._bound = true;
      saveMacBtn.addEventListener('click', async () => {
        await window.api.updateSettings({
          mac_locked: document.getElementById('own-mac-locked').checked ? 1 : 0
        });
        SellEngine.showToast('MAC settings saved', 'success');
      });
    }
  },

  // ---- Apply sidebar visibility based on feature_visibility table ----
  async _applySidebarVisibility() {
    const r = await window.api.dbAll("SELECT feature_key, is_visible FROM feature_visibility");
    if (!r.success || !r.data) return;

    const featureToPage = {
      'sell': 'sell',
      'products': 'products',
      'categories': 'categories',
      'customers': 'customers',
      'inventory': 'inventory',
      'sales_report': 'sales',
      'expenses': 'expenses',
      'settings': 'settings',
      'backup': null
    };

    r.data.forEach(f => {
      const pageKey = featureToPage[f.feature_key];
      if (pageKey) {
        const navItem = document.querySelector(`.nav-item[data-page="${pageKey}"]`);
        if (navItem) {
          navItem.style.display = f.is_visible ? 'flex' : 'none';
        }
      }
    });
  }
};


// ============================================
// CSV + PDF EXPORT UTILITY
// ============================================
const ExportUtil = {
  // Download a CSV string as file
  downloadCSV(filename, csvContent) {
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  },

  // Convert table data to CSV
  tableToCSV(headers, rows) {
    const escape = (val) => {
      const s = String(val == null ? '' : val);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    let csv = headers.map(escape).join(',') + '\n';
    rows.forEach(row => { csv += row.map(escape).join(',') + '\n'; });
    return csv;
  },

  // Generate printable PDF-style HTML and trigger print
  printReport(title, summaryHtml, tableHtml) {
    const win = window.open('', '_blank', 'width=900,height=700');
    win.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${title}</title>
      <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Segoe UI',sans-serif;font-size:12px;color:#000;padding:20px}
        h1{font-size:18px;margin-bottom:4px}
        .date{font-size:11px;color:#666;margin-bottom:16px}
        .summary{display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap}
        .summary-card{border:1px solid #ddd;border-radius:6px;padding:10px 14px;min-width:140px}
        .summary-card .label{font-size:10px;font-weight:600;color:#888;text-transform:uppercase}
        .summary-card .value{font-size:18px;font-weight:800;margin-top:2px}
        table{width:100%;border-collapse:collapse;font-size:11px}
        th{background:#f5f5f5;border:1px solid #ddd;padding:6px 8px;text-align:left;font-size:10px;font-weight:700;text-transform:uppercase}
        td{border:1px solid #eee;padding:5px 8px}
        .num{text-align:right;font-family:Consolas,monospace}
        .footer{margin-top:20px;font-size:10px;color:#aaa;text-align:center}
        @media print{@page{size:A4;margin:10mm}}
      </style>
    </head><body>
      <h1>${title}</h1>
      <div class="date">Generated: ${new Date().toLocaleString()}</div>
      ${summaryHtml}
      ${tableHtml}
      <div class="footer">ZaZ POS Pro — Report</div>
    </body></html>`);
    win.document.close();
    setTimeout(() => win.print(), 400);
  }
};


// ============================================
// SALES MANAGER — Sales History
// ============================================
const SalesManager = {
  sales: [],

  async init() {
    this.bindEvents();
    // Set default dates
    const today = new Date().toISOString().split('T')[0];
    const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
    document.getElementById('sales-from').value = monthAgo;
    document.getElementById('sales-to').value = today;
    await this.load();
    this.render();
  },

  async load() {
    const from = document.getElementById('sales-from').value || '2000-01-01';
    const to = document.getElementById('sales-to').value || '2099-12-31';
    const r = await window.api.dbAll(
      `SELECT s.*, c.name as customer_name,
       (SELECT COUNT(*) FROM sale_items WHERE sale_id = s.id) as item_count
       FROM sales s LEFT JOIN customers c ON s.customer_id = c.id
       WHERE date(s.created_at) >= ? AND date(s.created_at) <= ?
       ORDER BY s.created_at DESC`,
      [from, to]
    );
    this.sales = (r.success && r.data) ? r.data : [];
  },

  render() {
    const tbody = document.getElementById('sales-tbody');
    const empty = document.getElementById('sales-empty');
    const countEl = document.getElementById('sales-count');
    if (!tbody) return;

    let list = this.sales;
    const search = document.getElementById('sales-search').value.toLowerCase().trim();
    if (search) {
      list = list.filter(s => (s.invoice_number || '').toLowerCase().includes(search));
    }

    countEl.textContent = list.length + ' sale' + (list.length !== 1 ? 's' : '');

    if (list.length === 0) { tbody.innerHTML = ''; empty.style.display = 'block'; return; }
    empty.style.display = 'none';

    tbody.innerHTML = list.map((s, i) => {
      const isVoid = s.is_void === 1;
      const dateStr = (s.created_at || '').substring(0, 16).replace('T', ' ');
      return `<tr${isVoid ? ' class="voided"' : ''}>
        <td style="color:var(--text-light)">${i + 1}</td>
        <td class="cell-name" style="font-family:var(--font-mono)">${SellEngine.escHtml(s.invoice_number)}</td>
        <td style="font-size:11px;color:var(--text-secondary)">${dateStr}</td>
        <td>${s.item_count || 0}</td>
        <td class="cell-price" style="font-weight:700">${parseFloat(s.total).toFixed(2)}</td>
        <td style="font-size:11px">${s.payment_method || 'cash'}</td>
        <td>${isVoid ? '<span class="void-stamp">VOID</span>' : '<span class="sale-badge completed">OK</span>'}</td>
        <td><div class="pm-actions">
          <button class="pm-act-btn" title="View" onclick="SalesManager.viewSale(${s.id})">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
          ${!isVoid ? `<button class="pm-act-btn danger" title="Void" onclick="VoidManager.voidSale(${s.id})">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
          </button>` : ''}
        </div></td>
      </tr>`;
    }).join('');
  },

  async viewSale(id) {
    const saleR = await window.api.dbGet("SELECT s.*, c.name as customer_name FROM sales s LEFT JOIN customers c ON s.customer_id=c.id WHERE s.id=?", [id]);
    const itemsR = await window.api.dbAll("SELECT * FROM sale_items WHERE sale_id=?", [id]);
    if (!saleR.success || !saleR.data) return;
    const s = saleR.data;
    const items = (itemsR.success && itemsR.data) ? itemsR.data : [];

    let html = `<div style="font-size:12px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
        <div><strong>Invoice:</strong> ${SellEngine.escHtml(s.invoice_number)}</div>
        <div><strong>Date:</strong> ${(s.created_at || '').substring(0, 19)}</div>
        <div><strong>Customer:</strong> ${SellEngine.escHtml(s.customer_name || 'Cash')}</div>
        <div><strong>Method:</strong> ${s.payment_method}</div>
      </div>
      <table class="pm-table" style="font-size:11px">
        <thead><tr><th>Product</th><th style="width:50px">Qty</th><th style="width:70px">Price</th><th style="width:70px">Total</th></tr></thead>
        <tbody>${items.map(i => `<tr><td>${SellEngine.escHtml(i.product_name)}</td><td>${i.qty}</td><td class="cell-price">${parseFloat(i.unit_price).toFixed(2)}</td><td class="cell-price" style="font-weight:700">${parseFloat(i.total).toFixed(2)}</td></tr>`).join('')}</tbody>
      </table>
      <div style="text-align:right;margin-top:10px;font-size:13px">
        <div>Subtotal: <strong>${parseFloat(s.subtotal).toFixed(2)}</strong></div>
        <div>Tax: <strong>${parseFloat(s.tax_amount).toFixed(2)}</strong></div>
        <div style="font-size:16px;font-weight:900;margin-top:4px">Total: ${parseFloat(s.total).toFixed(2)} SAR</div>
      </div>
    </div>`;
    Modal.open('Sale #' + s.invoice_number, html, () => Modal.close());
    document.getElementById('modal-save').textContent = 'Close';
    document.getElementById('modal-cancel').style.display = 'none';
  },

  bindEvents() {
    document.getElementById('sales-filter-btn').addEventListener('click', async () => { await this.load(); this.render(); });
    document.getElementById('sales-search').addEventListener('input', () => this.render());
    document.getElementById('sales-export-csv').addEventListener('click', () => {
      const headers = ['Invoice', 'Date', 'Customer', 'Items', 'Subtotal', 'Tax', 'Total', 'Method', 'Status'];
      const rows = this.sales.map(s => [
        s.invoice_number, (s.created_at || '').substring(0, 19), s.customer_name || 'Cash',
        s.item_count, parseFloat(s.subtotal).toFixed(2), parseFloat(s.tax_amount).toFixed(2),
        parseFloat(s.total).toFixed(2), s.payment_method, s.is_void ? 'VOID' : 'OK'
      ]);
      ExportUtil.downloadCSV('sales_report.csv', ExportUtil.tableToCSV(headers, rows));
      SellEngine.showToast('CSV exported', 'success');
    });
    document.getElementById('sales-export-pdf').addEventListener('click', () => {
      const total = this.sales.filter(s => !s.is_void).reduce((sum, s) => sum + parseFloat(s.total), 0);
      const summary = `<div class="summary"><div class="summary-card"><div class="label">Total Sales</div><div class="value">${this.sales.length}</div></div><div class="summary-card"><div class="label">Revenue</div><div class="value">${total.toFixed(2)}</div></div></div>`;
      const table = `<table><thead><tr><th>#</th><th>Invoice</th><th>Date</th><th>Total</th><th>Method</th><th>Status</th></tr></thead><tbody>${this.sales.map((s, i) => `<tr><td>${i+1}</td><td>${s.invoice_number}</td><td>${(s.created_at||'').substring(0,16)}</td><td class="num">${parseFloat(s.total).toFixed(2)}</td><td>${s.payment_method}</td><td>${s.is_void?'VOID':'OK'}</td></tr>`).join('')}</tbody></table>`;
      ExportUtil.printReport('Sales Report', summary, table);
    });
  }
};


// ============================================
// EXPENSE MANAGER
// ============================================
const ExpenseManager = {
  expenses: [],

  async init() {
    this.bindEvents();
    const today = new Date().toISOString().split('T')[0];
    const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
    document.getElementById('exp-from').value = monthAgo;
    document.getElementById('exp-to').value = today;
    await this.load();
    this.render();
  },

  async load() {
    const from = document.getElementById('exp-from').value || '2000-01-01';
    const to = document.getElementById('exp-to').value || '2099-12-31';
    const r = await window.api.dbAll(
      "SELECT * FROM expenses WHERE is_deleted = 0 AND date >= ? AND date <= ? ORDER BY date DESC, id DESC",
      [from, to]
    );
    this.expenses = (r.success && r.data) ? r.data : [];
  },

  render() {
    const tbody = document.getElementById('exp-tbody');
    const empty = document.getElementById('exp-empty');
    const totalEl = document.getElementById('exp-total-display');
    if (!tbody) return;

    const total = this.expenses.reduce((s, e) => s + parseFloat(e.amount), 0);
    totalEl.textContent = 'Total: ' + total.toFixed(2);

    if (this.expenses.length === 0) { tbody.innerHTML = ''; empty.style.display = 'block'; return; }
    empty.style.display = 'none';

    tbody.innerHTML = this.expenses.map((e, i) => `
      <tr>
        <td style="color:var(--text-light)">${i + 1}</td>
        <td class="cell-name">${SellEngine.escHtml(e.description || '—')}</td>
        <td><span class="exp-cat-badge">${SellEngine.escHtml(e.category)}</span></td>
        <td class="cell-price" style="color:var(--accent-red);font-weight:700">${parseFloat(e.amount).toFixed(2)}</td>
        <td style="font-size:11px;color:var(--text-secondary)">${e.date}</td>
        <td><div class="pm-actions">
          <button class="pm-act-btn" title="Edit" onclick="ExpenseManager.openForm(${e.id})">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="pm-act-btn danger" title="Delete" onclick="ExpenseManager.deleteExp(${e.id})">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>
        </div></td>
      </tr>`).join('');
  },

  openForm(editId) {
    const exp = editId ? this.expenses.find(e => e.id === editId) : null;
    const html = `
      <div class="form-row">
        <label class="form-label">Description *</label>
        <input class="form-input" id="f-exp-desc" value="${exp ? SellEngine.escHtml(exp.description) : ''}" placeholder="e.g. Rent, Electricity...">
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Amount *</label>
          <input class="form-input form-input-mono" id="f-exp-amount" type="number" step="0.01" min="0" value="${exp ? exp.amount : ''}">
        </div>
        <div>
          <label class="form-label">Category</label>
          <select class="form-select" id="f-exp-cat">
            <option value="General"${exp && exp.category==='General'?' selected':''}>General</option>
            <option value="Rent"${exp && exp.category==='Rent'?' selected':''}>Rent</option>
            <option value="Utilities"${exp && exp.category==='Utilities'?' selected':''}>Utilities</option>
            <option value="Salary"${exp && exp.category==='Salary'?' selected':''}>Salary</option>
            <option value="Supplies"${exp && exp.category==='Supplies'?' selected':''}>Supplies</option>
            <option value="Transport"${exp && exp.category==='Transport'?' selected':''}>Transport</option>
            <option value="Other"${exp && exp.category==='Other'?' selected':''}>Other</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <label class="form-label">Date</label>
        <input class="form-input" id="f-exp-date" type="date" value="${exp ? exp.date : new Date().toISOString().split('T')[0]}">
      </div>`;

    Modal.open(exp ? 'Edit Expense' : 'Add Expense', html, async () => {
      const desc = Modal.getVal('f-exp-desc');
      const amount = Modal.getNum('f-exp-amount');
      if (!desc) { Modal.showError('Description required'); return; }
      if (amount <= 0) { Modal.showError('Amount must be > 0'); return; }

      const cat = Modal.getVal('f-exp-cat');
      const date = Modal.getVal('f-exp-date') || new Date().toISOString().split('T')[0];

      if (exp) {
        await window.api.dbRun("UPDATE expenses SET description=?, amount=?, category=?, date=? WHERE id=?", [desc, amount, cat, date, exp.id]);
      } else {
        await window.api.dbRun("INSERT INTO expenses (description, amount, category, date) VALUES (?,?,?,?)", [desc, amount, cat, date]);
      }
      Modal.close();
      await this.load(); this.render();
      SellEngine.showToast(exp ? 'Expense updated' : 'Expense added', 'success');
    });
  },

  async deleteExp(id) {
    if (!confirm('Delete this expense?')) return;
    await window.api.dbRun("UPDATE expenses SET is_deleted = 1 WHERE id = ?", [id]);
    await this.load(); this.render();
  },

  bindEvents() {
    document.getElementById('exp-add-btn').addEventListener('click', () => this.openForm());
    document.getElementById('exp-filter-btn').addEventListener('click', async () => { await this.load(); this.render(); });
    document.getElementById('exp-export-csv').addEventListener('click', () => {
      const headers = ['Description', 'Category', 'Amount', 'Date'];
      const rows = this.expenses.map(e => [e.description, e.category, parseFloat(e.amount).toFixed(2), e.date]);
      ExportUtil.downloadCSV('expenses_report.csv', ExportUtil.tableToCSV(headers, rows));
      SellEngine.showToast('CSV exported', 'success');
    });
  }
};


// ============================================
// REPORT MANAGER — Sales / Profit / Expense / Stock
// ============================================
const ReportManager = {
  currentType: 'sales',

  async init() {
    this.bindEvents();
  },

  bindEvents() {
    // Report tabs
    document.getElementById('rpt-tabs').addEventListener('click', (e) => {
      const tab = e.target.closest('.rpt-tab');
      if (!tab) return;
      document.querySelectorAll('.rpt-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      this.currentType = tab.getAttribute('data-rpt');
    });

    // Range selector
    document.getElementById('rpt-range').addEventListener('change', (e) => {
      const custom = e.target.value === 'custom';
      document.getElementById('rpt-from').style.display = custom ? 'block' : 'none';
      document.getElementById('rpt-to').style.display = custom ? 'block' : 'none';
    });

    // Generate
    document.getElementById('rpt-generate').addEventListener('click', () => this.generate());

    // Export
    document.getElementById('rpt-export-csv').addEventListener('click', () => this._exportCSV());
    document.getElementById('rpt-export-pdf').addEventListener('click', () => this._exportPDF());
    document.getElementById('rpt-print').addEventListener('click', () => this._exportPDF());
  },

  _getDateRange() {
    const range = document.getElementById('rpt-range').value;
    const today = new Date();
    let from, to;
    to = today.toISOString().split('T')[0];

    if (range === 'today') {
      from = to;
    } else if (range === 'week') {
      const d = new Date(today); d.setDate(d.getDate() - d.getDay());
      from = d.toISOString().split('T')[0];
    } else if (range === 'month') {
      from = today.toISOString().substring(0, 8) + '01';
    } else {
      from = document.getElementById('rpt-from').value || '2000-01-01';
      to = document.getElementById('rpt-to').value || to;
    }
    return { from, to };
  },

  _lastData: null,

  async generate() {
    const { from, to } = this._getDateRange();
    const type = this.currentType;
    const summary = document.getElementById('rpt-summary');
    const content = document.getElementById('rpt-content');

    if (type === 'sales') {
      const r = await window.api.dbAll(
        "SELECT * FROM sales WHERE date(created_at) >= ? AND date(created_at) <= ? AND is_void = 0 ORDER BY created_at DESC", [from, to]);
      const sales = (r.success && r.data) ? r.data : [];
      const totalRev = sales.reduce((s, x) => s + parseFloat(x.total), 0);
      const totalTax = sales.reduce((s, x) => s + parseFloat(x.tax_amount), 0);
      const avgSale = sales.length > 0 ? totalRev / sales.length : 0;
      const cashSales = sales.filter(s => s.payment_method === 'cash').reduce((s, x) => s + parseFloat(x.total), 0);
      const cardSales = sales.filter(s => s.payment_method === 'card').reduce((s, x) => s + parseFloat(x.total), 0);

      summary.innerHTML = `
        <div class="dash-card"><div class="dash-card-label">Total Sales</div><div class="dash-card-value">${sales.length}</div></div>
        <div class="dash-card"><div class="dash-card-label">Revenue</div><div class="dash-card-value text-green">${totalRev.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Tax Collected</div><div class="dash-card-value">${totalTax.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Avg Sale</div><div class="dash-card-value">${avgSale.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Cash</div><div class="dash-card-value">${cashSales.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Card</div><div class="dash-card-value">${cardSales.toFixed(2)}</div></div>`;

      content.innerHTML = `<table class="pm-table"><thead><tr><th>#</th><th>Invoice</th><th>Date</th><th>Method</th><th style="text-align:right">Total</th></tr></thead>
        <tbody>${sales.map((s, i) => `<tr><td>${i+1}</td><td style="font-family:var(--font-mono)">${s.invoice_number}</td><td style="font-size:11px">${(s.created_at||'').substring(0,16)}</td><td>${s.payment_method}</td><td class="cell-price" style="font-weight:700;text-align:right">${parseFloat(s.total).toFixed(2)}</td></tr>`).join('')}</tbody></table>`;

      this._lastData = { title: 'Sales Report', headers: ['#','Invoice','Date','Method','Total'], rows: sales.map((s,i) => [i+1, s.invoice_number, (s.created_at||'').substring(0,16), s.payment_method, parseFloat(s.total).toFixed(2)]), summaryHtml: summary.innerHTML };

    } else if (type === 'profit') {
      const r = await window.api.dbAll(
        `SELECT si.product_name, SUM(si.qty) as total_qty, SUM(si.total) as total_revenue, SUM(si.cost_price * si.qty) as total_cost
         FROM sale_items si JOIN sales s ON si.sale_id = s.id
         WHERE date(s.created_at) >= ? AND date(s.created_at) <= ? AND s.is_void = 0
         GROUP BY si.product_id ORDER BY total_revenue DESC`, [from, to]);
      const items = (r.success && r.data) ? r.data : [];
      const revenue = items.reduce((s, x) => s + parseFloat(x.total_revenue), 0);
      const cost = items.reduce((s, x) => s + parseFloat(x.total_cost || 0), 0);
      const profit = revenue - cost;
      const margin = revenue > 0 ? (profit / revenue * 100) : 0;

      const expR = await window.api.dbAll("SELECT COALESCE(SUM(amount),0) as total FROM expenses WHERE is_deleted=0 AND date >= ? AND date <= ?", [from, to]);
      const expenses = (expR.success && expR.data && expR.data[0]) ? parseFloat(expR.data[0].total) : 0;
      const netProfit = profit - expenses;

      summary.innerHTML = `
        <div class="dash-card"><div class="dash-card-label">Revenue</div><div class="dash-card-value text-blue">${revenue.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Cost</div><div class="dash-card-value">${cost.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Gross Profit</div><div class="dash-card-value text-green">${profit.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Margin</div><div class="dash-card-value">${margin.toFixed(1)}%</div></div>
        <div class="dash-card"><div class="dash-card-label">Expenses</div><div class="dash-card-value text-red">${expenses.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Net Profit</div><div class="dash-card-value ${netProfit>=0?'text-green':'text-red'}">${netProfit.toFixed(2)}</div></div>`;

      content.innerHTML = `<table class="pm-table"><thead><tr><th>#</th><th>Product</th><th style="text-align:right">Qty Sold</th><th style="text-align:right">Revenue</th><th style="text-align:right">Cost</th><th style="text-align:right">Profit</th></tr></thead>
        <tbody>${items.map((p, i) => {const pr = parseFloat(p.total_revenue) - parseFloat(p.total_cost||0); return `<tr><td>${i+1}</td><td class="cell-name">${SellEngine.escHtml(p.product_name)}</td><td class="num">${parseFloat(p.total_qty).toFixed(0)}</td><td class="num">${parseFloat(p.total_revenue).toFixed(2)}</td><td class="num">${parseFloat(p.total_cost||0).toFixed(2)}</td><td class="num" style="font-weight:700;color:${pr>=0?'var(--accent-green)':'var(--accent-red)'}">${pr.toFixed(2)}</td></tr>`;}).join('')}</tbody></table>`;

      this._lastData = { title: 'Profit Report', headers: ['#','Product','Qty','Revenue','Cost','Profit'], rows: items.map((p,i) => [i+1, p.product_name, parseFloat(p.total_qty).toFixed(0), parseFloat(p.total_revenue).toFixed(2), parseFloat(p.total_cost||0).toFixed(2), (parseFloat(p.total_revenue)-parseFloat(p.total_cost||0)).toFixed(2)]), summaryHtml: summary.innerHTML };

    } else if (type === 'expenses') {
      const r = await window.api.dbAll("SELECT * FROM expenses WHERE is_deleted=0 AND date >= ? AND date <= ? ORDER BY date DESC", [from, to]);
      const exps = (r.success && r.data) ? r.data : [];
      const total = exps.reduce((s, e) => s + parseFloat(e.amount), 0);
      // Group by category
      const byCat = {};
      exps.forEach(e => { byCat[e.category] = (byCat[e.category] || 0) + parseFloat(e.amount); });

      summary.innerHTML = `
        <div class="dash-card"><div class="dash-card-label">Total Expenses</div><div class="dash-card-value text-red">${total.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Count</div><div class="dash-card-value">${exps.length}</div></div>
        ${Object.entries(byCat).map(([cat, amt]) => `<div class="dash-card"><div class="dash-card-label">${SellEngine.escHtml(cat)}</div><div class="dash-card-value">${amt.toFixed(2)}</div></div>`).join('')}`;

      content.innerHTML = `<table class="pm-table"><thead><tr><th>#</th><th>Description</th><th>Category</th><th>Date</th><th style="text-align:right">Amount</th></tr></thead>
        <tbody>${exps.map((e, i) => `<tr><td>${i+1}</td><td>${SellEngine.escHtml(e.description)}</td><td><span class="exp-cat-badge">${e.category}</span></td><td style="font-size:11px">${e.date}</td><td class="num" style="color:var(--accent-red);font-weight:700">${parseFloat(e.amount).toFixed(2)}</td></tr>`).join('')}</tbody></table>`;

      this._lastData = { title: 'Expense Report', headers: ['#','Description','Category','Date','Amount'], rows: exps.map((e,i) => [i+1, e.description, e.category, e.date, parseFloat(e.amount).toFixed(2)]), summaryHtml: summary.innerHTML };

    } else if (type === 'stock') {
      const r = await window.api.dbAll(
        `SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id
         WHERE p.is_deleted=0 AND p.track_stock=1 ORDER BY p.stock_qty ASC`);
      const prods = (r.success && r.data) ? r.data : [];
      const totalVal = prods.reduce((s, p) => s + (parseFloat(p.cost_price) * parseFloat(p.stock_qty)), 0);
      const lowCount = prods.filter(p => p.stock_qty <= p.low_stock_threshold && p.stock_qty > 0).length;
      const outCount = prods.filter(p => p.stock_qty <= 0).length;

      summary.innerHTML = `
        <div class="dash-card"><div class="dash-card-label">Tracked Items</div><div class="dash-card-value">${prods.length}</div></div>
        <div class="dash-card"><div class="dash-card-label">Stock Value (cost)</div><div class="dash-card-value text-blue">${totalVal.toFixed(2)}</div></div>
        <div class="dash-card"><div class="dash-card-label">Low Stock</div><div class="dash-card-value text-orange">${lowCount}</div></div>
        <div class="dash-card"><div class="dash-card-label">Out of Stock</div><div class="dash-card-value text-red">${outCount}</div></div>`;

      content.innerHTML = `<table class="pm-table"><thead><tr><th>#</th><th>Product</th><th>Category</th><th style="text-align:right">Qty</th><th style="text-align:right">Cost</th><th style="text-align:right">Value</th><th>Status</th></tr></thead>
        <tbody>${prods.map((p, i) => {
          const isOut = p.stock_qty <= 0;
          const isLow = !isOut && p.stock_qty <= p.low_stock_threshold;
          const val = (parseFloat(p.cost_price) * parseFloat(p.stock_qty)).toFixed(2);
          return `<tr><td>${i+1}</td><td class="cell-name">${SellEngine.escHtml(p.name)}</td><td style="font-size:11px">${SellEngine.escHtml(p.cat_name||'—')}</td><td class="num cell-stock ${isOut?'out':isLow?'low':''}">${Math.floor(p.stock_qty)}</td><td class="num">${parseFloat(p.cost_price).toFixed(2)}</td><td class="num">${val}</td><td>${isOut?'<span class="inv-badge out">OUT</span>':isLow?'<span class="inv-badge low">LOW</span>':'<span class="inv-badge ok">OK</span>'}</td></tr>`;
        }).join('')}</tbody></table>`;

      this._lastData = { title: 'Stock Report', headers: ['#','Product','Category','Qty','Cost','Value','Status'], rows: prods.map((p,i) => [i+1, p.name, p.cat_name||'', Math.floor(p.stock_qty), parseFloat(p.cost_price).toFixed(2), (parseFloat(p.cost_price)*parseFloat(p.stock_qty)).toFixed(2), p.stock_qty<=0?'OUT':p.stock_qty<=p.low_stock_threshold?'LOW':'OK']), summaryHtml: summary.innerHTML };
    }
  },

  _exportCSV() {
    if (!this._lastData) { SellEngine.showToast('Generate a report first', 'error'); return; }
    ExportUtil.downloadCSV(this._lastData.title.replace(/ /g, '_').toLowerCase() + '.csv', ExportUtil.tableToCSV(this._lastData.headers, this._lastData.rows));
    SellEngine.showToast('CSV exported', 'success');
  },

  _exportPDF() {
    if (!this._lastData) { SellEngine.showToast('Generate a report first', 'error'); return; }
    const d = this._lastData;
    const tableHtml = `<table><thead><tr>${d.headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${d.rows.map(r=>`<tr>${r.map((c,i)=>`<td${i>=2?' class="num"':''}>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    ExportUtil.printReport(d.title, d.summaryHtml || '', tableHtml);
  }
};


// ============================================
// BACKUP MANAGER — Local + Google Drive
// ============================================
const BackupManager = {
  autoBackupInterval: null,
  AUTO_INTERVAL: 3600000, // 1 hour

  async init() {
    this.bindEvents();
    await this.loadList();
    this.startAutoBackup();
  },

  bindEvents() {
    // Create backup
    document.getElementById('bkp-create').addEventListener('click', async () => {
      SellEngine.showToast('Creating backup...', 'info');
      const r = await window.api.backupCreate('manual');
      if (r.success) {
        SellEngine.showToast('Backup created: ' + r.data.filename, 'success');
        await this.loadList();
      } else {
        SellEngine.showToast('Backup failed: ' + (r.error || ''), 'error');
      }
    });

    // Import
    document.getElementById('bkp-import').addEventListener('click', async () => {
      const r = await window.api.backupImport();
      if (r.success) {
        SellEngine.showToast('Backup imported: ' + r.data.filename, 'success');
        await this.loadList();
      }
    });

    // Open folder
    document.getElementById('bkp-open-folder').addEventListener('click', async () => {
      await window.api.backupOpenFolder();
    });

    // Auto backup toggle
    document.getElementById('bkp-auto-enabled').addEventListener('change', (e) => {
      if (e.target.checked) {
        this.startAutoBackup();
      } else {
        this.stopAutoBackup();
      }
    });

    // Google Drive upload
    document.getElementById('gdrive-upload').addEventListener('click', async () => {
      const token = document.getElementById('gdrive-token').value.trim();
      if (!token) { SellEngine.showToast('Enter Google OAuth token first', 'error'); return; }

      // Create fresh backup first
      SellEngine.showToast('Creating backup for upload...', 'info');
      const bkp = await window.api.backupCreate('gdrive');
      if (!bkp.success) { SellEngine.showToast('Backup failed', 'error'); return; }

      SellEngine.showToast('Uploading to Google Drive...', 'info');
      const r = await window.api.gdriveUpload({ filePath: bkp.data.path, accessToken: token });
      if (r.success) {
        SellEngine.showToast('Uploaded to Google Drive: ' + r.name, 'success');
      } else {
        SellEngine.showToast('Upload failed: ' + (r.error || ''), 'error');
      }
    });

    // Google Drive list
    document.getElementById('gdrive-list').addEventListener('click', async () => {
      const token = document.getElementById('gdrive-token').value.trim();
      if (!token) { SellEngine.showToast('Enter Google OAuth token first', 'error'); return; }

      SellEngine.showToast('Loading Drive backups...', 'info');
      const r = await window.api.gdriveList(token);
      if (r.success) {
        this.renderDriveList(r.data, token);
      } else {
        SellEngine.showToast('Failed: ' + (r.error || ''), 'error');
      }
    });
  },

  async loadList() {
    const r = await window.api.backupList();
    const tbody = document.getElementById('bkp-tbody');
    const empty = document.getElementById('bkp-empty');
    if (!tbody) return;

    const files = (r.success && r.data) ? r.data : [];

    if (files.length === 0) {
      tbody.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';

    tbody.innerHTML = files.map(f => {
      const sizeKB = (f.size / 1024).toFixed(1);
      const sizeMB = (f.size / 1048576).toFixed(2);
      const sizeStr = f.size > 1048576 ? sizeMB + ' MB' : sizeKB + ' KB';
      const dateStr = f.date ? new Date(f.date).toLocaleString() : '';
      const safePath = SellEngine.escHtml(f.path).replace(/'/g, "\\'");

      return `<tr>
        <td style="font-size:11px;font-family:var(--font-mono)">${SellEngine.escHtml(f.filename)}</td>
        <td style="font-size:11px;color:var(--text-secondary)">${sizeStr}</td>
        <td style="font-size:11px;color:var(--text-secondary)">${dateStr}</td>
        <td>
          <div class="pm-actions" style="gap:3px">
            <button class="pm-act-btn" title="Restore" onclick="BackupManager.restore('${safePath}')">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 105.64-12.36L1 10"/></svg>
            </button>
            <button class="pm-act-btn" title="Export" onclick="BackupManager.exportFile('${safePath}')">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            </button>
            <button class="pm-act-btn danger" title="Delete" onclick="BackupManager.deleteBackup('${safePath}')">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
            </button>
          </div>
        </td>
      </tr>`;
    }).join('');
  },

  async restore(backupPath) {
    if (!confirm('Restore from this backup?\n\nThis will replace ALL current data.\nA safety backup of current data will be created first.')) return;

    SellEngine.showToast('Restoring...', 'info');
    const r = await window.api.backupRestore(backupPath);
    if (r.success) {
      SellEngine.showToast('Database restored! Reloading...', 'success');
      // Reload all data
      setTimeout(() => window.location.reload(), 1500);
    } else {
      SellEngine.showToast('Restore failed: ' + (r.error || ''), 'error');
    }
  },

  async exportFile(backupPath) {
    const r = await window.api.backupExport(backupPath);
    if (r.success) {
      SellEngine.showToast('Exported to: ' + r.path, 'success');
    }
  },

  async deleteBackup(backupPath) {
    if (!confirm('Delete this backup file permanently?')) return;
    const r = await window.api.backupDelete(backupPath);
    if (r.success) {
      SellEngine.showToast('Backup deleted', 'info');
      await this.loadList();
    }
  },

  renderDriveList(files, token) {
    const container = document.getElementById('gdrive-backups');
    if (!container) return;

    if (!files || files.length === 0) {
      container.innerHTML = '<div style="font-size:12px;color:var(--text-light);padding:8px;">No backups found on Google Drive</div>';
      return;
    }

    container.innerHTML = `
      <div class="form-label" style="margin-bottom:6px;">Google Drive Backups (${files.length})</div>
      <div class="pm-table-wrap" style="max-height:200px;overflow:auto;">
        <table class="pm-table">
          <thead><tr><th>Name</th><th style="width:90px">Size</th><th style="width:130px">Modified</th><th style="width:80px">Actions</th></tr></thead>
          <tbody>${files.map(f => {
            const size = f.size ? ((parseInt(f.size) / 1024).toFixed(1) + ' KB') : '—';
            const date = f.modifiedTime ? new Date(f.modifiedTime).toLocaleDateString() : '';
            return `<tr>
              <td style="font-size:11px;font-family:var(--font-mono)">${SellEngine.escHtml(f.name)}</td>
              <td style="font-size:11px;color:var(--text-secondary)">${size}</td>
              <td style="font-size:11px;color:var(--text-secondary)">${date}</td>
              <td><button class="pm-act-btn" title="Download" onclick="BackupManager.downloadFromDrive('${f.id}','${SellEngine.escHtml(f.name)}')">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              </button></td>
            </tr>`;
          }).join('')}</tbody>
        </table>
      </div>`;
  },

  async downloadFromDrive(fileId, fileName) {
    const token = document.getElementById('gdrive-token').value.trim();
    if (!token) { SellEngine.showToast('Token required', 'error'); return; }

    SellEngine.showToast('Downloading from Drive...', 'info');
    const r = await window.api.gdriveDownload({ fileId, fileName, accessToken: token });
    if (r.success) {
      SellEngine.showToast('Downloaded: ' + fileName, 'success');
      await this.loadList();
    } else {
      SellEngine.showToast('Download failed: ' + (r.error || ''), 'error');
    }
  },

  startAutoBackup() {
    this.stopAutoBackup();
    const chk = document.getElementById('bkp-auto-enabled');
    if (chk && !chk.checked) return;

    this.autoBackupInterval = setInterval(async () => {
      console.log('[BACKUP] Auto backup triggered');
      const r = await window.api.backupCreate('auto');
      if (r.success) {
        console.log('[BACKUP] Auto backup created:', r.data.filename);
        // Clean old auto backups — keep last 5
        const list = await window.api.backupList();
        if (list.success && list.data) {
          const autos = list.data.filter(f => f.filename.includes('_auto'));
          if (autos.length > 5) {
            for (let i = 5; i < autos.length; i++) {
              await window.api.backupDelete(autos[i].path);
            }
          }
        }
      }
    }, this.AUTO_INTERVAL);

    console.log('[BACKUP] Auto backup started (every 1 hour)');
  },

  stopAutoBackup() {
    if (this.autoBackupInterval) {
      clearInterval(this.autoBackupInterval);
      this.autoBackupInterval = null;
      console.log('[BACKUP] Auto backup stopped');
    }
  }
};


// ============================================
// CUSTOMER MANAGER
// ============================================
const CustomerManager = {
  customers: [],
  searchTerm: '',
  filter: 'all',

  async init() {
    await this.load();
    this.render();
    this.bindEvents();
  },

  async load() {
    const r = await window.api.dbAll(
      `SELECT c.*, (SELECT COUNT(*) FROM sales WHERE customer_id = c.id AND is_void = 0) as sale_count
       FROM customers c WHERE c.is_deleted = 0 ORDER BY c.name ASC`
    );
    this.customers = (r.success && r.data) ? r.data : [];
  },

  render() {
    const tbody = document.getElementById('cust-tbody');
    const empty = document.getElementById('cust-empty');
    const countEl = document.getElementById('cust-count');
    if (!tbody) return;

    let list = this.customers;
    if (this.filter === 'due') list = list.filter(c => c.balance_due > 0);
    if (this.searchTerm) {
      const t = this.searchTerm.toLowerCase();
      list = list.filter(c => (c.name && c.name.toLowerCase().includes(t)) || (c.phone && c.phone.includes(t)));
    }

    if (countEl) countEl.textContent = list.length + ' customer' + (list.length !== 1 ? 's' : '');

    if (list.length === 0) { tbody.innerHTML = ''; empty.style.display = 'block'; return; }
    empty.style.display = 'none';

    tbody.innerHTML = list.map((c, i) => {
      const hasDue = c.balance_due > 0;
      return `<tr>
        <td style="color:var(--text-light)">${i + 1}</td>
        <td class="cell-name">${SellEngine.escHtml(c.name)}</td>
        <td style="font-size:12px;color:var(--text-secondary)">${SellEngine.escHtml(c.phone || '—')}</td>
        <td class="cust-due ${hasDue ? 'has-due' : 'clear'}">${parseFloat(c.balance_due).toFixed(2)}</td>
        <td>${c.sale_count || 0}</td>
        <td><div class="pm-actions" style="gap:3px">
          <button class="pm-act-btn" title="View" onclick="CustomerManager.viewCustomer(${c.id})">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
          <button class="pm-act-btn" title="Edit" onclick="CustomerManager.openForm(${c.id})">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          ${hasDue ? `<button class="pm-act-btn" title="Receive Payment" onclick="CustomerManager.receivePayment(${c.id})" style="color:var(--accent-green)">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
          </button>` : ''}
          ${c.id !== 1 ? `<button class="pm-act-btn danger" title="Delete" onclick="CustomerManager.deleteCustomer(${c.id})">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>` : ''}
        </div></td>
      </tr>`;
    }).join('');
  },

  bindEvents() {
    bindClick('cust-add-btn', () => this.openForm());
    bindInput('cust-search', (e) => { this.searchTerm = e.target.value; this.render(); });
    bindChange('cust-filter', (e) => { this.filter = e.target.value; this.render(); });
  },

  openForm(editId) {
    const c = editId ? this.customers.find(x => x.id === editId) : null;
    const html = `
      <div class="form-row">
        <label class="form-label">Customer Name *</label>
        <input class="form-input" id="f-cust-name" value="${c ? SellEngine.escHtml(c.name) : ''}" placeholder="Full name">
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Phone</label>
          <input class="form-input" id="f-cust-phone" value="${c ? SellEngine.escHtml(c.phone || '') : ''}" placeholder="05XXXXXXXX">
        </div>
        <div>
          <label class="form-label">Email</label>
          <input class="form-input" id="f-cust-email" value="${c ? SellEngine.escHtml(c.email || '') : ''}" placeholder="Optional">
        </div>
      </div>
      <div class="form-row">
        <label class="form-label">Address</label>
        <input class="form-input" id="f-cust-addr" value="${c ? SellEngine.escHtml(c.address || '') : ''}" placeholder="Optional">
      </div>
      <div class="form-row">
        <label class="form-label">Notes</label>
        <input class="form-input" id="f-cust-notes" value="${c ? SellEngine.escHtml(c.notes || '') : ''}" placeholder="Optional">
      </div>`;

    Modal.open(c ? 'Edit Customer' : 'Add Customer', html, async () => {
      const name = Modal.getVal('f-cust-name');
      if (!name) { Modal.showError('Name is required'); return; }

      const data = [name, Modal.getVal('f-cust-phone'), Modal.getVal('f-cust-email'), Modal.getVal('f-cust-addr'), Modal.getVal('f-cust-notes')];

      if (c) {
        await window.api.dbRun("UPDATE customers SET name=?, phone=?, email=?, address=?, notes=?, updated_at=datetime('now','localtime') WHERE id=?", [...data, c.id]);
      } else {
        await window.api.dbRun("INSERT INTO customers (name, phone, email, address, notes) VALUES (?,?,?,?,?)", data);
      }
      Modal.close();
      await this.load(); this.render();
      SellEngine.showToast(c ? 'Customer updated' : 'Customer added', 'success');
    });
  },

  async viewCustomer(id) {
    const c = this.customers.find(x => x.id === id);
    if (!c) return;

    // Get sales for this customer
    const salesR = await window.api.dbAll(
      "SELECT * FROM sales WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20", [id]);
    const sales = (salesR.success && salesR.data) ? salesR.data : [];

    // Get payment history
    const payR = await window.api.dbAll(
      "SELECT * FROM payment_history WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20", [id]);
    const payments = (payR.success && payR.data) ? payR.data : [];

    let html = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;font-size:12px;">
        <div><strong>Name:</strong> ${SellEngine.escHtml(c.name)}</div>
        <div><strong>Phone:</strong> ${SellEngine.escHtml(c.phone || '—')}</div>
        <div><strong>Email:</strong> ${SellEngine.escHtml(c.email || '—')}</div>
        <div><strong>Balance Due:</strong> <span class="cust-due ${c.balance_due > 0 ? 'has-due' : 'clear'}">${parseFloat(c.balance_due).toFixed(2)} SAR</span></div>
      </div>`;

    // Sales
    html += `<div class="form-label" style="margin-top:8px">Recent Sales (${sales.length})</div>`;
    if (sales.length > 0) {
      html += `<table class="pay-hist-table"><thead><tr><th>Invoice</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>`;
      html += sales.map(s => `<tr${s.is_void ? ' style="opacity:0.4;text-decoration:line-through"' : ''}>
        <td style="font-family:var(--font-mono)">${s.invoice_number}</td>
        <td>${(s.created_at || '').substring(0, 16)}</td>
        <td style="font-weight:700">${parseFloat(s.total).toFixed(2)}</td>
        <td>${s.is_void ? '<span class="void-stamp">VOID</span>' : '<span class="sale-badge completed">OK</span>'}</td>
      </tr>`).join('');
      html += `</tbody></table>`;
    } else {
      html += `<div style="font-size:12px;color:var(--text-light);padding:8px;">No sales yet</div>`;
    }

    // Payment history
    html += `<div class="form-label" style="margin-top:12px">Payment History (${payments.length})</div>`;
    if (payments.length > 0) {
      html += `<table class="pay-hist-table"><thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Method</th><th>Notes</th></tr></thead><tbody>`;
      html += payments.map(p => `<tr>
        <td>${(p.created_at || '').substring(0, 16)}</td>
        <td><span class="pay-type-badge ${p.type}">${p.type}</span></td>
        <td style="font-weight:700;font-family:var(--font-mono)">${parseFloat(p.amount).toFixed(2)}</td>
        <td>${p.method || '—'}</td>
        <td style="font-size:11px;color:var(--text-secondary)">${SellEngine.escHtml(p.notes || '')}</td>
      </tr>`).join('');
      html += `</tbody></table>`;
    } else {
      html += `<div style="font-size:12px;color:var(--text-light);padding:8px;">No payments recorded</div>`;
    }

    Modal.open('Customer: ' + c.name, html, () => Modal.close());
    document.getElementById('modal-save').textContent = 'Close';
    document.getElementById('modal-cancel').style.display = 'none';
  },

  receivePayment(id) {
    const c = this.customers.find(x => x.id === id);
    if (!c) return;

    const html = `
      <div style="text-align:center;margin-bottom:14px;">
        <div style="font-size:12px;color:var(--text-secondary);">Balance Due for ${SellEngine.escHtml(c.name)}</div>
        <div style="font-size:28px;font-weight:900;color:var(--accent-red);font-family:var(--font-mono)">${parseFloat(c.balance_due).toFixed(2)}</div>
      </div>
      <div class="form-row">
        <label class="form-label">Payment Amount *</label>
        <input class="form-input form-input-mono" id="f-cpay-amount" type="number" step="0.01" min="0.01" max="${c.balance_due}" value="${parseFloat(c.balance_due).toFixed(2)}" style="font-size:18px;height:44px">
      </div>
      <div class="form-row-double">
        <div>
          <label class="form-label">Method</label>
          <select class="form-select" id="f-cpay-method">
            <option value="cash">Cash</option>
            <option value="card">Card</option>
            <option value="transfer">Transfer</option>
          </select>
        </div>
        <div>
          <label class="form-label">Notes</label>
          <input class="form-input" id="f-cpay-notes" placeholder="Optional">
        </div>
      </div>`;

    Modal.open('Receive Payment', html, async () => {
      const amount = Modal.getNum('f-cpay-amount');
      if (amount <= 0) { Modal.showError('Amount must be > 0'); return; }
      if (amount > c.balance_due) { Modal.showError('Amount exceeds balance due'); return; }

      const method = Modal.getVal('f-cpay-method');
      const notes = Modal.getVal('f-cpay-notes');

      // Record payment
      await window.api.dbRun(
        "INSERT INTO payment_history (customer_id, amount, type, method, notes) VALUES (?,?,?,?,?)",
        [c.id, amount, 'payment', method, notes]
      );
      // Reduce balance
      await window.api.dbRun(
        "UPDATE customers SET balance_due = balance_due - ?, updated_at = datetime('now','localtime') WHERE id = ?",
        [amount, c.id]
      );

      Modal.close();
      await this.load(); this.render();
      SellEngine.showToast(`Payment received: ${amount.toFixed(2)} from ${c.name}`, 'success');
    });
  },

  async deleteCustomer(id) {
    if (id === 1) return; // Can't delete default
    if (!confirm('Delete this customer? Sales history will be preserved.')) return;
    await window.api.dbRun("UPDATE customers SET is_deleted = 1, updated_at = datetime('now','localtime') WHERE id = ?", [id]);
    await this.load(); this.render();
    SellEngine.showToast('Customer deleted', 'info');
  },

  // Get customer list for dropdowns
  async getForSelect() {
    const r = await window.api.dbAll("SELECT id, name, balance_due FROM customers WHERE is_deleted = 0 ORDER BY name ASC");
    return (r.success && r.data) ? r.data : [];
  }
};


// ============================================
// VOID / DELETE SYSTEM
// ============================================
const VoidManager = {

  // Void a sale — requires password, marks as void, restores stock
  async voidSale(saleId) {
    // Prompt for password
    const html = `
      <div style="text-align:center;margin-bottom:14px;">
        <div style="font-size:36px;margin-bottom:8px;">⚠️</div>
        <div style="font-size:15px;font-weight:700;color:var(--accent-red);">Void This Sale?</div>
        <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">This action cannot be easily undone. Stock will be restored.</div>
      </div>
      <div class="form-row">
        <label class="form-label">Enter Owner/Admin Password *</label>
        <input class="form-input form-input-mono" id="f-void-pw" type="password" placeholder="Password required">
      </div>
      <div class="form-row">
        <label class="form-label">Reason for Void *</label>
        <input class="form-input" id="f-void-reason" placeholder="e.g. Customer return, Wrong items...">
      </div>`;

    Modal.open('Void Sale', html, async () => {
      const pw = Modal.getVal('f-void-pw');
      const reason = Modal.getVal('f-void-reason');

      if (!pw) { Modal.showError('Password is required'); return; }
      if (!reason) { Modal.showError('Reason is required'); return; }

      // Verify password
      const settings = await window.api.getSettings();
      const correctPw = (settings.success && settings.data) ? settings.data.owner_password : '';
      if (pw !== correctPw) {
        Modal.showError('Incorrect password');
        return;
      }

      // Mark sale as void
      const voidR = await window.api.dbRun(
        "UPDATE sales SET is_void = 1, void_reason = ?, void_by = 'owner', status = 'voided' WHERE id = ?",
        [reason, saleId]
      );
      if (!voidR.success) { Modal.showError('Void failed: ' + voidR.error); return; }

      // Restore stock
      const stockR = await window.api.stockRestore(saleId);
      if (!stockR.success) {
        console.warn('[VOID] Stock restore warning:', stockR.error);
      }

      // If customer had due amount, reverse it
      const sale = await window.api.dbGet("SELECT customer_id, due_amount FROM sales WHERE id = ?", [saleId]);
      if (sale.success && sale.data && sale.data.due_amount > 0 && sale.data.customer_id > 1) {
        await window.api.dbRun(
          "UPDATE customers SET balance_due = MAX(0, balance_due - ?) WHERE id = ?",
          [sale.data.due_amount, sale.data.customer_id]
        );
      }

      Modal.close();

      // Refresh all affected pages
      await SellEngine.loadProducts();
      SellEngine.renderProducts();
      await SalesManager.load();
      SalesManager.render();

      SellEngine.showToast('Sale voided — stock restored', 'info');
    });
  }
};


// ============================================
// UPDATE MANAGER — GitHub Release Checker
// ============================================
const UpdateManager = {
  downloadPath: null,

  async init() {
    this.bindEvents();
    // Set current version
    const info = AppState.appInfo || {};
    const verEl = document.getElementById('upd-current-ver');
    if (verEl) verEl.textContent = info.version || '1.0.0';

    // Listen for download progress
    if (window.api && window.api.on) {
      window.api.on('update:progress', (data) => {
        const bar = document.getElementById('upd-progress-bar');
        const text = document.getElementById('upd-progress-text');
        if (bar) bar.style.width = data.percent + '%';
        if (text) {
          const mb = (data.downloaded / 1048576).toFixed(1);
          const totalMb = (data.total / 1048576).toFixed(1);
          text.textContent = `Downloading... ${mb} / ${totalMb} MB (${data.percent}%)`;
        }
      });
    }
  },

  bindEvents() {
    bindClick('upd-check-btn', () => this.checkForUpdates());
    bindClick('upd-download-btn', () => this.downloadUpdate());
  },

  async checkForUpdates() {
    const repo = document.getElementById('upd-repo').value.trim();
    if (!repo) {
      SellEngine.showToast('Enter your GitHub repository (e.g. username/zaz-pos-pro)', 'error');
      return;
    }

    const badge = document.getElementById('upd-status-badge');
    const infoDiv = document.getElementById('upd-info');
    const dlBtn = document.getElementById('upd-download-btn');

    badge.textContent = 'Checking...';
    badge.style.background = '#FEF3C7';
    badge.style.color = '#92400E';

    SellEngine.showToast('Checking for updates...', 'info');
    const r = await window.api.updateCheck(repo);

    if (!r.success) {
      badge.textContent = 'Check failed';
      badge.style.background = '#FEE2E2';
      badge.style.color = '#991B1B';
      SellEngine.showToast('Update check failed: ' + (r.error || ''), 'error');
      return;
    }

    const d = r.data;

    if (d.hasUpdate) {
      badge.textContent = 'Update available!';
      badge.style.background = '#DBEAFE';
      badge.style.color = '#1E40AF';

      document.getElementById('upd-new-ver').textContent = 'v' + d.latestVersion + (d.releaseName ? ' — ' + d.releaseName : '');
      document.getElementById('upd-notes').textContent = d.releaseNotes || 'No release notes.';
      infoDiv.style.display = 'block';

      if (d.downloadUrl) {
        dlBtn.style.display = 'inline-flex';
        this._pendingDownload = { url: d.downloadUrl, filename: d.downloadName };
      }

      SellEngine.showToast('Update available: v' + d.latestVersion, 'success');
    } else {
      badge.textContent = 'Up to date';
      badge.style.background = '#ECFDF5';
      badge.style.color = '#065F46';
      infoDiv.style.display = 'none';
      dlBtn.style.display = 'none';
      SellEngine.showToast('You are running the latest version', 'success');
    }
  },

  async downloadUpdate() {
    if (!this._pendingDownload) return;

    const progress = document.getElementById('upd-progress');
    const bar = document.getElementById('upd-progress-bar');
    const text = document.getElementById('upd-progress-text');

    progress.style.display = 'block';
    bar.style.width = '0%';
    text.textContent = 'Starting download...';

    SellEngine.showToast('Downloading update...', 'info');

    const r = await window.api.updateDownload(this._pendingDownload);

    if (r.success) {
      this.downloadPath = r.path;
      bar.style.width = '100%';
      text.textContent = 'Download complete!';

      const badge = document.getElementById('upd-status-badge');
      badge.textContent = 'Ready to install';
      badge.style.background = '#ECFDF5';
      badge.style.color = '#065F46';

      // Change download button to install button
      const dlBtn = document.getElementById('upd-download-btn');
      dlBtn.textContent = '🚀 Install & Restart';
      dlBtn.onclick = () => this.installUpdate();

      SellEngine.showToast('Update downloaded! Click "Install & Restart" to apply.', 'success');
    } else {
      text.textContent = 'Download failed: ' + (r.error || '');
      SellEngine.showToast('Download failed: ' + (r.error || ''), 'error');
    }
  },

  async installUpdate() {
    if (!this.downloadPath) return;
    if (!confirm('Install update now?\n\nThe app will close and the installer will open.\nMake sure to save any work first.')) return;

    await window.api.updateInstall(this.downloadPath);
  }
};
